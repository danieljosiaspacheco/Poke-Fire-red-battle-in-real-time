import sys, re; sys.path.insert(0,'/home/claude/work/hack/tools')
from emu import Emu
def sym(name, path='/home/claude/work/hack/build_debug/arena.sym'):
    for l in open(path):
        p=l.split()
        if len(p)>=3 and p[2]==name: return int(p[0],16)
def boot(rom='/home/claude/work/hack/build/test.gba', species=19, level=5):
    e=Emu(rom)
    e.load('/tmp/ss_intro2.state')
    for i in range(6): e.press(0x1,3,25)
    e.run(60)
    e.w16(0x203F000, species); e.w16(0x203F002, level)
    e.w32(0x30030F4, sym('DebugStartWild')|1)
    e.run(160)
    return e
