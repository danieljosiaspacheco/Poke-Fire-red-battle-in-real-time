"""tweak_sprites.py sprites.bin [follow.bin] - colour tweaks applied to the finished packs (idempotent).
Grovyle (#253): the PMD palette made its body a dark teal; recolour the body ramp to a bright leaf green
(arena pack: palette at record+8, overworld follower pack: palette at record+0)."""
import struct, sys
def rgb(r, g, b): return (r >> 3) | ((g >> 3) << 5) | ((b >> 3) << 10)
GREENS = ((5, (40, 176, 40)), (6, (112, 208, 64)), (7, (200, 248, 144)))
def tweak(path, pal_off):
    d = bytearray(open(path, 'rb').read())
    off = struct.unpack_from('<512I', d, 0)
    o = off[253] + pal_off
    for idx, col in GREENS:
        struct.pack_into('<H', d, o + 2 * idx, rgb(*col))
    open(path, 'wb').write(d)
tweak(sys.argv[1], 8)
if len(sys.argv) > 2: tweak(sys.argv[2], 0)
