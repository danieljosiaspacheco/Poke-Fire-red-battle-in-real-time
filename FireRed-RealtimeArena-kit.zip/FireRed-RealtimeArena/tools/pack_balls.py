#!/usr/bin/env python3
"""pack_balls.py FIRERED.gba OUT.bin [preview.png] - the 12 Poke Ball item icons of FireRed (24x24, LZ77), shrunk to 12x12
and centred in a 16x16 sprite.  Record i (in BALL_ITEMS order Poke, Great, Ultra, Master, Safari, Net, Dive, Nest, Repeat,
Timer, Luxury, Premier) = 16 x u16 palette + 4 tiles (TL, TR, BL, BR) of 4bpp = 160 bytes."""
import struct, sys
ITEMS = [4, 3, 2, 1, 5, 6, 7, 8, 9, 10, 11, 12]
ICON_TABLE = 0x3D428C + 8            # entry for item N at ICON_TABLE + 8 * N: {LZ tiles, LZ palette}

def lz(fr, off):
    assert fr[off] == 0x10
    n = fr[off + 1] | fr[off + 2] << 8 | fr[off + 3] << 16
    o = bytearray(); p = off + 4
    while len(o) < n:
        fl = fr[p]; p += 1
        for b in range(8):
            if len(o) >= n: break
            if fl & (0x80 >> b):
                a, c = fr[p], fr[p + 1]; p += 2
                l = (a >> 4) + 3; d = ((a & 15) << 8 | c) + 1
                for _ in range(l): o.append(o[-d])
            else:
                o.append(fr[p]); p += 1
    return bytes(o)

def icon(fr, item):
    a, b = struct.unpack_from('<II', fr, ICON_TABLE + 8 * item)
    d = lz(fr, a - 0x08000000); pal = lz(fr, b - 0x08000000)
    im = [[0] * 24 for _ in range(24)]
    for t in range(9):
        tx, ty = t % 3, t // 3
        for y in range(8):
            for x in range(8):
                v = d[t * 32 + y * 4 + x // 2]; v = (v >> 4) if x & 1 else v & 15
                im[ty * 8 + y][tx * 8 + x] = v
    return im, list(struct.unpack('<16H', pal[:32]))

def shrink(im, pal):
    """24x24 -> 12x12: each 2x2 block becomes its most common visible colour; a block that is mostly empty stays empty"""
    out = [[0] * 12 for _ in range(12)]
    lum = lambda i: sum((pal[i] >> s) & 31 for s in (0, 5, 10))
    for y in range(12):
        for x in range(12):
            blk = [im[2 * y + j][2 * x + i] for j in (0, 1) for i in (0, 1)]
            vis = [v for v in blk if v]
            if len(vis) < 2: continue
            best = max(set(vis), key=lambda v: (vis.count(v), -lum(v)))     # ties -> the darker one keeps the outline
            out[y][x] = best
    return out

def pack(fr):
    out = bytearray(); prev = []
    for item in ITEMS:
        im, pal = icon(fr, item)
        s = shrink(im, pal)
        cv = [[0] * 16 for _ in range(16)]
        for y in range(12):
            for x in range(12): cv[y + 2][x + 2] = s[y][x]
        out += struct.pack('<16H', *pal)
        for ty in range(2):
            for tx in range(2):
                for y in range(8):
                    for x in range(0, 8, 2):
                        out.append(cv[ty * 8 + y][tx * 8 + x] | (cv[ty * 8 + y][tx * 8 + x + 1] << 4))
        prev.append((cv, pal))
    return bytes(out), prev

def main():
    out, prev = pack(open(sys.argv[1], 'rb').read())
    open(sys.argv[2], 'wb').write(out)
    print('wrote', sys.argv[2], len(out))
    if len(sys.argv) > 3:
        from PIL import Image
        W = Image.new('RGBA', (len(prev) * 18, 18), (110, 150, 90, 255))
        for k, (cv, pal) in enumerate(prev):
            for y in range(16):
                for x in range(16):
                    v = cv[y][x]
                    if v: c = pal[v]; W.putpixel((k * 18 + 1 + x, 1 + y), ((c & 31) * 8, ((c >> 5) & 31) * 8, ((c >> 10) & 31) * 8, 255))
        W.resize((W.width * 5, W.height * 5), Image.NEAREST).save(sys.argv[3])
if __name__ == '__main__':
    main()
