import struct
ORD=["GAMS","GAMS"]
import itertools
perms=list(itertools.permutations("GAEM"))  # G A E M lexicographic order matches game's table
def mon(e, addr):
    b=e.rd(addr,100)
    pid,oid=struct.unpack_from('<II',b,0); key=pid^oid
    dec=bytearray(48)
    for i in range(12):
        w=struct.unpack_from('<I',b,32+4*i)[0]^key
        struct.pack_into('<I',dec,4*i,w)
    order=perms[pid%24]
    sub={c:dec[12*i:12*i+12] for i,c in enumerate(order)}
    species,item,exp,ppb,fr=struct.unpack_from('<HHIBB',sub['G'],0)
    return dict(species=species,exp=exp,friend=fr,level=b[0x54],hp=struct.unpack_from('<H',b,0x56)[0],maxhp=struct.unpack_from('<H',b,0x58)[0],moves=struct.unpack_from('<4H',sub['A'],0),pp=list(sub['A'][8:12]))
def party(e,i): return mon(e,0x2024284+100*i)
def enemy(e,i=0): return mon(e,0x202402C+100*i)

def set_exp(e, addr, newexp):
    b=bytearray(e.rd(addr,100))
    pid,oid=struct.unpack_from('<II',b,0); key=pid^oid
    dec=bytearray(48)
    for i in range(12):
        struct.pack_into('<I',dec,4*i,struct.unpack_from('<I',b,32+4*i)[0]^key)
    order=perms[pid%24]; gi=order.index('G')
    struct.pack_into('<I',dec,12*gi+4,newexp)
    chk=sum(struct.unpack_from('<24H',dec,0))&0xFFFF
    struct.pack_into('<H',b,0x1C,chk)
    for i in range(12):
        struct.pack_into('<I',b,32+4*i,struct.unpack_from('<I',dec,4*i)[0]^key)
    for i in range(32,80): e.w8(addr+i,b[i])
    e.w16(addr+0x1C,chk)
