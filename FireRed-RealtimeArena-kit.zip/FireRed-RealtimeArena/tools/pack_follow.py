#!/usr/bin/env python3
"""pack_follow.py - build the overworld follower pack: 32x32 walking sprites (S, N, W x 4 frames) per species,
taken from the user's own Pokemon Mystery Dungeon - Red Rescue Team ROM through extract_pmd.py.

Pack layout (little endian):
  u32[512]  table, index = national dex number, value = offset of the species record (0 = none)
  record:   u16 palette[16]; u16 frame_off[16] (offsets inside the record to GBA LZ77 blobs of one 32x32 4bpp frame);
            at +64: 3 walk animations (S, N, W) of 17 bytes: u8 count, 8 x {u8 frame, u8 ticks}
"""
import os, sys, struct, tempfile, shutil
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import extract_pmd as X
from pack_sprites import lz77
import overrides

SHAPE_W = [[8, 16, 32, 64], [16, 32, 32, 64], [8, 8, 16, 32]]
SHAPE_H = [[8, 16, 32, 64], [8, 8, 16, 32], [16, 32, 32, 64]]
DIRS = (0, 4, 6)        # PMD directions S, N, W


def decode(blob, off, fw, fh):
    px = [[0] * fw for _ in range(fh)]
    t = 0
    for ty in range(fh // 8):
        for tx in range(fw // 8):
            base = off + t * 32
            for r in range(8):
                for c in range(4):
                    b = blob[base + r * 4 + c]
                    px[ty * 8 + r][tx * 8 + c * 2] = b & 15
                    px[ty * 8 + r][tx * 8 + c * 2 + 1] = b >> 4
            t += 1
    return px


def bbox(px):
    ys = [y for y, row in enumerate(px) if any(row)]
    if not ys:
        return None
    xs = [x for row in px for x, v in enumerate(row) if v]
    return min(xs), min(ys), max(xs) + 1, max(ys) + 1


def shrink(px, x0, y0, w, h, s):
    """box-vote downscale of the w x h region at (x0,y0) by factor s <= 1"""
    nw, nh = max(1, int(w * s + 0.999)), max(1, int(h * s + 0.999))
    out = [[0] * nw for _ in range(nh)]
    for dy in range(nh):
        sy0, sy1 = int(dy / s), max(int(dy / s) + 1, int((dy + 1) / s + 0.999))
        for dx in range(nw):
            sx0, sx1 = int(dx / s), max(int(dx / s) + 1, int((dx + 1) / s + 0.999))
            cnt = {}
            tot = 0
            for yy in range(sy0, min(sy1, h)):
                for xx in range(sx0, min(sx1, w)):
                    tot += 1
                    v = px[y0 + yy][x0 + xx]
                    if v:
                        cnt[v] = cnt.get(v, 0) + 1
            if cnt and sum(cnt.values()) * 100 >= 35 * tot:
                out[dy][dx] = max(cnt, key=cnt.get)
    return out


def encode(px32, cw=32):
    out = bytearray()
    for ty in range(cw // 8):
        for tx in range(cw // 8):
            for r in range(8):
                for c in range(0, 8, 2):
                    out.append(px32[ty * 8 + r][tx * 8 + c] | (px32[ty * 8 + r][tx * 8 + c + 1] << 4))
    return bytes(out)


def species_record(rom, mt, n, tmp):
    d = os.path.join(tmp, str(n))
    info = X.extract_species(rom, n, d, anims=overrides.anim_list(n, "0"), previews=False, native=False, mt=mt)
    overrides.apply(info, d, n)
    fr = info["frame"]
    fw, fh = SHAPE_W[fr["obj_shape"]][fr["obj_size"]], SHAPE_H[fr["obj_shape"]][fr["obj_size"]]
    bpf = fr["bytes_per_frame"]
    blob = open(os.path.join(d, "frames.4bpp"), "rb").read()
    pal = open(os.path.join(d, "palette.pal"), "rb").read()[:32]
    walk = info["animations"]["walk"]["directions"]
    # the walk animation (frame sequence + ticks) of S, N, W, exactly as the arena plays it (max 8 steps each)
    seqs = []
    for dirn in DIRS:
        fl = walk[dirn]["frames"][:8] or [{"frame": 0, "ticks": 8}]
        seqs.append([(f["frame"], max(1, min(255, f["ticks"]))) for f in fl])
    uniq = []
    for sq in seqs:
        for fr_i, _ in sq:
            if fr_i not in uniq:
                uniq.append(fr_i)
    uniq = uniq[:16]
    chosen = [uniq]
    imgs = {}
    for seq in chosen:
        for fi in seq:
            if fi not in imgs:
                imgs[fi] = decode(blob, fi * bpf, fw, fh)
    # union bounding box over all chosen frames, scaled once so that it fits 30x30
    bb = None
    for p in imgs.values():
        b = bbox(p)
        if b:
            bb = b if bb is None else (min(bb[0], b[0]), min(bb[1], b[1]), max(bb[2], b[2]), max(bb[3], b[3]))
    if bb is None:
        return None
    w, h = bb[2] - bb[0], bb[3] - bb[1]
    # original size, never shrunk: 32x32 frames, or 64x64 for the species that are larger than that
    big = w > 32 or h > 32
    cw = 64 if big else 32
    frames = []
    for fi in uniq:
        p = imgs[fi]
        q = [row[bb[0]:bb[2]] for row in p[bb[1]:bb[3]]]
        qh, qw = len(q), len(q[0])
        canvas = [[0] * cw for _ in range(cw)]
        ox, oy = (cw - qw) // 2, cw - 1 - qh            # centred, feet near the bottom
        for y in range(qh):
            for x in range(qw):
                canvas[oy + y][ox + x] = q[y][x]
        frames.append(encode(canvas, cw))
    anim = bytearray()
    for sq in seqs:
        sq = [(uniq.index(f) if f in uniq else 0, t) for f, t in sq]
        anim.append(len(sq))
        for f, t in sq:
            anim += bytes((f, t))
        anim += b'\0' * (2 * (8 - len(sq)))
    shutil.rmtree(d, ignore_errors=True)
    return pal, frames, bytes(anim), big


def pack(pmd_path, species_list, verbose=True):
    rom = X.load_rom(pmd_path)
    mt = X.MonsterTable(rom)
    tmp = tempfile.mkdtemp(prefix="follow_")
    table = [0] * 512
    body = bytearray()
    base = 512 * 4
    try:
        for n in species_list:
            try:
                r = species_record(rom, mt, n, tmp)
            except Exception as e:
                if verbose:
                    print("  skip %d: %s" % (n, e))
                continue
            if not r:
                continue
            pal, frames, anim, big = r
            comp = [lz77(f, True) for f in frames]
            rec = bytearray(pal) + b"\0" * 32 + anim + b"\0" * 1      # 32 pal | 32 frame table | 51 anim | pad -> 116
            while len(rec) < 116:
                rec.append(0)
            rec[115] = 1 if big else 0                                 # size class: 0 = 32x32, 1 = 64x64
            offs = []
            for c in comp:
                offs.append(len(rec))
                rec += c
            rec[32:32 + 2 * len(offs)] = struct.pack("<%dH" % len(offs), *offs)
            while len(body) % 4:
                body.append(0)
            table[n] = base + len(body)
            body += rec
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    return struct.pack("<512I", *table) + bytes(body)


if __name__ == "__main__":
    out = sys.argv[3] if len(sys.argv) > 3 else os.path.join(HERE, "..", "build", "follow.bin")
    if len(sys.argv) > 4:
        overrides.set_firered(sys.argv[4])       # FireRed ROM: two-legged Zangoose
    data = pack(sys.argv[1], range(1, 387))
    open(out, "wb").write(data)
    print("wrote %s (%.2f MB)" % (out, len(data) / 1e6))
