"""customfx.py - original (hand-drawn) 32x32 effect sprites for moves that have no graphics in FireRed
(there, melee moves are animated by moving the Pokemon itself). Pure python, no dependencies."""
import math, struct

# palette per type: (main, light, shade) as RGB tuples
TYPE_COL = {
    0: ((200, 192, 170), (248, 244, 230), (128, 120, 100)),   # normal
    1: ((208, 72, 56), (248, 168, 136), (136, 32, 24)),       # fighting
    2: ((144, 176, 248), (216, 232, 255), (80, 104, 192)),    # flying
    3: ((176, 80, 200), (232, 168, 248), (104, 40, 128)),     # poison
    4: ((216, 176, 96), (248, 224, 160), (144, 104, 48)),     # ground
    5: ((176, 144, 80), (224, 200, 144), (112, 88, 40)),      # rock
    6: ((152, 200, 56), (216, 248, 128), (88, 128, 24)),      # bug
    7: ((144, 104, 176), (208, 176, 232), (80, 56, 112)),     # ghost
    8: ((176, 184, 200), (232, 240, 248), (104, 112, 136)),   # steel
    9: ((200, 192, 170), (248, 244, 230), (128, 120, 100)),
    10: ((248, 128, 40), (255, 216, 96), (176, 56, 16)),      # fire
    11: ((72, 136, 248), (168, 208, 255), (32, 72, 176)),     # water
    12: ((88, 192, 80), (176, 240, 144), (40, 120, 40)),      # grass
    13: ((248, 216, 40), (255, 248, 160), (184, 144, 8)),     # electric
    14: ((248, 104, 160), (255, 190, 216), (176, 56, 104)),   # psychic
    15: ((136, 224, 240), (216, 248, 255), (72, 152, 184)),   # ice
    16: ((104, 80, 232), (176, 160, 255), (56, 40, 160)),     # dragon
    17: ((120, 96, 88), (176, 152, 144), (56, 40, 40)),       # dark
}

def rgb555(c): return (c[0] >> 3) | ((c[1] >> 3) << 5) | ((c[2] >> 3) << 10)

class Canvas:
    def __init__(self): self.p = [[0] * 32 for _ in range(32)]
    def px(self, x, y, c):
        if 0 <= x < 32 and 0 <= y < 32: self.p[y][x] = c
    def poly(self, pts, c):
        n = len(pts)
        for y in range(32):
            xs = []
            for i in range(n):
                (x0, y0), (x1, y1) = pts[i], pts[(i + 1) % n]
                if (y0 <= y + 0.5 < y1) or (y1 <= y + 0.5 < y0):
                    xs.append(x0 + (y + 0.5 - y0) * (x1 - x0) / (y1 - y0))
            xs.sort()
            for i in range(0, len(xs) - 1, 2):
                for x in range(int(math.floor(xs[i] + 0.5)), int(math.floor(xs[i + 1] + 0.5))): self.px(x, y, c)
    def rect(self, x0, y0, x1, y1, c):
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1): self.px(x, y, c)
    def ell(self, cx, cy, rx, ry, c):
        for y in range(32):
            for x in range(32):
                if ((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2 <= 1: self.px(x, y, c)
    def ring(self, cx, cy, ro, ri, c, clip=None):
        for y in range(32):
            for x in range(32):
                r = math.hypot(x - cx, y - cy)
                if ri <= r <= ro and (clip is None or clip(x, y)): self.px(x, y, c)
    def line(self, x0, y0, x1, y1, w, c):
        dx, dy = x1 - x0, y1 - y0; L = dx * dx + dy * dy or 1
        for y in range(32):
            for x in range(32):
                t = max(0, min(1, ((x - x0) * dx + (y - y0) * dy) / L))
                if math.hypot(x - (x0 + t * dx), y - (y0 + t * dy)) <= w / 2: self.px(x, y, c)
    def outline(self):
        q = [r[:] for r in self.p]
        for y in range(32):
            for x in range(32):
                if self.p[y][x]: continue
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    a, b = x + dx, y + dy
                    if 0 <= a < 32 and 0 <= b < 32 and self.p[b][a] and self.p[b][a] != 1: q[y][x] = 1; break
        self.p = q

# colour indices: 1 outline, 2 main, 3 light, 4 white, 5 shade
def star_pts(cx, cy, ro, ri, n):
    return [(cx + (ro if i % 2 == 0 else ri) * math.sin(math.pi * i / n), cy - (ro if i % 2 == 0 else ri) * math.cos(math.pi * i / n)) for i in range(2 * n)]


def _fist(c, cx, cy):
    """a clenched fist seen from the front, colours: 1 outline, 6 skin, 7 skin shade, 8 skin highlight"""
    def shapes(g, col, ol):
        for i in range(4): c.ell(cx - 4.5 + 3 * i, cy - 4.2, 2.2 + g, 2.4 + g, col)
        c.rect(int(cx - 6 - g), int(cy - 3 - g), int(cx + 6 + g), int(cy + 6 + g), col)
        c.ell(cx - 6.5, cy + 2, 2.6 + g, 3.4 + g, col)
    shapes(1.2, 1, 1)
    shapes(0, 6, 0)
    c.rect(int(cx - 5), int(cy + 5), int(cx + 6), int(cy + 6), 7)
    for x in (-3, 0, 3): c.line(cx + x, cy - 3, cx + x, cy + 1.5, 1, 7)
    c.line(cx - 6, cy - 5.2, cx + 5, cy - 5.2, 1, 8)
    c.ell(cx - 6.5, cy + 2, 1.3, 2, 7)

def _tongue(c, bx, by, ang, ln, w, col):
    a = math.radians(ang); dx, dy = math.cos(a), -math.sin(a); nx, ny = -dy, dx
    pts = [(bx + nx * w / 2, by + ny * w / 2), (bx + dx * ln * 0.45 + nx * w * 0.62, by + dy * ln * 0.45 + ny * w * 0.62),
           (bx + dx * ln, by + dy * ln), (bx + dx * ln * 0.45 - nx * w * 0.62, by + dy * ln * 0.45 - ny * w * 0.62),
           (bx - nx * w / 2, by - ny * w / 2)]
    c.poly(pts, col)

def _bolt(c, x0, y0, x1, y1, jit, w):
    n = 4; pts = [(x0, y0)]
    for i in range(1, n):
        t = i / n; pts.append((x0 + (x1 - x0) * t + (jit if i % 2 else -jit), y0 + (y1 - y0) * t + (-jit if i % 2 else jit) * 0.6))
    pts.append((x1, y1))
    for (a, b), (d, e) in zip(pts, pts[1:]): c.line(a, b, d, e, w + 1.8, 1)
    for (a, b), (d, e) in zip(pts, pts[1:]): c.line(a, b, d, e, w, 2)
    for (a, b), (d, e) in zip(pts, pts[1:]): c.line(a, b, d, e, 0.8, 4)

def _shard(c, cx, cy, ang, r0, r1, w):
    a = math.radians(ang); dx, dy = math.cos(a), -math.sin(a); nx, ny = -dy, dx
    tip = (cx + dx * r1, cy + dy * r1)
    b1 = (cx + dx * r0 + nx * w / 2, cy + dy * r0 + ny * w / 2); b2 = (cx + dx * r0 - nx * w / 2, cy + dy * r0 - ny * w / 2)
    c.poly([(b1[0] + (b1[0] - tip[0]) * 0.0, b1[1]), (tip[0], tip[1]), (b2[0], b2[1])], 1)
    mid = (cx + dx * (r0 + (r1 - r0) * 0.12), cy + dy * (r0 + (r1 - r0) * 0.12))
    sm = (cx + dx * (r1 - 1.6), cy + dy * (r1 - 1.6))
    c.poly([(b1[0] - nx * 0.8, b1[1] - ny * 0.8), sm, (b2[0] + nx * 0.8, b2[1] + ny * 0.8)], 2)
    c.poly([((b1[0] + sm[0]) / 2, (b1[1] + sm[1]) / 2), sm, (mid[0] + nx * w * 0.1, mid[1] + ny * w * 0.1)], 4)


def _sole(c, cx, cy, ang, L, W, col, tread=None):
    """a shoe sole print: forefoot, narrow waist, heel. ang = direction of the toe (degrees, 0 = up, clockwise); L length, W width"""
    a = math.radians(ang); ca, sa = math.cos(a), math.sin(a)
    for y in range(32):
        for x in range(32):
            dx, dy = x + 0.5 - cx, y + 0.5 - cy
            u = dx * ca + dy * sa            # across
            v = -dx * sa + dy * ca           # along (negative = toe side)
            fv = (v + 0.22 * L) / (0.30 * L); fu = u / (0.5 * W)
            hv = (v - 0.32 * L) / (0.17 * L); hu = u / (0.36 * W)
            wv = (v - 0.05 * L); wu = u / (0.30 * W)
            inside = fu * fu + fv * fv <= 1 or hu * hu + hv * hv <= 1 or (abs(wv) <= 0.22 * L and abs(wu) <= 1)
            if inside:
                c.px(x, y, col)
                if tread and -0.42 * L < v < -0.08 * L and int((v + 1) * 10) % 4 == 0 and abs(u) < 0.42 * W: c.px(x, y, tread)

def _paw(c, cx, cy, s, body, claw, pad):
    # bear paw print: big palm pad + four toe pads, curved claws above the toes
    c.ell(cx, cy + 7 * s, 8.2 * s, 6.4 * s, body)
    for tx, ty, r in ((-9, -3.5, 3.3), (-3.2, -7.5, 3.6), (3.2, -7.5, 3.6), (9, -3.5, 3.3)):
        c.ell(cx + tx * s, cy + ty * s, r * s * 1.0, r * s * 1.2, body)
    for tx, ty, d in ((-9, -3.5, -1), (-3.2, -7.5, -0.35), (3.2, -7.5, 0.35), (9, -3.5, 1)):
        bx, by = cx + tx * s, cy + (ty - 3.2) * s
        pts = [(bx - 1.6, by + 1), (bx + d * 2.5 - 0.3, by - 6.5 * s), (bx + d * 3.5, by - 8 * s), (bx + 1.6, by + 1)]
        c.poly(pts, claw)
    c.ell(cx, cy + 8 * s, 4.6 * s, 3.2 * s, pad)

def draw(kind):
    c = Canvas()
    if kind == 'fist':
        c.rect(10, 22, 22, 30, 5)
        c.poly([(6, 12), (25, 12), (26, 24), (8, 25)], 2)
        for i, x in enumerate((9, 13, 17, 22)): c.ell(x, 11, 3.2, 4, 2); c.line(x - 1, 8, x - 1, 10, 1, 3)
        c.ell(7, 20, 4, 3, 2)
        for x in (11, 15, 19): c.line(x, 13, x, 20, 1, 5)
        c.line(8, 14, 23, 14, 1, 3)
    elif kind == 'kick':
        c.rect(11, 2, 20, 16, 2); c.rect(11, 2, 13, 16, 3)
        c.poly([(11, 16), (21, 16), (29, 22), (29, 28), (7, 28), (7, 19)], 2)
        c.rect(7, 26, 29, 28, 5); c.line(22, 18, 27, 22, 2, 3)
        c.rect(11, 12, 20, 13, 5)
    elif kind == 'fangs':
        c.rect(3, 3, 28, 9, 2); c.rect(3, 23, 28, 29, 2)
        for x in (4, 11, 18, 24):
            c.poly([(x, 9), (x + 5, 9), (x + 2.5, 18)], 4)
            c.poly([(x + 3, 23), (x + 8, 23), (x + 5.5, 14)], 4)
        c.line(3, 4, 28, 4, 1, 3); c.line(3, 24, 28, 24, 1, 3)
    elif kind == 'claw':
        for dx in (0, 8, 16):
            c.poly([(3 + dx, 1), (8 + dx, 1), (12 + dx, 30), (8 + dx, 24)], 2)
            c.line(5 + dx, 3, 10 + dx, 26, 1, 4)
    elif kind == 'dclaw':     # Dragon Claw: four tapering curved claw slashes, two on the left and two on the right (mirrored), yellow
        for side, xs in ((1, (10.0, 3.5)), (-1, (22.0, 28.5))):
            for tx in xs:
                pts = []
                for k in range(41):
                    t = k / 40.0
                    pts.append((tx + side * (-6.5 * t + 1.4 * math.sin(math.pi * t) * 0 ) - side * 3.0 * t * 0 + 0 + (4.0 - 8.0 * t) * side * -1 * -1 * 0 + side * (3.5 - 7.0 * t), 1 + 29 * t, 3.0 * math.sin(math.pi * t) + 0.5))
                for ring, col in ((1.0, 1), (0.0, 2), (-1.3, 3), (-2.2, 4)):
                    for x, y, r in pts:
                        rr = r + ring
                        if rr > 0.3: c.ell(x, y, rr, rr, col)
    elif kind == 'shoes3':     # Triple Kick: three black shoe prints
        _sole(c, 6.5, 18, 0, 22, 9, 2, 5); _sole(c, 16, 14, 0, 22, 9, 2, 5); _sole(c, 25.5, 18, 0, 22, 9, 2, 5)
        c.outline()
    elif kind == 'dbreath':    # Dragon Breath: a yellow flame blob; a row of them is a long wavering yellow column like Flamethrower
        for ang, ln, w in ((0, 13, 9), (40, 10, 7), (-40, 10, 7), (180, 6, 8)):
            _tongue(c, 12, 16, ang, ln, w, 5)
        c.ell(15, 16, 10, 8.5, 5)
        c.ell(15, 16, 8.5, 7, 2)
        for ang, ln, w in ((0, 14, 6), (35, 9, 4.5), (-35, 9, 4.5)):
            _tongue(c, 12, 16, ang, ln, w, 2)
        c.ell(14, 16, 5.5, 4.5, 3); c.ell(13, 16, 2.8, 2.2, 4)
    elif kind == 'jet':       # Hydro Pump: a big plain blob of water; a dense row of them is one thick continuous jet
        c.ell(16, 16, 15, 14, 2)
        for y in range(32):
            for x in range(32):
                if c.p[y][x] == 2 and (x - 16) ** 2 / 225.0 + (y - 16) ** 2 / 196.0 <= 1:
                    if 6 <= y <= 8: c.p[y][x] = 3
                    elif y == 7: c.p[y][x] = 4
                    elif y >= 24: c.p[y][x] = 5
        for x in range(4, 28): c.px(x, 7, 4) if c.p[7][x] else None
    elif kind == 'orbs':      # Mega/Giga Drain: a heap of round green balls
        balls = [(8, 7, 4.2), (20, 6, 3.4), (27, 13, 3.0), (14, 15, 4.6), (5, 19, 3.2), (24, 22, 4.2), (13, 26, 3.4), (30, 29, 2.0), (3, 29, 2.2), (19, 14, 2.4)]
        for bx, by, r in balls:
            c.ell(bx, by, r, r, 5); c.ell(bx, by, r - 1, r - 1, 2); c.ell(bx - r * 0.3, by - r * 0.3, max(1.0, r * 0.45), max(1.0, r * 0.45), 3)
            c.px(int(bx - r * 0.4), int(by - r * 0.4), 4)
    elif kind == 'bolt':      # Thunder Shock (alternative): a horizontal wave of jagged lightning, flat at both edges so copies join
        pts = [(-2, 16), (2, 16), (6, 5), (10, 25), (14, 7), (18, 26), (22, 6), (26, 24), (29, 16), (34, 16)]
        for (x0, y0), (x1, y1) in zip(pts, pts[1:]): c.line(x0, y0, x1, y1, 3.6, 2)
        for (x0, y0), (x1, y1) in zip(pts, pts[1:]): c.line(x0, y0, x1, y1, 1.5, 4)
        for fx, fy, tx, ty in ((14, 7, 19, 2), (18, 26, 13, 30), (22, 6, 26, 1), (10, 25, 6, 30)): c.line(fx, fy, tx, ty, 2, 2); c.line(fx, fy, tx, ty, 1, 4)
    elif kind == 'ecg':       # Thunder Shock: one heartbeat of an electrocardiogram trace, flat at both edges so copies join into a continuous line
        pts = [(-2, 16), (5, 16), (7, 13), (10, 13), (12, 16), (13, 18), (15, 2), (18, 28), (20, 16), (22, 16), (24, 11), (28, 11), (30, 16), (34, 16)]
        for (x0, y0), (x1, y1) in zip(pts, pts[1:]): c.line(x0, y0, x1, y1, 3.2, 2)
        for (x0, y0), (x1, y1) in zip(pts, pts[1:]): c.line(x0, y0, x1, y1, 1.4, 4)
    elif kind == 'wind':
        for by in (7, 16, 25):
            pts = [(x, by + ((x - 14) ** 2) // 36 - 4) for x in range(2, 30, 2)]
            for (x0, y0), (x1, y1) in zip(pts, pts[1:]): c.line(x0, y0, x1, y1, 3, 2)
            for (x0, y0), (x1, y1) in zip(pts, pts[1:]): c.line(x0, y0, x1, y1, 1, 4)
    elif kind == 'wing':      # straight wing stretched out sideways (right-facing, root at the left edge): flat arm on top, eight feathers hanging below
        for i in range(8):
            x0 = i * 4; ln = int(28 - i * 1.5)
            c.rect(x0, 10, x0 + 2, ln - 3, 2); c.rect(x0, 10, x0, ln - 3, 3); c.rect(x0 + 3, 10, x0 + 3, ln - 4, 5)
            c.rect(x0 + 1, ln - 2, x0 + 1, ln - 1, 2); c.rect(x0, ln - 3, x0 + 2, ln - 3, 2)
        c.rect(0, 6, 31, 11, 5); c.rect(0, 7, 31, 9, 2); c.rect(0, 7, 31, 7, 3)
    elif kind == 'icegale':   # Blizzard: an icy gale - three long swirling wind streaks with ice crystals flying in it (faces right)
        for by, ph in ((8, 0.0), (16, 1.6), (24, 3.2)):
            pts = [(x, by + 3.0 * math.sin(x * 0.32 + ph)) for x in range(0, 32, 2)]
            for (x0, y0), (x1, y1) in zip(pts, pts[1:]): c.line(x0, y0, x1, y1, 2.5 + 3.5 * (x0 / 31.0), 5)
            for (x0, y0), (x1, y1) in zip(pts, pts[1:]): c.line(x0, y0, x1, y1, 1.2 + 2.6 * (x0 / 31.0), 2)
            for (x0, y0), (x1, y1) in zip(pts[2:], pts[3:]): c.line(x0, y0, x1, y1, 1, 4)
        for cx, cy, r in ((5, 4, 3), (22, 12, 3.6), (11, 20, 3.2), (27, 27, 3.2), (27, 3, 2.8), (4, 28, 2.8)):
            c.poly([(cx, cy - r), (cx + r * 0.65, cy), (cx, cy + r), (cx - r * 0.65, cy)], 5)
            c.poly([(cx, cy - r + 1), (cx + r * 0.65 - 1, cy), (cx, cy + r - 1), (cx - r * 0.65 + 1, cy)], 3)
            c.px(int(cx), int(cy - 1), 4)
    elif kind == 'bean':      # Ice Beam: a heap of ice balls shaped like beans
        beans = [(6, 6, 0.5), (16, 5, -0.3), (26, 8, 0.6), (9, 15, -0.5), (20, 15, 0.3), (28, 20, -0.6), (5, 25, 0.4), (15, 25, -0.4), (25, 28, 0.2)]
        for bx, by, an in beans:
            dx, dy = 2.4 * math.cos(an), 2.4 * math.sin(an)
            c.line(bx - dx, by - dy, bx + dx, by + dy, 6.6, 5)
            c.line(bx - dx, by - dy - 0.4, bx + dx, by + dy - 0.4, 5.0, 2)
            c.line(bx - dx - 0.8, by - dy - 1.4, bx + dx - 0.8, by + dy - 1.4, 1.6, 3)
            c.px(int(bx - dx * 0.5 - 1), int(by - dy * 0.5 - 2), 4)
    elif kind == 'mound':     # Dig: a hump of earth ploughing forward (faces right), pebbles on top, a puff of dust behind
        c.ell(19, 27, 12.5, 11, 5)
        c.ell(19, 26, 11, 9.5, 2)
        c.ell(17, 22, 6.5, 4.5, 3)
        for ex, ey, r in ((25, 20, 1.6), (13, 25, 1.5), (21, 17, 1.2), (28, 26, 1.4)): c.ell(ex, ey, r, r, 5)
        for ex, ey, r in ((4, 26, 2.8), (8, 22, 2.4), (3, 20, 1.8), (9, 28, 2.2)): c.ell(ex, ey, r, r, 3)
        c.rect(0, 29, 31, 31, 0)
        c.rect(2, 28, 30, 28, 5)
    elif kind == 'rubble':    # Magnitude: three jagged rocks thrust out of the ground in a cloud of dust
        c.poly([(1, 28), (3, 15), (8, 9), (13, 28)], 2); c.poly([(3, 15), (8, 9), (7, 20)], 3); c.poly([(8, 9), (13, 28), (8, 28)], 5)
        c.poly([(11, 28), (14, 7), (19, 1), (24, 28)], 2); c.poly([(14, 7), (19, 1), (17, 15)], 3); c.poly([(19, 1), (24, 28), (18, 28)], 5)
        c.poly([(22, 28), (24, 17), (28, 12), (31, 28)], 2); c.poly([(24, 17), (28, 12), (27, 22)], 3); c.poly([(28, 12), (31, 28), (27, 28)], 5)
        for ex, ey, r in ((3, 29, 2.8), (13, 30, 3), (23, 29, 3), (30, 30, 2.4)): c.ell(ex, ey, r, r - 0.6, 4)
    elif kind == 'leaf':      # Razor Leaf: a heap of sharp leaves, each a different angle (green blades with a pale midrib)
        leaves = [(7, 7, 6.5, 0.5), (18, 5, 6, -0.3), (27, 10, 5.5, 0.7), (9, 17, 6, -0.6), (20, 16, 6.5, 0.2), (28, 23, 5.2, -0.7), (6, 26, 5.5, 0.4), (16, 27, 6, -0.4), (25, 29, 4.5, 0.1)]
        for pas in (0, 1):
            for lx, ly, L, an in leaves:
                ca, sa = math.cos(an), math.sin(an)
                w = 3.1 - (0.9 if pas == 0 else 0) * 0
                tip = (lx + L * ca, ly + L * sa); base = (lx - L * ca, ly - L * sa)
                m1 = (lx - 0.2 * L * ca - w * sa, ly - 0.2 * L * sa + w * ca); m2 = (lx - 0.2 * L * ca + w * sa, ly - 0.2 * L * sa - w * ca)
                if pas == 0:
                    e = 1.0
                    c.poly([(base[0] - e * ca, base[1] - e * sa), (m1[0] - e * sa, m1[1] + e * ca), (tip[0] + e * ca, tip[1] + e * sa), (m2[0] + e * sa, m2[1] - e * ca)], 5)
                else:
                    c.poly([base, m1, tip, m2], 2)
                    c.line(base[0] + ca, base[1] + sa, tip[0] - ca, tip[1] - sa, 1.1, 3)
                    c.line(lx - sa * 1.5, ly + ca * 1.5, lx + ca * 2, ly + sa * 2, 0.9, 5)
    elif kind == 'fistfire':   # Fire Punch: a fist inside a blaze
        for ang, ln, w in ((90, 14, 9), (50, 13, 8), (130, 13, 8), (10, 12, 7), (170, 12, 7), (-30, 10, 6.5), (210, 10, 6.5)):
            _tongue(c, 16, 17, ang, ln, w, 5)
        for ang, ln, w in ((90, 11, 6.5), (52, 10, 5.5), (128, 10, 5.5), (12, 9, 5), (168, 9, 5), (-30, 7, 4.5), (210, 7, 4.5)):
            _tongue(c, 16, 17, ang, ln, w, 2)
        for ang, ln, w in ((90, 8, 4), (55, 7, 3.4), (125, 7, 3.4)):
            _tongue(c, 16, 17, ang, ln, w, 3)
        _fist(c, 16, 17)
        for ang, ln, w in ((60, 8, 5), (120, 8, 5)):
            _tongue(c, 16 + (5 if ang < 90 else -5), 24, ang, ln, w, 2)
        _tongue(c, 21, 24, 60, 5, 3, 3); _tongue(c, 11, 24, 120, 5, 3, 3)
    elif kind == 'fistthunder':   # Thunder Punch: a fist in the middle of crackling lightning
        for x0, y0, x1, y1, j in ((16, 9, 15, 0, 2.4), (22, 12, 31, 3, 2.6), (24, 17, 31, 16, 2.4), (22, 23, 30, 30, 2.6), (16, 25, 17, 31, 2.4), (10, 23, 1, 30, 2.6), (8, 17, 0, 15, 2.4), (10, 12, 2, 3, 2.6)):
            _bolt(c, x0, y0, x1, y1, j, 1.7)
        _fist(c, 16, 17)
        for x, y in ((5, 8), (27, 9), (4, 25), (28, 24)): c.px(x, y, 4); c.px(x + 1, y, 4); c.px(x, y + 1, 4)
    elif kind == 'fistice':    # Ice Punch: a fist frozen inside a block of ice with crystal spikes
        for ang in (90, 45, 0, -45, -90, 225, 180, 135):
            _shard(c, 16, 16, ang, 8, 15.5 if ang % 90 == 0 else 14, 7)
        c.ell(16, 16, 12.3, 11.5, 1); c.ell(16, 16, 11.2, 10.4, 3)
        c.ell(16, 16, 11.2, 10.4, 3)
        for x, y, rx, ry in ((9, 9, 2.4, 1.2), (24, 22, 2.0, 1.0)): c.ell(x, y, rx, ry, 4)
        _fist(c, 16, 17)
        c.line(6, 21, 11, 26, 1, 4); c.px(25, 8, 4); c.px(26, 9, 4); c.px(24, 9, 4); c.px(25, 10, 4)
    elif kind == 'sludge':     # Sludge Bomb: a glob of toxic sludge, lumpy, with a drip and bubbles; a row of them makes a long stream
        c.ell(16, 16, 8.2, 6.6, 2); c.ell(11, 12, 4, 3.4, 2); c.ell(21, 20, 4.2, 3.4, 2); c.ell(20, 11.5, 3, 2.6, 2); c.ell(8.5, 19, 2.8, 2.4, 2)
        c.outline()
        c.ell(18, 20, 6, 3, 5)
        c.ell(13, 12.5, 3.2, 2.0, 3); c.ell(21.5, 11.5, 1.6, 1.2, 3)
        c.ell(17, 15, 1.1, 1.1, 4); c.px(12, 11, 4); c.px(13, 11, 4)
        c.ell(20, 17, 1.2, 1.2, 1); c.ell(14, 19, 1.0, 1.0, 1)
    elif kind == 'bearclaw':    # Stomp: a black bear paw with pale claws
        _paw(c, 16, 14, 1.0, 2, 4, 5)
        c.outline()
        for x, y in ((12, 21), (20, 21)): c.px(x, y, 3)
    elif kind == 'shoes2':     # Double Kick: two black shoe prints
        _sole(c, 9.5, 17, 0, 24, 11, 2, 5); _sole(c, 22.5, 14, 0, 24, 11, 2, 5)
        c.outline()
    elif kind == 'shoering':   # Rolling Kick: a circle of black shoe prints, toes outward
        for i in range(6):
            ang = i * 60
            r = 10.5
            _sole(c, 16 + r * math.sin(math.radians(ang)), 16 - r * math.cos(math.radians(ang)), ang, 12, 6, 2, 5)
        c.outline()
    elif kind == 'rollball':   # Rollout: a ball, recoloured at run time with the colours of the Pokemon; swirl bands show the spin
        c.ell(16, 16, 12.5, 12.5, 1); c.ell(16, 16, 11.5, 11.5, 2)
        for y in range(32):
            for x in range(32):
                if c.p[y][x] == 2 and (x - 16) + (y - 16) > 9: c.p[y][x] = 5
        for off in (-5.5, 5.5):
            for t in range(41):
                u = t / 40.0 * 2 - 1
                x = 16 + 10.5 * u; y = 16 + off + 5.5 * math.sin(math.pi * u)
                if math.hypot(x - 16, y - 16) < 10.8: c.ell(x, y, 1.6, 1.6, 5)
        for t in range(41):
            u = t / 40.0 * 2 - 1
            x = 16 + 10.5 * u; y = 16 + 5.5 * math.sin(math.pi * u)
            if math.hypot(x - 16, y - 16) < 10.8: c.ell(x, y, 1.2, 1.2, 3)
        c.ell(11.5, 10.5, 3.6, 2.4, 3); c.ell(10.5, 9.8, 1.4, 1.0, 4)
        for ang in (30, 150, 270):
            x = 16 + 5.5 * math.cos(math.radians(ang)); y = 16 - 5.5 * math.sin(math.radians(ang))
            c.ell(x, y, 1.4, 1.4, 3)
    elif kind == 'vinebead':  # Vine Whip: one round bead of vine; a chain of them (two chains, wobbling) forms the two vines
        c.ell(16, 16, 6.0, 6.0, 1); c.ell(16, 16, 5.0, 5.0, 2); c.ell(14.4, 14.2, 2.4, 1.9, 3); c.px(13, 13, 4); c.px(14, 12, 4)
        c.ell(18.2, 18.4, 2.6, 1.8, 5)
    elif kind == 'amoeba':    # Pursuit: a purple amoeba with round-tipped pseudopods
        pods = ((15, 10.5, 6.4), (78, 9.0, 5.6), (142, 11.0, 6.6), (204, 8.5, 5.4), (256, 10.0, 6.0), (320, 9.5, 5.8))
        c.ell(16, 16, 9.4, 8.6, 2)
        for ang, ln, w in pods:
            a = math.radians(ang); tx, ty = 16 + ln * math.cos(a), 16 - ln * math.sin(a) * 0.95
            c.line(16, 16, tx, ty, w * 0.9, 2); c.ell(tx, ty, w / 2, w / 2, 2)
        c.outline()
        c.ell(13.5, 13, 3.6, 2.8, 3); c.ell(21, 12, 1.8, 1.4, 3); c.ell(11, 20, 1.6, 1.4, 3)
        c.ell(17.5, 17.5, 3.4, 3.0, 5); c.ell(18, 18, 1.5, 1.3, 1)
        c.px(12, 12, 4); c.px(13, 11, 4); c.px(21, 11, 4)
    elif kind == 'vine':      # Vine Whip: one vine lash (faces right): a long tapering green vine in an S curve, a little leaf pair at the root
        n = 40
        pts = [(1 + i * 0.74, 17 + 8.5 * math.sin(i / n * math.pi * 2.0 + 0.4) * (0.55 + 0.45 * i / n)) for i in range(n)]
        for k, ((x0, y0), (x1, y1)) in enumerate(zip(pts, pts[1:])):
            t = k / n; w = 4.6 - 2.6 * t
            c.line(x0, y0, x1, y1, w + 1.8, 5)
        for k, ((x0, y0), (x1, y1)) in enumerate(zip(pts, pts[1:])):
            t = k / n; w = 4.6 - 2.6 * t
            c.line(x0, y0, x1, y1, w, 2)
        for k, ((x0, y0), (x1, y1)) in enumerate(zip(pts, pts[1:])):
            if k < n - 6: c.line(x0, y0 - 0.9, x1, y1 - 0.9, 0.9, 3)
        c.poly([(2, 16), (6, 8), (9, 15)], 2); c.poly([(3, 19), (7, 27), (10, 20)], 2)
        c.line(3, 15, 6, 10, 0.9, 3); c.line(4, 20, 7, 25, 0.9, 3)
    elif kind == 'dragon':    # Dragon Rage: the Gen-3 dragon (Salamence) - its whole body outline, flying right, redrawn in yellow with a furious red eye
        rows = [
            '................................',
            '................................',
            '................................',
            '......................1.........',
            '......................12........',
            '................1555..122.......',
            '..............15555...11555.....',
            '............1555511...121552....',
            '...........155511555121335552...',
            '..........15511555512321311552..',
            '.........1551555511233223234231.',
            '........1551555511233222234332..',
            '........55155551123321122122....',
            '.......15155555122332112........',
            '......151555555523321...........',
            '......151555555233311...........',
            '......51555555223332............',
            '......11555112222332............',
            '.....115511222222232............',
            '.....155112222221232............',
            '.....151122222331232............',
            '....1551223322211222............',
            '....1152122332..12322...........',
            '...13222122221....222...........',
            '...23221122221..................',
            '...2221..2242...................',
            '..2321....1231..................',
            '.1221.......1...................',
            '.121............................',
            '.12.............................',
            '..1.............................',
            '................................',
        ]
        for y, r in enumerate(rows):
            for x, ch in enumerate(r):
                if ch != '.': c.px(x, y, int(ch))
        c.outline()
        c.px(25, 9, 6); c.px(26, 9, 6); c.px(24, 8, 1); c.px(25, 8, 1); c.px(26, 8, 1)
    elif kind == 'bubbles':   # Bubble: a heap of small bubbles
        bs = [(6, 7, 3), (15, 5, 2.4), (24, 8, 3.2), (10, 15, 2.6), (20, 15, 3.4), (29, 18, 2.2), (5, 24, 3), (14, 25, 3.4), (24, 27, 2.6), (30, 5, 1.8), (2, 15, 1.8)]
        for bx, by, r in bs: c.ell(bx, by, r + 0.6, r + 0.6, 5)
        for bx, by, r in bs: c.ell(bx, by, r, r, 2)
        for bx, by, r in bs: c.ell(bx - r * 0.25, by - r * 0.25, r * 0.62, r * 0.62, 3)
        for bx, by, r in bs: c.px(int(bx - r * 0.45), int(by - r * 0.5), 4)
    elif kind == 'ring':      # Water Pulse: a ring of water seen edge-on (faces right)
        c.ell(16, 16, 8.5, 14.5, 5); c.ell(16, 16, 7, 13, 2); c.ell(16, 16, 3.8, 10.2, 0); c.ell(17, 16, 2.2, 8.2, 0)
        c.ring(16, 16, 14.5, 12.5, 3, lambda x, y: x < 15 and y < 18)
        c.line(11, 6, 12, 10, 1.4, 4)
        for ex, ey in ((8, 22), (10, 26), (25, 8)): c.ell(ex, ey, 1.2, 1.2, 4)
    elif kind == 'fall':      # Waterfall: a column of falling water with foam on top and a splash at the foot
        for y in range(2, 30):
            j = 1 if (y // 3) % 2 else 0
            c.rect(8 + j, y, 23 - j, y, 2)
        for x, y0, y1 in ((11, 4, 20), (15, 8, 27), (19, 3, 16), (21, 12, 26)): c.line(x, y0, x, y1, 1.4, 3)
        for x, y0, y1 in ((13, 6, 14), (18, 14, 24), (10, 18, 25)): c.line(x, y0, x, y1, 1, 4)
        c.line(8, 4, 8, 28, 1.2, 5)
        c.ell(16, 3, 10.5, 3.2, 4); c.ell(16, 28, 13, 3.6, 4)
        for ex, ey in ((3, 25), (29, 26), (6, 21), (27, 21)): c.ell(ex, ey, 1.8, 1.8, 3)
    elif kind == 'dive':      # Dive: the arch of a leap out of the water with spray and ripples under it
        c.ring(16, 24, 14, 8, 5, lambda x, y: y < 24)
        c.ring(16, 24, 13, 9, 2, lambda x, y: y < 24)
        c.ring(16, 24, 12, 11, 3, lambda x, y: y < 22 and x < 17)
        for ex, ey in ((3, 14), (6, 7), (26, 8), (29, 15), (16, 8)): c.ell(ex, ey, 1.6, 1.6, 4)
        c.ell(16, 27, 14.5, 3.4, 5); c.ell(16, 27, 13, 2.4, 3); c.ell(16, 27, 8, 1.2, 4)
    elif kind == 'burst':
        for y in (7, 13, 19, 25): c.line(0, y, 11, y, 1, 3)
        c.ell(21, 16, 9, 9, 2); c.ell(19, 14, 4, 4, 3); c.ell(18, 13, 2, 2, 4)
        c.poly(star_pts(21, 16, 13, 7, 8), 3) if False else None
    elif kind == 'coil':
        c.ring(16, 16, 14, 8, 2); c.ring(16, 16, 14, 12, 3, lambda x, y: x + y < 24); c.ring(16, 16, 9, 8, 5)
    elif kind == 'quake':
        pts = [(2, 17), (8, 9), (13, 21), (18, 10), (24, 22), (30, 14)]
        for (x0, y0), (x1, y1) in zip(pts, pts[1:]): c.line(x0, y0, x1, y1, 5, 5)
        for (x0, y0), (x1, y1) in zip(pts, pts[1:]): c.line(x0, y0, x1, y1, 2, 2)
        c.poly([(5, 26), (10, 24), (12, 29), (6, 30)], 3); c.poly([(21, 3), (26, 2), (27, 7), (22, 8)], 3)
    elif kind == 'acidwave':   # a low sheet of liquid on the ground, rippling surface, bubbles popping on top
        for x in range(32):
            top = 20 + int(round(2.2 * math.sin(x * 0.75) + 1.2 * math.sin(x * 1.7 + 1)))
            for y in range(top, 30): c.px(x, y, 2)
            c.px(x, top, 3); c.px(x, top + 1, 3 if x % 3 else 2)
            for y in range(27, 30): c.px(x, y, 5)
        for bx, by, r in ((5, 17, 2), (13, 15, 3), (22, 17, 2), (28, 19, 1.5)):
            c.ell(bx, by, r, r, 3); c.ell(bx, by, r - 1, r - 1, 4 if r >= 2 else 3)
        for x in (3, 10, 17, 25): c.px(x, 24, 4); c.px(x + 1, 25, 4)
        c.outline()
    elif kind == 'wave':
        c.rect(0, 20, 31, 30, 2)
        for cx, r in ((7, 8), (16, 10), (25, 8)): c.ell(cx, 20, r, r, 2)
        c.rect(0, 22, 31, 30, 2)
        for cx, cy in ((9, 14), (17, 11), (25, 15)): c.ell(cx, cy, 2, 2, 4)
        c.rect(0, 25, 31, 26, 5)
    elif kind == 'surf':      # side view of a breaking wave travelling to the right: long back slope, curling crest, foam
        back = [(0, 31), (0, 27), (5, 23), (10, 18), (15, 13), (20, 9), (25, 7), (29, 8), (31, 11), (30, 15), (27, 14), (24, 13), (22, 16), (23, 21), (26, 26), (31, 31)]
        c.poly(back, 2)
        c.poly([(0, 27), (5, 23), (10, 18), (15, 13), (20, 9), (25, 7), (24, 11), (19, 14), (13, 19), (7, 25), (0, 30)], 3)
        c.poly([(0, 31), (0, 29), (8, 27), (16, 27), (23, 25), (26, 26), (31, 31)], 5)
        c.poly([(20, 9), (25, 7), (29, 8), (31, 11), (30, 15), (27, 14), (25, 11), (22, 11)], 4)
        for fx, fy, r in ((17, 12, 1.5), (12, 17, 1.2), (7, 22, 1.2), (28, 20, 1.5), (30, 25, 1.2)): c.ell(fx, fy, r, r, 4)
    elif kind == 'tornado':   # funnel: wide spinning top, narrowing to the ground, banded
        for y in range(2, 31):
            hw = 14.5 - (y - 2) * 13.5 / 28
            cx = 16 + 2.2 * math.sin(y * 0.55)
            col = 3 if ((y + 1) // 3) % 2 == 0 else 2
            c.rect(int(round(cx - hw)), y, int(round(cx + hw)) - 1, y, col)
        c.ell(16, 4, 14, 3, 4)
        c.rect(10, 12, 14, 12, 4); c.rect(19, 18, 23, 18, 4); c.rect(13, 24, 16, 24, 4)
        for dx, dy in ((2, 8), (29, 14), (4, 20), (27, 6)): c.rect(dx, dy, dx + 1, dy, 5)
    elif kind == 'crater':    # top view of a hole in the ground: dirt rim, dark slope, deep centre, loose dirt
        c.ell(16, 18, 15.5, 10, 3)
        c.ell(16, 18, 13, 8, 2)
        c.ell(16, 19, 10, 6, 5)
        c.ell(16, 20, 6.5, 3.5, 1)
        for ex, ey in ((3, 13), (28, 12), (6, 25), (26, 26), (16, 6), (22, 8)): c.ell(ex, ey, 2, 1.5, 2)
    elif kind == 'firestar':   # the anime Fire Blast: the kanji 'dai' (大) written in flame - bar, stem and two legs, with flame tips
        strokes = [(1, 12, 30, 12), (16, 2, 16, 17), (16, 15, 3, 30), (16, 15, 29, 30)]
        for x0, y0, x1, y1 in strokes: c.line(x0, y0, x1, y1, 7, 5)
        for x0, y0, x1, y1 in strokes: c.line(x0, y0, x1, y1, 5, 2)
        for x0, y0, x1, y1 in strokes: c.line(x0, y0, x1, y1, 2.5, 3)
        c.ell(16, 13, 3, 3, 4)
        for ex, ey in ((1, 12), (30, 12), (16, 2), (3, 30), (29, 30)): c.ell(ex, ey, 2.2, 2.2, 3)
    elif kind == 'rings':
        c.ring(16, 16, 15, 12, 2); c.ring(16, 16, 10, 7, 3); c.ring(16, 16, 5, 2, 2); c.ell(16, 16, 1.5, 1.5, 4)
    elif kind == 'crystal':
        c.poly([(16, 1), (27, 12), (16, 31), (5, 12)], 3)
        c.poly([(16, 1), (27, 12), (16, 14)], 4); c.poly([(16, 14), (27, 12), (16, 31)], 2); c.poly([(16, 14), (5, 12), (16, 31)], 5)
    elif kind == 'sound':
        for r in (7, 12, 18): c.ring(2, 16, r + 2, r, 2, lambda x, y: x > 4)
        c.ell(3, 16, 3, 3, 3)
    elif kind == 'triangle':
        c.poly([(16, 2), (30, 28), (2, 28)], 2); c.poly([(16, 10), (24, 24), (8, 24)], 4); c.poly([(16, 15), (20, 22), (12, 22)], 3)
    elif kind == 'star':
        c.poly(star_pts(16, 16, 15, 6, 5), 3); c.poly(star_pts(16, 16, 9, 4, 5), 4)
    c.outline()
    return c

def blob(kind, mtype):
    main, light, shade = TYPE_COL.get(mtype, TYPE_COL[0])
    pal = [0, rgb555((24, 24, 32)), rgb555(main), rgb555(light), rgb555((255, 255, 255)), rgb555(shade)] + [0] * 10
    if kind == 'dragon':
        pal = [0, rgb555((112, 64, 0)), rgb555((248, 208, 24)), rgb555((255, 244, 150)), rgb555((255, 255, 255)), rgb555((228, 116, 16)), rgb555((232, 24, 16)), rgb555((136, 16, 24))] + [0] * 8
    if kind == 'firestar':      # exactly the colours of the game's flame sprite (red edge, orange body, yellow core)
        pal = [0, rgb555((152, 0, 0)), rgb555((248, 96, 16)), rgb555((248, 200, 32)), rgb555((255, 248, 176)), rgb555((240, 24, 8))] + [0] * 10
    if kind == 'acidwave':      # Acid: a flat sheet of liquid on the ground, in the colours of the game's own acid sprite (purple)
        pal = [0, rgb555((64, 0, 64)), rgb555((208, 0, 208)), rgb555((232, 160, 232)), rgb555((248, 248, 248)), rgb555((136, 0, 136))] + [0] * 10
    if kind == 'dclaw':       # Dragon Claw: yellow claws
        pal = [0, rgb555((120, 72, 0)), rgb555((248, 200, 16)), rgb555((255, 240, 120)), rgb555((255, 255, 224)), rgb555((200, 128, 8))] + [0] * 10
    if kind in ('orbs', 'vinebead'):        # greens: dark outline, bright body, pale highlight
        pal = [0, rgb555((16, 72, 24)), rgb555((72, 200, 56)), rgb555((184, 248, 140)), rgb555((255, 255, 240)), rgb555((40, 136, 40))] + [0] * 10
    if kind == 'amoeba':      # purple: dark outline, violet body, pale highlight, deep nucleus
        pal = [0, rgb555((56, 16, 88)), rgb555((152, 64, 200)), rgb555((216, 160, 248)), rgb555((255, 255, 255)), rgb555((104, 32, 144))] + [0] * 10
    if kind in ('ecg', 'bolt'):         # a bright electric yellow trace with a white core
        pal = [0, rgb555((96, 72, 0)), rgb555((248, 216, 24)), rgb555((255, 248, 160)), rgb555((255, 255, 255)), rgb555((200, 144, 8))] + [0] * 10
    SK = [rgb555((248, 208, 160)), rgb555((184, 136, 96)), rgb555((255, 238, 206))]
    if kind == 'fistfire':
        pal = [0, rgb555((72, 24, 8)), rgb555((248, 120, 16)), rgb555((255, 216, 64)), rgb555((255, 250, 210)), rgb555((216, 40, 8))] + SK + [0] * 7
    if kind == 'fistthunder':
        pal = [0, rgb555((88, 64, 0)), rgb555((248, 216, 32)), rgb555((255, 248, 160)), rgb555((255, 255, 255)), rgb555((216, 168, 8))] + SK + [0] * 7
    if kind == 'fistice':
        pal = [0, rgb555((24, 56, 136)), rgb555((120, 200, 248)), rgb555((196, 234, 255)), rgb555((255, 255, 255)), rgb555((72, 140, 216))] + SK + [0] * 7
    if kind == 'sludge':
        pal = [0, rgb555((56, 8, 80)), rgb555((168, 64, 208)), rgb555((228, 168, 250)), rgb555((255, 240, 255)), rgb555((108, 32, 148))] + [0] * 10
    if kind == 'bearclaw':
        pal = [0, rgb555((196, 196, 214)), rgb555((22, 22, 30)), rgb555((96, 96, 116)), rgb555((244, 240, 224)), rgb555((52, 52, 66))] + [0] * 10
    if kind == 'dbreath':
        pal = [0, rgb555((152, 88, 0)), rgb555((248, 200, 24)), rgb555((255, 238, 120)), rgb555((255, 255, 235)), rgb555((232, 140, 16))] + [0] * 10
    if kind in ('shoes2', 'shoering', 'shoes3'):
        pal = [0, rgb555((196, 196, 214)), rgb555((20, 20, 28)), rgb555((96, 96, 116)), rgb555((244, 240, 224)), rgb555((78, 78, 94))] + [0] * 10
    if kind == 'rollball':
        pal = [0, rgb555((40, 40, 60)), rgb555((200, 160, 80)), rgb555((250, 230, 170)), rgb555((255, 255, 255)), rgb555((140, 100, 40))] + [0] * 10
    if kind == 'jet':
        pal = [0, rgb555((16, 72, 176)), rgb555((56, 152, 248)), rgb555((152, 216, 255)), rgb555((255, 255, 255)), rgb555((32, 104, 216))] + [0] * 10
    cv = draw(kind)
    tiles = bytearray()
    for ty in range(4):
        for tx in range(4):
            for y in range(8):
                for x in range(0, 8, 2):
                    a = cv.p[ty * 8 + y][tx * 8 + x]; b = cv.p[ty * 8 + y][tx * 8 + x + 1]
                    tiles.append(a | (b << 4))
    return bytes([0, 2, 16, 0]) + struct.pack('<16H', *pal) + bytes(tiles)    # shape square, size 32x32, 16 tiles

KINDS = {}
def _set(kind, ids):
    for i in ids: KINDS[i] = kind
_set('fist', [1, 2, 3, 4, 5, 66, 68, 70, 117, 175, 183, 233, 264, 292, 325, 327])
_set('kick', [23, 24, 25, 26, 27, 67, 136, 167])
_set('fangs', [44, 242])
_set('claw', [232])
_set('dclaw', [337])
_set('jet', [56]); _set('orbs', [71, 72, 202]); _set('bolt', [84])
_set('wind', [13, 19, 143, 340]); _set('wing', [17, 211]); _set('tornado', [16]); _set('mound', [91]); _set('rubble', [222]); IMPACT = {91: 'crater'}; _set('firestar', [126]); _set('icegale', [59]); _set('bubbles', [145]); _set('ring', [352]); _set('fall', [127]); _set('dive', [291]); _set('bean', [58]); _set('leaf', [75]); _set('vinebead', [22]); _set('fistfire', [7]); _set('fistice', [8]); _set('fistthunder', [9]); _set('sludge', [188]); _set('amoeba', [228]); _set('dragon', [82]); _set('acidwave', [51]); _set('bearclaw', [23]); _set('shoes2', [24]); _set('shoering', [27]); _set('rollball', [205]); _set('shoes3', [167]); _set('dbreath', [225])
_set('burst', [29, 33, 34, 36, 37, 38, 64, 98, 130, 168, 185, 216, 231, 251, 252, 282])
_set('coil', [20, 128, 132])
_set('quake', [89])
_set('wave', [330]); _set('surf', [57])
_set('rings', [93, 94, 101, 248, 295, 326, 353, 354])
FORCE = (23, 24, 27, 167, 225, 205, 7, 8, 9, 188, 228, 71, 72, 202, 84, 56, 337, 232, 57, 16, 91, 126, 17, 211, 58, 59, 89, 222, 145, 352, 127, 291, 75, 22, 82, 51)      # custom sprite even though the game has some graphics for it
_set('crystal', [329]); _set('sound', [304]); _set('triangle', [161]); _set('star', [290])

if __name__ == '__main__':
    import sys
    from itertools import count
    # preview sheet (needs PIL, only for development)
    from PIL import Image
    kinds = sorted(set(KINDS.values())); W = Image.new('RGB', (len(kinds) * 70, 70 * 3), (70, 70, 80))
    for r, t in enumerate((1, 10, 11)):
        for i, k in enumerate(kinds):
            b = blob(k, t); pal = struct.unpack_from('<16H', b, 4); til = b[36:]
            for ty in range(4):
                for tx in range(4):
                    for y in range(8):
                        for x in range(8):
                            v = til[(ty * 4 + tx) * 32 + y * 4 + x // 2]; v = (v >> 4) if x & 1 else v & 15
                            if v: cc = pal[v]; W.putpixel((i * 70 + 4 + tx * 8 + x, r * 70 + 4 + ty * 8 + y), ((cc & 31) * 8, ((cc >> 5) & 31) * 8, ((cc >> 10) & 31) * 8))
    W = W.resize((W.width * 2, W.height * 2), Image.NEAREST); W.save('/tmp/custom.png'); print(kinds)
