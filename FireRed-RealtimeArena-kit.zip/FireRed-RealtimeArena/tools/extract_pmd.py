#!/usr/bin/env python3
"""extract_pmd.py - Pokemon sprite/animation extractor for
Pokemon Mystery Dungeon - Red Rescue Team (GBA, game code B24E).

Usage (run it against YOUR OWN ROM dump):

    python3 -I extract_pmd.py ROM.gba SPECIES OUTDIR [options]
    python3 -I extract_pmd.py ROM.gba --list

SPECIES is a national dex number (1..386) by default; use --pmd to give PMD's
own internal species index (1..423, includes Unown letters, Castform forms,
Deoxys forms) instead.

Format summary (all of this was cross-checked against pret/pmd-red):

* "pksdir0" file archives: 8-byte magic "pksdir0\\0", s32 count, u32 ptr to an
  array of {char *name, void *data} pairs (GBA pointers 0x08xxxxxx).
  Monster archive: "ax001".."ax423" (sprites), "kaoNNN" (portraits), "palet".
  System archive: "monspara" (per-species data, 0x48 bytes/entry).
* Sprite file ("axNNN") data pointer -> "SIRO" + u32 ptr -> axmain (0x14 bytes):
    poses**   (array of ptr to pose list; pose = list of 10-byte OAM parts,
               terminated by sprite=-1, flags=0xFFFF)
    anims***  (anims[anim_id][direction] -> list of 12-byte frames, ends frames==0)
    animCount, sprites** (sprite id -> list of {ptr, byteCount} tile chunks,
    terminated by byteCount==0), positions*.
  Tile data is plain, UNCOMPRESSED 4bpp (GBA OBJ format, 1D mapping).
* Palettes: the monster archive's "palet" holds 14 shared 16-colour palettes of
  4 bytes/colour (R,G,B,0x80), 8-bit channels; species -> palette index is
  monspara[species].overworldPalette (byte at +8).

Only the Python standard library is required; PIL is used for PNG previews if
present (a small built-in PNG writer is the fallback).
"""
import hashlib
import json
import os
import struct
import sys
import zlib

ROM_BASE = 0x08000000
GAME_CODES = {b"B24E": "Red Rescue Team (USA/Australia)"}
KNOWN_MD5 = {"2100cf6f17e12cd34f1513647dfa506b": "Red Rescue Team (USA, Australia)"}

MONSPARA_ENTRY_SIZE = 0x48
MAX_PMD_SPECIES = 424          # MONSTER_MAX in the decomp (0 = none, 1..423)
TICKS_PER_SEC = 59.7275        # GBA frame rate; anim "frames" are game ticks

# PMD direction order, index 0..7 (include/constants/direction.h)
DIRECTIONS = ["S", "SE", "E", "NE", "N", "NW", "W", "SW"]

# Animation ids as used by the RRT game code (dungeon_mon_sprite_render.c).
# Names for ids the decomp doesn't name are filled in from inspection.
ANIM_NAMES = {
    0: "walk",
    1: "attack",
    5: "sleep",
    6: "hurt",
    7: "idle",
}
DEFAULT_ANIMS = ["walk", "attack", "idle", "hurt", "sleep"]

# GBA OBJ dimensions: shape (attr0 bits 14-15) -> size (attr1 bits 14-15) -> (w, h)
OBJ_SIZES = {
    0: [(8, 8), (16, 16), (32, 32), (64, 64)],
    1: [(16, 8), (32, 8), (32, 16), (64, 32)],
    2: [(8, 16), (8, 32), (16, 32), (32, 64)],
}
# frame canvases tried by --frame auto (smallest area that fits wins)
AUTO_FRAME_SIZES = [(32, 32), (64, 32), (32, 64), (64, 64)]

# sanity limits: the ROM is treated as untrusted input
MAX_POSES = 1024
MAX_PARTS = 64
MAX_ANIM_FRAMES = 512
MAX_CHUNKS = 64
MAX_TILES_PER_POSE = 1024


class RomError(Exception):
    pass


# ----------------------------------------------------------------------------
# ROM access
# ----------------------------------------------------------------------------
class Rom:
    def __init__(self, data, strict=True):
        if len(data) < 0x200000:
            raise RomError("file too small to be a GBA ROM")
        self.data = data
        self.size = len(data)
        self.code = bytes(data[0xAC:0xB0])
        self.md5 = hashlib.md5(data).hexdigest()
        self.title = bytes(data[0xA0:0xAC]).rstrip(b"\0").decode("latin1")
        if strict and self.code not in GAME_CODES:
            raise RomError(
                "game code %r is not a supported Red Rescue Team ROM (expected B24E); "
                "pass --force to try anyway" % self.code)

    def u8(self, o):
        if not 0 <= o < self.size:
            raise RomError("read out of range: 0x%X" % o)
        return self.data[o]

    def u16(self, o):
        if not 0 <= o <= self.size - 2:
            raise RomError("read out of range: 0x%X" % o)
        return struct.unpack_from("<H", self.data, o)[0]

    def s16(self, o):
        if not 0 <= o <= self.size - 2:
            raise RomError("read out of range: 0x%X" % o)
        return struct.unpack_from("<h", self.data, o)[0]

    def u32(self, o):
        if not 0 <= o <= self.size - 4:
            raise RomError("read out of range: 0x%X" % o)
        return struct.unpack_from("<I", self.data, o)[0]

    def ptr(self, o):
        """Read a GBA pointer at file offset o, return a FILE offset."""
        v = self.u32(o)
        return self.off(v)

    def off(self, addr):
        o = addr - ROM_BASE
        if not 0 <= o < self.size:
            raise RomError("bad ROM pointer 0x%08X" % addr)
        return o

    def cstr(self, o, maxlen=64):
        end = self.data.find(b"\0", o, o + maxlen)
        if end < 0:
            raise RomError("unterminated string at 0x%X" % o)
        return self.data[o:end].decode("latin1")

    def bytes_at(self, o, n):
        if n < 0 or o < 0 or o + n > self.size:
            raise RomError("range out of ROM: 0x%X+0x%X" % (o, n))
        return self.data[o:o + n]

    def unwrap_siro(self, o):
        """'SIRO' wrapper: 4 bytes magic + pointer to real data."""
        if self.data[o:o + 4] == b"SIRO":
            return self.ptr(o + 4)
        return o


def load_rom(path, strict=True):
    with open(path, "rb") as f:
        return Rom(f.read(), strict=strict)


# ----------------------------------------------------------------------------
# "pksdir0" archives
# ----------------------------------------------------------------------------
class Archive:
    def __init__(self, rom, base):
        self.rom = rom
        self.base = base
        count = rom.u32(base + 8)
        if not 0 < count <= 4096:
            raise RomError("bad archive count %d" % count)
        tab = rom.ptr(base + 12)
        self.entries = {}
        self.order = []
        for i in range(count):
            name = rom.cstr(rom.ptr(tab + 8 * i), 16)
            addr = rom.u32(tab + 8 * i + 4)
            self.entries[name] = addr
            self.order.append(name)

    def file_offset(self, name):
        """File offset of the entry's data (the SIRO wrapper is NOT stripped)."""
        return self.rom.off(self.entries[name])


def find_archives(rom):
    """Scan the ROM for valid 'pksdir0' archive headers (4-byte aligned)."""
    out = []
    i = 0
    d = rom.data
    while True:
        i = d.find(b"pksdir0\0", i)
        if i < 0:
            break
        if i % 4 == 0 and i + 16 <= rom.size:
            try:
                out.append(Archive(rom, i))
            except RomError:
                pass
        i += 1
    return out


# ----------------------------------------------------------------------------
# Monster data
# ----------------------------------------------------------------------------
class MonsterTable:
    """Parses monspara (species data) and the sprite archive of the ROM."""

    def __init__(self, rom):
        self.rom = rom
        archives = find_archives(rom)
        self.mon_arc = next((a for a in archives if "ax001" in a.entries), None)
        self.sys_arc = next((a for a in archives if "monspara" in a.entries), None)
        if self.mon_arc is None or self.sys_arc is None:
            raise RomError("could not locate the monster sprite archive / monspara")
        base = rom.unwrap_siro(self.sys_arc.file_offset("monspara"))
        self.species = {}
        for i in range(1, MAX_PMD_SPECIES):
            o = base + i * MONSPARA_ENTRY_SIZE
            try:
                name = rom.cstr(rom.ptr(o), 24)
            except RomError:
                break
            self.species[i] = {
                "pmd_index": i,
                "name": name,
                "palette": rom.u8(o + 8),
                "national": rom.s16(o + 0x3C),     # dexInternal[0]
                "internal": rom.s16(o + 0x3E),
            }
        self.ax = {}
        for n in self.mon_arc.order:
            if n.startswith("ax") and n[2:].isdigit():
                self.ax[int(n[2:])] = n
        pal_off = rom.unwrap_siro(self.mon_arc.file_offset("palet"))
        self.palettes_rgb = []
        for p in range(14):
            cols = []
            for c in range(16):
                r, g, b, _a = struct.unpack_from("4B", rom.bytes_at(pal_off + p * 64 + c * 4, 4))
                cols.append((r, g, b))
            self.palettes_rgb.append(cols)

    @staticmethod
    def national_to_pmd_formula(n):
        if n <= 201:
            return n
        if n <= 351:
            return n + 25
        return n + 28

    def pmd_for_national(self, n):
        """Lowest PMD species index whose dex number is n (alt forms come later)."""
        for i in sorted(self.species):
            if self.species[i]["national"] == n:
                return i
        return None

    def sprite_offset(self, pmd_index):
        return self.mon_arc.file_offset(self.ax[pmd_index])


def bgr555(rgb):
    r, g, b = rgb
    return ((b >> 3) << 10) | ((g >> 3) << 5) | (r >> 3)


# ----------------------------------------------------------------------------
# Sprite (ax) parsing
# ----------------------------------------------------------------------------
class Part:
    __slots__ = ("sprite", "f1", "f2", "f3", "x", "y", "w", "h", "hflip", "vflip",
                 "tile", "shape", "size", "pal", "own_pal")

    def __init__(self, sprite, f1, f2, f3):
        self.sprite, self.f1, self.f2, self.f3 = sprite, f1, f2, f3
        self.shape = f1 >> 14
        self.size = f2 >> 14
        if self.shape > 2:
            raise RomError("invalid OBJ shape")
        self.w, self.h = OBJ_SIZES[self.shape][self.size]
        # The game stores positions biased: x is 9 bits (-0x100), y is 10 bits (-0x200)
        self.x = (f2 & 0x1FF) - 0x100
        self.y = (f1 & 0x3FF) - 0x200
        self.hflip = bool(f2 & 0x1000)
        self.vflip = bool(f2 & 0x2000)
        self.tile = f3 & 0x3FF
        self.pal = f3 >> 12
        self.own_pal = bool(f2 & 0x400)     # unk6 bit1: keep the part's own palette


class Pose:
    def __init__(self, parts, tiles):
        self.parts = parts
        self.tiles = tiles           # bytes: concatenated uploaded chunks (4bpp tiles)


class AxFile:
    """One monster sprite file."""

    def __init__(self, rom, file_off):
        self.rom = rom
        am = rom.unwrap_siro(file_off)
        self.poses_tab = rom.ptr(am)
        self.anims_tab = rom.ptr(am + 4)
        self.anim_count = rom.u32(am + 8)
        self.sprites_tab = rom.ptr(am + 12)
        if not 0 < self.anim_count <= 64:
            raise RomError("implausible animation count %d" % self.anim_count)
        self.animations = []         # [anim_id][dir] -> list of frame dicts
        max_pose = -1
        for a in range(self.anim_count):
            dirs_tab = rom.ptr(self.anims_tab + 4 * a)
            per_dir = []
            for d in range(8):
                q = rom.ptr(dirs_tab + 4 * d)
                frames = []
                while True:
                    n, fl, pid, ox, oy, sx, sy = struct.unpack_from(
                        "<BBhbbbb", rom.bytes_at(q, 12))
                    if n == 0:
                        break
                    if len(frames) >= MAX_ANIM_FRAMES or not 0 <= pid < MAX_POSES:
                        raise RomError("corrupt animation data")
                    frames.append({"pose": pid, "ticks": n, "flags": fl,
                                   "dx": ox, "dy": oy, "shadow_dx": sx, "shadow_dy": sy})
                    max_pose = max(max_pose, pid)
                    q += 12
                per_dir.append(frames)
            self.animations.append(per_dir)
        self.pose_count = max_pose + 1
        self._pose_cache = {}

    def pose(self, pid):
        if pid in self._pose_cache:
            return self._pose_cache[pid]
        rom = self.rom
        q = rom.ptr(self.poses_tab + 4 * pid)
        parts = []
        blob = bytearray()
        while True:
            sprite, _u0, _u1, f1, f2, f3 = struct.unpack_from("<hbbHHH", rom.bytes_at(q, 10))
            if sprite == -1 and f1 == 0xFFFF:
                break
            if len(parts) >= MAX_PARTS:
                raise RomError("corrupt pose %d" % pid)
            parts.append(Part(sprite, f1, f2, f3))
            if sprite >= 0:
                # The game appends this sprite's tile chunks to VRAM at the running cursor.
                c = rom.ptr(self.sprites_tab + 4 * sprite)
                for _ in range(MAX_CHUNKS):
                    gfx_addr, nbytes = struct.unpack_from("<II", rom.bytes_at(c, 8))
                    if nbytes == 0:
                        break
                    if nbytes % 32 or nbytes > 0x8000:
                        raise RomError("bad tile chunk size")
                    if gfx_addr == 0:
                        blob += bytes(nbytes)      # NULL src = the game clears this VRAM range
                    else:
                        blob += rom.bytes_at(rom.off(gfx_addr), nbytes)
                    c += 8
                    if len(blob) > MAX_TILES_PER_POSE * 32:
                        raise RomError("pose tile data too large")
            q += 10
        p = Pose(parts, bytes(blob))
        self._pose_cache[pid] = p
        return p


# ----------------------------------------------------------------------------
# Rendering (indexed pixel buffers)
# ----------------------------------------------------------------------------
class Raster:
    """Palette-index raster (0 = transparent) placed at (x0, y0) in pose space."""

    def __init__(self, x0, y0, w, h):
        self.x0, self.y0, self.w, self.h = x0, y0, w, h
        self.px = bytearray(w * h)

    def opaque_bbox(self):
        w, h, px = self.w, self.h, self.px
        xs0, ys0, xs1, ys1 = w, h, -1, -1
        for y in range(h):
            row = px[y * w:(y + 1) * w]
            if any(row):
                xs0 = min(xs0, next(i for i, v in enumerate(row) if v))
                xs1 = max(xs1, w - 1 - next(i for i, v in enumerate(reversed(row)) if v))
                ys0 = min(ys0, y)
                ys1 = max(ys1, y)
        if ys1 < 0:
            return None
        return (self.x0 + xs0, self.y0 + ys0, self.x0 + xs1 + 1, self.y0 + ys1 + 1)


def part_pixels(tiles, part):
    """Decode a part to rows of palette indices, honouring flips (1D mapping)."""
    tw, th = part.w // 8, part.h // 8
    rows = [bytearray(part.w) for _ in range(part.h)]
    ntiles = len(tiles) // 32
    for ty in range(th):
        for tx in range(tw):
            t = part.tile + ty * tw + tx
            if t >= ntiles:
                continue
            base = t * 32
            for r in range(8):
                row = rows[ty * 8 + r]
                for c in range(4):
                    b = tiles[base + r * 4 + c]
                    row[tx * 8 + c * 2] = b & 15
                    row[tx * 8 + c * 2 + 1] = b >> 4
    if part.hflip:
        rows = [bytearray(reversed(r)) for r in rows]
    if part.vflip:
        rows.reverse()
    return rows


def render_pose(pose):
    if not pose.parts:
        return Raster(0, 0, 1, 1)
    x0 = min(p.x for p in pose.parts)
    y0 = min(p.y for p in pose.parts)
    x1 = max(p.x + p.w for p in pose.parts)
    y1 = max(p.y + p.h for p in pose.parts)
    r = Raster(x0, y0, x1 - x0, y1 - y0)
    # OAM entry 0 is drawn on top, so paint from the last part to the first.
    for part in reversed(pose.parts):
        rows = part_pixels(pose.tiles, part)
        for yy in range(part.h):
            base = (part.y - y0 + yy) * r.w + (part.x - x0)
            src = rows[yy]
            for xx in range(part.w):
                v = src[xx]
                if v:
                    r.px[base + xx] = v
    return r


def scale_raster_old(r, s, pal=None):
    """Shrink a raster about the pose origin by factor s (<1).  Each destination pixel takes the
    most common opaque colour of its source box (if the box is at least 35% opaque), which keeps
    thin features such as tails and whiskers."""
    import math
    nx0, ny0 = math.floor(r.x0 * s), math.floor(r.y0 * s)
    nx1, ny1 = math.ceil((r.x0 + r.w) * s), math.ceil((r.y0 + r.h) * s)
    out = Raster(nx0, ny0, max(1, nx1 - nx0), max(1, ny1 - ny0))
    for dy in range(out.h):
        sy0 = (ny0 + dy) / s - r.y0
        sy1 = (ny0 + dy + 1) / s - r.y0
        ya, yb = max(0, int(sy0)), min(r.h, max(int(sy0) + 1, int(math.ceil(sy1))))
        for dx in range(out.w):
            sx0 = (nx0 + dx) / s - r.x0
            sx1 = (nx0 + dx + 1) / s - r.x0
            xa, xb = max(0, int(sx0)), min(r.w, max(int(sx0) + 1, int(math.ceil(sx1))))
            cnt = {}; tot = 0
            for yy in range(ya, yb):
                row = r.px[yy * r.w:(yy + 1) * r.w]
                for xx in range(xa, xb):
                    tot += 1
                    v = row[xx]
                    if v:
                        cnt[v] = cnt.get(v, 0) + 1
            if cnt and sum(cnt.values()) * 100 >= 35 * tot:
                if pal is None:
                    out.px[dy * out.w + dx] = max(cnt, key=cnt.get)
                else:
                    # detail-preserving: dark outline pixels weigh more, mean colour snaps to the palette
                    sw = sr = sg = sb = 0.0
                    for v, c in cnt.items():
                        R, G, B = pal[v][:3]
                        w = c * (1.0 + 2.5 * (1.0 - (0.3 * R + 0.59 * G + 0.11 * B) / 255.0) ** 2)
                        sw += w; sr += w * R; sg += w * G; sb += w * B
                    mr, mg, mb = sr / sw, sg / sw, sb / sw
                    out.px[dy * out.w + dx] = min(cnt, key=lambda v: (pal[v][0] - mr) ** 2 + (pal[v][1] - mg) ** 2 + (pal[v][2] - mb) ** 2)
    return out



# ---- detail-preserving shrink (exact area coverage, outline-weighted colour, continuous outline) ----
import math
def scale_hq(r, s, pal=None, thr=0.40, dk=2.5):
    nx0, ny0 = math.floor(r.x0*s), math.floor(r.y0*s)
    nx1, ny1 = math.ceil((r.x0+r.w)*s), math.ceil((r.y0+r.h)*s)
    out = Raster(nx0, ny0, max(1,nx1-nx0), max(1,ny1-ny0))
    inv = 1.0/s
    cand=[(i,pal[i][:3]) for i in range(1,16) if i<len(pal)]
    # "eye" spots: a clearly lighter / more colourful source pixel enclosed by dark pixels survives the shrink
    def _lum(i): R,G,B=pal[i][:3]; return (0.3*R+0.59*G+0.11*B)
    def _sat(i): R,G,B=pal[i][:3]; return max(R,G,B)-min(R,G,B)
    W0,H0=r.w,r.h; spot=bytearray(W0*H0)
    for yy in range(1,H0-1):
        for xx in range(1,W0-1):
            v=r.px[yy*W0+xx]
            if not v or (_lum(v)<95 and _sat(v)<90): continue
            nd=0; nt=0
            for oy in (-1,0,1):
                for ox in (-1,0,1):
                    if ox==0 and oy==0: continue
                    q=r.px[(yy+oy)*W0+xx+ox]
                    if q:
                        nt+=1
                        if _lum(q)<80: nd+=1
            if nt>=7 and nd>=5: spot[yy*W0+xx]=1
    eyes=set()
    for dy in range(out.h):
        ya=(ny0+dy)*inv-r.y0; yb=(ny0+dy+1)*inv-r.y0
        for dx in range(out.w):
            xa=(nx0+dx)*inv-r.x0; xb=(nx0+dx+1)*inv-r.x0
            tot=0.0; cov=0.0; sw=sr=sg=sb=0.0; spc={}
            y=max(0,int(math.floor(ya)))
            while y<min(r.h,yb) :
                wy=min(yb,y+1)-max(ya,y)
                x=max(0,int(math.floor(xa)))
                while x<min(r.w,xb):
                    wx=min(xb,x+1)-max(xa,x)
                    w=wx*wy; tot+=w
                    v=r.px[y*r.w+x]
                    if v:
                        cov+=w
                        if spot[y*r.w+x]: spc[v]=spc.get(v,0.0)+w
                        R,G,B=pal[v][:3]
                        lum=(0.3*R+0.59*G+0.11*B)/255.0
                        ww=w*(1.0+dk*(1.0-lum)**2)
                        sw+=ww; sr+=ww*R; sg+=ww*G; sb+=ww*B
                    x+=1
                y+=1
            if tot<=0 or cov < thr*tot: continue
            if spc:
                sv=max(spc,key=spc.get)
                if spc[sv] >= 0.15*tot:
                    out.px[dy*out.w+dx]=sv; eyes.add((dx,dy)); continue
            mr,mg,mb=sr/sw,sg/sw,sb/sw
            best=min(cand,key=lambda c:(c[1][0]-mr)**2+(c[1][1]-mg)**2+(c[1][2]-mb)**2)
            out.px[dy*out.w+dx]=best[0]
    out.eyes=eyes
    return out

def scale_hq2(r, s, pal=None):
    out = scale_hq(r, s, pal, thr=0.34)
    # outline index: the darkest palette entry that appears on the source silhouette boundary
    def lum(i): R,G,B=pal[i][:3]; return 0.3*R+0.59*G+0.11*B
    W,H=r.w,r.h; cnt={}
    for y in range(H):
        for x in range(W):
            v=r.px[y*W+x]
            if not v: continue
            edge = x==0 or y==0 or x==W-1 or y==H-1 or not r.px[y*W+x-1] or not r.px[y*W+x+1] or not r.px[(y-1)*W+x] or not r.px[(y+1)*W+x]
            if edge: cnt[v]=cnt.get(v,0)+1
    dark=[i for i in cnt if lum(i)<70]
    if not dark: return out
    ol=max(dark,key=lambda i:cnt[i])
    ow,oh=out.w,out.h; px=out.px
    new=bytearray(px)
    for y in range(oh):
        for x in range(ow):
            if not px[y*ow+x]: continue
            edge = x==0 or y==0 or x==ow-1 or y==oh-1 or not px[y*ow+x-1] or not px[y*ow+x+1] or not px[(y-1)*ow+x] or not px[(y+1)*ow+x]
            if edge and (x,y) not in out.eyes and lum(px[y*ow+x])<150: new[y*ow+x]=ol
    out.px=new
    return out


def scale_raster(r, s, pal=None):
    if pal is None:
        return scale_raster_old(r, s, pal)
    return scale_hq2(r, s, pal)

def blit(canvas, cw, ch, ras, ox, oy):
    """Copy raster `ras` (pose space) into canvas whose top-left is (ox, oy) in pose space."""
    clipped = 0
    for y in range(ras.h):
        cy = ras.y0 + y - oy
        for x in range(ras.w):
            v = ras.px[y * ras.w + x]
            if not v:
                continue
            cx = ras.x0 + x - ox
            if 0 <= cx < cw and 0 <= cy < ch:
                canvas[cy * cw + cx] = v
            else:
                clipped += 1
    return clipped


def encode_4bpp_obj(canvas, cw, ch):
    """Encode a cw x ch index canvas as 4bpp tiles in row-major 1D OBJ order."""
    out = bytearray()
    for ty in range(ch // 8):
        for tx in range(cw // 8):
            for r in range(8):
                o = (ty * 8 + r) * cw + tx * 8
                for c in range(0, 8, 2):
                    out.append(canvas[o + c] | (canvas[o + c + 1] << 4))
    return bytes(out)


def obj_shape_size(w, h):
    for shape, lst in OBJ_SIZES.items():
        for size, wh in enumerate(lst):
            if wh == (w, h):
                return shape, size
    raise ValueError("not a GBA OBJ size: %dx%d" % (w, h))


# ----------------------------------------------------------------------------
# PNG output
# ----------------------------------------------------------------------------
def _png_fallback(path, w, h, rgba):
    def chunk(tag, data):
        c = struct.pack(">I", len(data)) + tag + data
        return c + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)
    raw = bytearray()
    for y in range(h):
        raw.append(0)
        raw += rgba[y * w * 4:(y + 1) * w * 4]
    with open(path, "wb") as f:
        f.write(b"\x89PNG\r\n\x1a\n")
        f.write(chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0)))
        f.write(chunk(b"IDAT", zlib.compress(bytes(raw), 9)))
        f.write(chunk(b"IEND", b""))


def save_png(path, w, h, rgba, labels=None):
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        _png_fallback(path, w, h, rgba)
        return
    im = Image.frombytes("RGBA", (w, h), bytes(rgba))
    if labels:
        d = ImageDraw.Draw(im)
        for (x, y, text) in labels:
            d.text((x, y), text, fill=(255, 255, 255, 255))
    im.save(path)


def make_sheet(rows, cell_w, cell_h, palette_rgb, scale=2, row_labels=None, origin=None):
    """rows: list of list of (index canvas | None). Returns (w, h, rgba, labels)."""
    ncols = max((len(r) for r in rows), default=1) or 1
    gut = 22 if row_labels else 0
    W = gut + ncols * cell_w * scale
    H = len(rows) * cell_h * scale
    buf = bytearray(W * H * 4)
    # background: two-tone checker so transparent pixels are obvious
    for y in range(H):
        for x in range(W):
            cell = ((x - gut) // 8 + y // 8) & 1
            v = 70 if cell else 90
            o = (y * W + x) * 4
            buf[o:o + 4] = bytes((v, v, v + 10, 255))
    pal = [(r, g, b, 255) for (r, g, b) in palette_rgb]
    for ri, row in enumerate(rows):
        for ci, cv in enumerate(row):
            x_base = gut + ci * cell_w * scale
            y_base = ri * cell_h * scale
            # cell border
            for k in range(cell_w * scale):
                for yy in (y_base, y_base + cell_h * scale - 1):
                    o = (yy * W + x_base + k) * 4
                    buf[o:o + 4] = b"\x30\x30\x40\xff"
            for k in range(cell_h * scale):
                for xx in (x_base, x_base + cell_w * scale - 1):
                    o = ((y_base + k) * W + xx) * 4
                    buf[o:o + 4] = b"\x30\x30\x40\xff"
            if cv is None:
                continue
            for y in range(cell_h):
                for x in range(cell_w):
                    v = cv[y * cell_w + x]
                    if not v:
                        continue
                    px = bytes(pal[v])
                    for sy in range(scale):
                        for sx in range(scale):
                            o = ((y_base + y * scale + sy) * W + x_base + x * scale + sx) * 4
                            buf[o:o + 4] = px
            if origin:
                ox, oy = origin
                for k in range(-2, 3):
                    for (xx, yy) in ((ox + k, oy), (ox, oy + k)):
                        if 0 <= xx < cell_w and 0 <= yy < cell_h:
                            o = ((y_base + yy * scale) * W + x_base + xx * scale) * 4
                            buf[o:o + 4] = b"\xff\x40\xff\xff"
    labels = []
    if row_labels:
        for ri, t in enumerate(row_labels):
            labels.append((2, ri * cell_h * scale + 2, t))
    return W, H, buf, labels


# ----------------------------------------------------------------------------
# Main extraction
# ----------------------------------------------------------------------------
def resolve_species(mt, species, pmd=False):
    if pmd:
        idx = species
        if idx not in mt.species or idx not in mt.ax:
            raise RomError("PMD species index %d has no sprite" % idx)
    else:
        if not 1 <= species <= 386:
            raise RomError("national dex number must be 1..386")
        idx = mt.pmd_for_national(species)
        if idx is None or idx not in mt.ax:
            raise RomError("national #%d is not present in this ROM" % species)
    return idx


def anim_name(aid):
    return ANIM_NAMES.get(aid, "anim%02d" % aid)


def parse_anim_selection(sel, anim_count):
    if sel is None:
        names = DEFAULT_ANIMS
    elif sel == "all":
        return list(range(anim_count))
    else:
        names = [s.strip() for s in sel.split(",") if s.strip()]
    inv = {v: k for k, v in ANIM_NAMES.items()}
    ids = []
    for n in names:
        if n.isdigit():
            ids.append(int(n))
        elif n in inv:
            ids.append(inv[n])
        elif n.startswith("anim") and n[4:].isdigit():
            ids.append(int(n[4:]))
        else:
            raise RomError("unknown animation %r" % n)
    return [i for i in ids if i < anim_count]


def extract_species(rom_or_path, species, outdir, pmd=False, anims=None,
                    frame="auto", previews=True, native=True, mt=None, multi=False):
    """Extract one species into outdir. Returns the info dict (also written as info.json)."""
    rom = rom_or_path if isinstance(rom_or_path, Rom) else load_rom(rom_or_path)
    mt = mt or MonsterTable(rom)
    idx = resolve_species(mt, species, pmd)
    sp = mt.species[idx]
    ax = AxFile(rom, mt.sprite_offset(idx))
    anim_ids = parse_anim_selection(anims, ax.anim_count)
    os.makedirs(outdir, exist_ok=True)

    pal_idx = sp["palette"]
    if pal_idx >= len(mt.palettes_rgb):
        raise RomError("palette index out of range")
    palette_rgb = mt.palettes_rgb[pal_idx]

    # --- 1. render every pose referenced by the selected animations ------------
    used = []
    for a in anim_ids:
        for d in range(8):
            for fr in ax.animations[a][d]:
                if fr["pose"] not in used:
                    used.append(fr["pose"])
    rasters = {pid: render_pose(ax.pose(pid)) for pid in used}
    bbox = None
    for r in rasters.values():
        b = r.opaque_bbox()
        if b:
            bbox = b if bbox is None else (min(bbox[0], b[0]), min(bbox[1], b[1]),
                                          max(bbox[2], b[2]), max(bbox[3], b[3]))
    if bbox is None:
        raise RomError("sprite is empty")
    uw, uh = bbox[2] - bbox[0], bbox[3] - bbox[1]
    if frame == "auto" and (uw > 64 or uh > 64) and not multi:
        # larger than the biggest GBA sprite (64x64): shrink every pose by the same factor
        sc = min(64.0 / uw, 64.0 / uh) * 0.98
        rasters = {pid: scale_raster(r, sc, palette_rgb) for pid, r in rasters.items()}
        bbox = None
        for r in rasters.values():
            b = r.opaque_bbox()
            if b:
                bbox = b if bbox is None else (min(bbox[0], b[0]), min(bbox[1], b[1]),
                                              max(bbox[2], b[2]), max(bbox[3], b[3]))
        uw, uh = bbox[2] - bbox[0], bbox[3] - bbox[1]

    # --- 2. choose the fixed frame canvas -------------------------------------
    bigmode = bool(multi and frame == "auto" and (uw > 64 or uh > 64))
    pcols = prows = 1
    if bigmode:                      # several 64x64 OBJs: the canvas starts at the top-left of the content
        pcols, prows = (uw + 63) // 64, (uh + 63) // 64
        fw, fh = pcols * 64, prows * 64
    elif frame == "auto":
        fits = [s for s in AUTO_FRAME_SIZES if s[0] >= uw and s[1] >= uh]
        fw, fh = min(fits, key=lambda s: s[0] * s[1]) if fits else (64, 64)
    else:
        fw, fh = frame
    if not bigmode:
        obj_shape_size(fw, fh)
    fits_all = fw >= uw and fh >= uh
    # canvas top-left in pose space; prefer origin at canvas (W/2, H/2), clamp to fit
    cx = -(fw // 2)
    cy = -(fh // 2)
    if bigmode:
        cx, cy = bbox[0], bbox[1]
    elif fits_all:
        cx = max(bbox[2] - fw, min(cx, bbox[0]))
        cy = max(bbox[3] - fh, min(cy, bbox[1]))
    origin = (-cx, -cy)       # canvas pixel that corresponds to the entity position

    # --- 3. composite frames (dedup identical canvases) -----------------------
    frames = []                # list of index canvases
    frame_of_pose = {}
    by_hash = {}
    clipped_px = 0
    for pid in used:
        canvas = bytearray(fw * fh)
        clipped_px += blit(canvas, fw, fh, rasters[pid], cx, cy)
        h = hashlib.sha1(canvas).digest()
        if h not in by_hash:
            by_hash[h] = len(frames)
            frames.append(canvas)
        frame_of_pose[pid] = by_hash[h]
    tiles_per_frame = (fw // 8) * (fh // 8)
    with open(os.path.join(outdir, "frames.4bpp"), "wb") as f:
        for c in frames:
            if bigmode:              # piece-major: each 64x64 piece is a separate OBJ (pieces in row-major order)
                for pr in range(prows):
                    for pc in range(pcols):
                        sub = bytearray()
                        for yy in range(64):
                            o = (pr * 64 + yy) * fw + pc * 64
                            sub += c[o:o + 64]
                        f.write(encode_4bpp_obj(sub, 64, 64))
            else:
                f.write(encode_4bpp_obj(c, fw, fh))

    # --- 4. palettes ----------------------------------------------------------
    pal_words = [bgr555(c) for c in palette_rgb]
    with open(os.path.join(outdir, "palette.pal"), "wb") as f:
        f.write(struct.pack("<16H", *pal_words))
    with open(os.path.join(outdir, "palettes_all.pal"), "wb") as f:
        for p in mt.palettes_rgb:
            f.write(struct.pack("<16H", *[bgr555(c) for c in p]))

    # --- 5. animation lists ---------------------------------------------------
    shape, size = (0, 3) if bigmode else obj_shape_size(fw, fh)
    anim_json = {}
    for a in anim_ids:
        per_dir = []
        for d in range(8):
            fl = []
            tot = 0
            for fr in ax.animations[a][d]:
                tot += fr["ticks"]
                fl.append({
                    "frame": frame_of_pose[fr["pose"]],
                    "pose": fr["pose"],
                    "ticks": fr["ticks"],
                    "ms": round(fr["ticks"] * 1000.0 / TICKS_PER_SEC, 1),
                    "dx": fr["dx"], "dy": fr["dy"],
                    "shadow_dx": fr["shadow_dx"], "shadow_dy": fr["shadow_dy"],
                    "flags": fr["flags"],
                })
            per_dir.append({"dir": DIRECTIONS[d], "dir_index": d,
                            "total_ticks": tot, "frames": fl})
        anim_json[anim_name(a)] = {"id": a, "directions": per_dir}

    # --- 6. native (exact, multi-OAM) pose export ------------------------------
    native_info = None
    if native:
        ndir = os.path.join(outdir, "native")
        os.makedirs(ndir, exist_ok=True)
        poses_json = []
        off_tiles = 0
        with open(os.path.join(ndir, "poses.4bpp"), "wb") as f:
            for pid in used:
                p = ax.pose(pid)
                f.write(p.tiles)
                parts = []
                for pt in p.parts:
                    attr0 = (pt.y & 0xFF) | (pt.shape << 14)
                    attr1 = (pt.x & 0x1FF) | (0x1000 if pt.hflip else 0) | \
                            (0x2000 if pt.vflip else 0) | (pt.size << 14)
                    attr2 = pt.tile | (3 << 10)       # priority 3, palette bank 0
                    parts.append({"x": pt.x, "y": pt.y, "w": pt.w, "h": pt.h,
                                  "hflip": pt.hflip, "vflip": pt.vflip,
                                  "tile": pt.tile, "attr0": attr0, "attr1": attr1,
                                  "attr2": attr2, "own_palette": pt.own_pal,
                                  "palette": pt.pal if pt.own_pal else None})
                poses_json.append({"pose": pid, "frame": frame_of_pose[pid],
                                   "tile_offset": off_tiles,
                                   "tile_count": len(p.tiles) // 32, "parts": parts})
                off_tiles += len(p.tiles) // 32
        with open(os.path.join(ndir, "poses.json"), "w") as f:
            json.dump(poses_json, f, indent=1)
        native_info = {"files": ["native/poses.4bpp", "native/poses.json"],
                       "note": "per-pose tile blob + OAM parts; part x/y are relative to the "
                               "entity origin; tile indices are relative to the pose blob "
                               "(add your VRAM base); OAM attr words use x&0x1FF / y&0xFF"}

    # --- 7. info.json + previews ----------------------------------------------
    info = {
        "rom": {"title": rom.title, "code": rom.code.decode("latin1"), "md5": rom.md5},
        "species": {"national": sp["national"], "pmd_index": idx, "name": sp["name"],
                    "palette_index": pal_idx},
        "frame": {
            "width": fw, "height": fh, "tiles": tiles_per_frame,
            "bytes_per_frame": tiles_per_frame * 32,
            "frame_count": len(frames),
            "obj_shape": shape, "obj_size": size,
            "tile_order": "row-major, 8x8 tiles, 32 bytes/tile (4bpp, low nibble = left pixel); "
                          "use with OBJ 1D mapping and %dx%d OBJ" % (fw, fh),
            "origin_in_frame": list(origin),
            "pieces": [pcols, prows],
            "content_bbox_in_pose_space": list(bbox),
            "fits_without_clipping": fits_all and clipped_px == 0,
            "clipped_pixels": clipped_px,
        },
        "palette": {"file": "palette.pal", "format": "16 x u16 little-endian BGR555; index 0 transparent",
                    "bgr555": ["0x%04X" % w for w in pal_words],
                    "all_palettes_file": "palettes_all.pal (14 palettes)"},
        "tick_rate_hz": TICKS_PER_SEC,
        "directions": DIRECTIONS,
        "animations": anim_json,
        "native": native_info,
    }
    with open(os.path.join(outdir, "info.json"), "w") as f:
        json.dump(info, f, indent=1)

    if previews:
        pal_preview = [(255, 0, 255)] + list(palette_rgb[1:])
        for a in anim_ids:
            rows = []
            labels = []
            for d in range(8):
                rows.append([frames[frame_of_pose[fr["pose"]]] for fr in ax.animations[a][d]])
                labels.append(DIRECTIONS[d])
            if not any(rows):
                continue
            W, H, buf, lab = make_sheet(rows, fw, fh, pal_preview, scale=2,
                                        row_labels=labels, origin=origin)
            save_png(os.path.join(outdir, "preview_%s.png" % anim_name(a)), W, H, buf, lab)
        # palette swatch
        sw = bytearray()
        for _ in range(16):
            for c in palette_rgb:
                sw += bytes((c[0], c[1], c[2], 255)) * 16
        row = bytes(sw)
        save_png(os.path.join(outdir, "preview_palette.png"), 256, 16, bytearray(row), None)
    return info


def list_species(rom_or_path):
    rom = rom_or_path if isinstance(rom_or_path, Rom) else load_rom(rom_or_path)
    mt = MonsterTable(rom)
    lines = []
    for n in range(1, 387):
        idx = mt.pmd_for_national(n)
        ok = idx is not None and idx in mt.ax
        lines.append((n, idx, mt.species[idx]["name"] if idx else "-", ok))
    return lines


def main(argv):
    import argparse
    ap = argparse.ArgumentParser(description="Extract sprites from PMD Red Rescue Team (B24E)")
    ap.add_argument("rom")
    ap.add_argument("species", nargs="?", type=int, help="national dex number (or PMD index with --pmd)")
    ap.add_argument("outdir", nargs="?")
    ap.add_argument("--pmd", action="store_true", help="species is a PMD internal index (1..423)")
    ap.add_argument("--anims", default=None,
                    help="comma list of names/ids, or 'all' (default: %s)" % ",".join(DEFAULT_ANIMS))
    ap.add_argument("--frame", default="auto", help="auto, or WxH GBA OBJ size such as 32x32, 64x64")
    ap.add_argument("--no-preview", action="store_true")
    ap.add_argument("--no-native", action="store_true")
    ap.add_argument("--list", action="store_true", help="list national dex -> PMD index mapping")
    ap.add_argument("--force", action="store_true", help="skip game-code check")
    a = ap.parse_args(argv)
    try:
        rom = load_rom(a.rom, strict=not a.force)
        if a.list:
            for n, idx, name, ok in list_species(rom):
                print("%3d  pmd=%3s  %-12s %s" % (n, idx, name, "ok" if ok else "MISSING"))
            return 0
        if a.species is None or a.outdir is None:
            ap.error("species and outdir are required")
        frame = "auto"
        if a.frame != "auto":
            w, h = a.frame.lower().split("x")
            frame = (int(w), int(h))
        info = extract_species(rom, a.species, a.outdir, pmd=a.pmd, anims=a.anims, frame=frame,
                               previews=not a.no_preview, native=not a.no_native)
    except (RomError, ValueError, KeyError) as e:
        print("error: %s" % e, file=sys.stderr)
        return 1
    fr = info["frame"]
    print("%s (national %d, pmd %d): %d frames of %dx%d (%d tiles), palette %d -> %s" % (
        info["species"]["name"], info["species"]["national"], info["species"]["pmd_index"],
        fr["frame_count"], fr["width"], fr["height"], fr["tiles"],
        info["species"]["palette_index"], a.outdir))
    if not fr["fits_without_clipping"]:
        print("warning: selected animations do not fit in the frame; see native/ for exact poses",
              file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
