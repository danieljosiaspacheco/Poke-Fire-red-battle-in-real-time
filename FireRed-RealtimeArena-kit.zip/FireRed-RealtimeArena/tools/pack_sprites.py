#!/usr/bin/env python3
"""pack_sprites.py - build the PMD sprite pack that the arena engine reads from ROM.

Takes the user's own Pokemon Mystery Dungeon - Red Rescue Team ROM, extracts the
sprites with extract_pmd.py and writes a compact binary pack (LZ77-compressed
frames, one record per national dex number).  Nothing from the ROM is shipped.

Pack layout (all little endian, offsets relative to the pack start unless noted):
  u32[512]  species table, index = national dex number, value = record offset (0 = none)
  records...

Species record (offsets inside the record are relative to the record start):
  u8  obj_shape, obj_size, nframes, tiles_per_frame
  u8  origin_x, origin_y, pad, pad
  u16 palette[16]               (BGR555)
  u32 frame_off[nframes]        (-> GBA LZ77 type-0x10 blob, 4-aligned)
  u16 anim_off[NANIMS][8]       (-> anim data, indexed [anim][dir], dir order S,SE,E,NE,N,NW,W,SW)
  anim data: u8 count, then count * {u8 frame, u8 ticks, s8 dx, s8 dy, u8 flags}
"""
import os, struct, sys, json, tempfile, shutil

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import extract_pmd as X
import overrides

# animation slots used by the engine
ANIM_SLOTS = [("walk", 0), ("attack", 1), ("shoot", 3), ("hurt", 6), ("sleep", 5)]
NANIMS = len(ANIM_SLOTS)


def lz77(data: bytes, vram: bool = False) -> bytes:
    """GBA BIOS LZ77 (type 0x10) compressor, greedy with hash chains."""
    n = len(data)
    out = bytearray(struct.pack("<I", 0x10 | (n << 8)))
    heads = {}
    chains = [0] * n
    pos = 0
    def insert(p):
        if p + 2 < n:
            k = data[p:p + 3]
            chains[p] = heads.get(k, -1)
            heads[k] = p
    while pos < n:
        flags = 0
        block = bytearray()
        for i in range(8):
            if pos >= n:
                break
            best_len, best_disp = 0, 0
            if pos + 2 < n:
                cand = heads.get(data[pos:pos + 3], -1)
                tries = 0
                while cand >= 0 and pos - cand <= 4096 and tries < 64:
                    if vram and pos - cand < 2:      # LZ77UnCompVram writes 16 bits at a time: no offset-1 copies
                        cand = chains[cand]
                        continue
                    l = 0
                    mx = min(18, n - pos)
                    while l < mx and data[cand + l] == data[pos + l]:
                        l += 1
                    if l > best_len:
                        best_len, best_disp = l, pos - cand
                        if l == mx:
                            break
                    cand = chains[cand]
                    tries += 1
            if best_len >= 3:
                flags |= 0x80 >> i
                block.append(((best_len - 3) << 4) | ((best_disp - 1) >> 8))
                block.append((best_disp - 1) & 0xFF)
                for k in range(best_len):
                    insert(pos + k)
                pos += best_len
            else:
                block.append(data[pos])
                insert(pos)
                pos += 1
        out.append(flags)
        out += block
    while len(out) % 4:
        out.append(0)
    return bytes(out)


def build_record(info, frames_blob, bpf):
    """Return the species record bytes (offsets relative to record start)."""
    nf = info["frame"]["frame_count"]
    fr = info["frame"]
    # dedupe identical frames
    uniq, remap = [], {}
    seen = {}
    for i in range(nf):
        chunk = frames_blob[i * bpf:(i + 1) * bpf]
        if chunk not in seen:
            seen[chunk] = len(uniq)
            uniq.append(chunk)
        remap[i] = seen[chunk]
    comp = [lz77(c) for c in uniq]

    pal = open(os.path.join(info["_dir"], "palette.pal"), "rb").read()[:32]
    pc, pr = fr.get("pieces", [1, 1])
    multi = pc * pr > 1
    assert 0 <= fr["origin_in_frame"][0] < 256 and 0 <= fr["origin_in_frame"][1] < 256, "origin out of range"
    head = struct.pack("<BBBBBBBB", fr["obj_shape"], fr["obj_size"], len(uniq), (min(255, fr["content_bbox_in_pose_space"][3] - fr["content_bbox_in_pose_space"][1]) if multi else fr["tiles"]),
                       fr["origin_in_frame"][0], fr["origin_in_frame"][1], pc if multi else 0, pr if multi else 0)
    head += pal
    frame_tab_off = len(head)
    head += b"\0" * (4 * len(uniq))
    anim_tab_off = len(head)
    head += b"\0" * (2 * NANIMS * 8)
    # anim data
    adata = bytearray()
    anim_offs = []
    fallback = None
    for slot, (name, aid) in enumerate(ANIM_SLOTS):
        a = info["animations"].get(name)
        if a is None:  # missing (e.g. no shoot anim): use attack, else walk
            a = info["animations"].get("attack") or info["animations"]["walk"]
        offs = []
        for d in range(8):
            frs = a["directions"][d]["frames"][:30]
            offs.append(len(head) + len(adata))
            adata.append(len(frs))
            for f in frs:
                adata += struct.pack("<BBbbB", remap[f["frame"]], min(f["ticks"], 255),
                                     max(-128, min(127, f["dx"])), max(-128, min(127, f["dy"])), f["flags"] & 0xFF)
        anim_offs.append(offs)
    while len(adata) % 4:
        adata.append(0)
    rec = bytearray(head) + adata
    # frames
    foffs = []
    for c in comp:
        foffs.append(len(rec))
        rec += c
    rec[frame_tab_off:frame_tab_off + 4 * len(uniq)] = struct.pack("<%dI" % len(uniq), *foffs)
    flat = [o for offs in anim_offs for o in offs]
    rec[anim_tab_off:anim_tab_off + 2 * len(flat)] = struct.pack("<%dH" % len(flat), *flat)
    return bytes(rec), len(uniq)


def pack(rom_path, species_list, out_path, verbose=True):
    rom = X.load_rom(rom_path)
    mt = X.MonsterTable(rom)
    tmp = tempfile.mkdtemp(prefix="pmdpack_")
    table = [0] * 512
    body = bytearray()
    base = 512 * 4
    total_frames = 0
    anims = ",".join(str(a) for _, a in ANIM_SLOTS)
    try:
        for n in species_list:
            d = os.path.join(tmp, str(n))
            try:
                info = X.extract_species(rom, n, d, anims=overrides.anim_list(n, anims), previews=False, native=False, mt=mt, multi=True)
                overrides.apply(info, d, n)
            except Exception as e:
                if verbose:
                    print("  skip %d: %s" % (n, e))
                continue
            info["_dir"] = d
            blob = open(os.path.join(d, "frames.4bpp"), "rb").read()
            bpf = info["frame"]["bytes_per_frame"]
            rec, nu = build_record(info, blob, bpf)
            while len(body) % 4:
                body.append(0)
            table[n] = base + len(body)
            body += rec
            total_frames += nu
            shutil.rmtree(d, ignore_errors=True)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    data = struct.pack("<512I", *table) + bytes(body)
    open(out_path, "wb").write(data)
    if verbose:
        print("packed %d species, %d unique frames, %.2f MB -> %s" % (
            sum(1 for t in table if t), total_frames, len(data) / 1e6, out_path))
    return data


if __name__ == "__main__":
    rom = sys.argv[1]
    out = sys.argv[2]
    lst = [int(x) for x in sys.argv[3].split(",")] if len(sys.argv) > 3 else list(range(1, 387))
    if len(sys.argv) > 4:
        overrides.set_firered(sys.argv[4])       # FireRed ROM: two-legged Zangoose
    pack(rom, lst, out)
