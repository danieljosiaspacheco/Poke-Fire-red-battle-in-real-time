import subprocess, os
from PIL import Image
HARNESS = os.environ.get("GBAHARNESS", "/home/claude/work/harness")
class Emu:
    def __init__(self, rom):
        self.p = subprocess.Popen([HARNESS, rom], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True, bufsize=1)
        assert self.p.stdout.readline().startswith("ready")
    def cmd(self, s):
        self.p.stdin.write(s + "\n"); self.p.stdin.flush()
        return self.p.stdout.readline().strip()
    def run(self, n): return self.cmd("run %d" % n)
    def arun(self, n, path): return self.cmd('arun %d %s' % (n, path))
    def keys(self, m): return self.cmd("keys %x" % m)
    def r8(self, a): return int(self.cmd("r8 %x" % a), 16)
    def r16(self, a): return int(self.cmd("r16 %x" % a), 16)
    def r32(self, a): return int(self.cmd("r32 %x" % a), 16)
    def w8(self, a, v): self.cmd("w8 %x %x" % (a, v))
    def w16(self, a, v): self.cmd("w16 %x %x" % (a, v))
    def w32(self, a, v): self.cmd("w32 %x %x" % (a, v))
    def rd(self, a, n): return bytes.fromhex(self.cmd("rd %x %d" % (a, n)))
    def pc(self): return int(self.cmd("pc"), 16)
    def save(self, path): return self.cmd("save " + path)
    def load(self, path): return self.cmd("load " + path)
    def shot(self, path, scale=2):
        self.cmd("shot /tmp/_shot.ppm")
        im = Image.open("/tmp/_shot.ppm")
        if scale != 1: im = im.resize((im.width * scale, im.height * scale), Image.NEAREST)
        im.save(path); return path
    def press(self, mask, frames=4, after=6):
        self.keys(mask); self.run(frames); self.keys(0); self.run(after)
    def close(self):
        try: self.p.stdin.write("quit\n"); self.p.stdin.flush()
        except Exception: pass
        self.p.wait(timeout=5)

def trap(emu, maxsteps=3000000):
    emu.p.stdin.write("trap %d\n" % maxsteps); emu.p.stdin.flush()
    out = [emu.p.stdout.readline().strip()]
    if "hit=1" in out[0]:
        for _ in range(48): out.append(emu.p.stdout.readline().strip())
    return out
