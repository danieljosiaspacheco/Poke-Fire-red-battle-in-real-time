import sys; sys.path.insert(0,'/home/claude/work/hack/tools')
from emu import Emu
PTR=0x3003520
def s32(v): return v-(1<<32) if v&0x80000000 else v
class Bot:
    def __init__(self, e): self.e=e
    @property
    def A(self): return self.e.r32(PTR)
    def act(self,i):
        e=self.e; b=self.A+12+172*i
        return dict(x=s32(e.r32(b))/256, y=s32(e.r32(b+4))/256, dir=e.r8(b+16), phase=e.r8(b+18), alive=e.r8(b+27), hp=s32(e.r16(b+46)<<16)>>16, maxhp=e.r16(b+48), status=e.r8(b+69))
    def state(self): return self.e.r8(self.A) if self.A else -1
    def step_toward(self, key_attack, maxframes=2000, log=None):
        e=self.e
        for f in range(maxframes):
            if self.A==0: return 'exited'
            st=self.state()
            if st>=3: return 'end'
            p=self.act(0); en=self.act(1)
            dx=en['x']-p['x']; dy=(en['y']-8)-(p['y']-8)
            keys=0
            if abs(dx)>20: keys |= 0x10 if dx>0 else 0x20
            if abs(dy)>14: keys |= 0x80 if dy>0 else 0x40
            if abs(dx)<=34 and abs(dy)<=34 and f%8==0: keys |= key_attack
            e.keys(keys); e.run(1)
            if log and f%log==0: print(f, p, en)
        e.keys(0); return 'timeout'
