#!/usr/bin/env python3
"""extract_movefx.py FIRERED.gba -> per-move effect sprite (tiles + palette) read from the game's own
battle-animation data (gBattleAnims_Moves scripts, sprite templates, pic/palette tables)."""
import struct, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import customfx

ANIM_TABLE = 0x1c68f4      # gBattleAnims_Moves (script pointer per move id)
PIC_TABLE = 0x3acc08       # gBattleAnimPicTable   {lz77 ptr, u16 size, u16 tag}
PAL_TABLE = 0x3ad510       # gBattleAnimPaletteTable {lz77 ptr, u16 tag, u16 pad}
NPIC = 289
NMOVES = 355

def lz77(d, off):
    assert d[off] == 0x10
    n = d[off+1] | d[off+2] << 8 | d[off+3] << 16
    out = bytearray(); p = off + 4
    while len(out) < n:
        f = d[p]; p += 1
        for i in range(8):
            if len(out) >= n: break
            if f & (0x80 >> i):
                a, b = d[p], d[p+1]; p += 2
                ln = (a >> 4) + 3; disp = ((a & 15) << 8 | b) + 1
                for _ in range(ln): out.append(out[-disp])
            else:
                out.append(d[p]); p += 1
    return bytes(out[:n])

SHAPE = [[(8,8),(16,16),(32,32),(64,64)], [(16,8),(32,8),(32,16),(64,32)], [(8,16),(8,32),(16,32),(32,64)]]

def load(rom):
    d = open(rom, 'rb').read()
    pics = {}; pals = {}
    for i in range(NPIC):
        ptr, size, tag = struct.unpack('<IHH', d[PIC_TABLE+8*i:PIC_TABLE+8*i+8])
        pics[tag] = (ptr - 0x8000000, size)
        ptr, tag, _ = struct.unpack('<IHH', d[PAL_TABLE+8*i:PAL_TABLE+8*i+8])
        pals[tag] = ptr - 0x8000000
    return d, pics, pals


IMPACT_TAGS = (0x2797, 0x279F)     # generic hit star / hands-and-feet
# sizes of the battle-animation script commands (opcode -> bytes); createsprite/createvisualtask are variable
OPSIZE = {0:3,1:3,4:2,5:1,6:1,7:1,8:1,9:3,0xA:2,0xB:2,0xC:3,0xD:1,0xE:5,0xF:1,0x10:4,0x11:9,0x12:4,0x13:5,0x14:7,
          0x15:2,0x17:1,0x19:4,0x1a:12,0x1b:7,0x1c:6,0x1d:2,0x1f:3,0x20:1,0x21:7,0x22:6,0x24:8,0x25:1,0x26:7,
          0x27:7,0x28:2,0x29:1,0x2a:2}

def templates(d, pics, pals):
    """tag -> [(shape,size,w,h,frames)] for every sprite template in the ROM whose graphics tag we know"""
    N = len(d); tm = {}
    for o in range(0x100000, N - 24, 4):
        tile, ptag = struct.unpack_from('<HH', d, o)
        if tile not in pics or ptag not in pals: continue
        oam, anims, imgs, aff, cb = struct.unpack_from('<5I', d, o + 4)
        lim = 0x8000000 + N
        if not (0x8000000 <= oam < lim and 0x8000000 <= anims < lim and 0x8000000 <= cb < lim and cb & 1): continue
        if not (imgs == 0 or 0x8000000 <= imgs < lim): continue
        if not (0x8000000 <= aff < lim): continue
        a0, a1, a2 = struct.unpack('<HHH', d[oam-0x8000000:oam-0x8000000+6])
        shape, sz = a0 >> 14, a1 >> 14
        if shape == 3: continue
        w, h = SHAPE[shape][sz]
        a = struct.unpack('<I', d[anims-0x8000000:anims-0x8000000+4])[0] - 0x8000000
        fr = []
        if 0 <= a < N - 128:
            for i in range(32):
                img, dur = struct.unpack_from('<hh', d, a + 4*i)
                if img < 0: break
                fr.append(img)
        tm.setdefault(tile, []).append((shape, sz, w, h, fr or [0], ptag))
    return tm

def script(d, m):
    """linear walk of a move's animation script -> (loaded gfx tags, [(template ptr)] of createsprite)"""
    o = struct.unpack('<I', d[ANIM_TABLE+4*m:ANIM_TABLE+4*m+4])[0] - 0x8000000
    loads, sprites = [], []
    if not (0 < o < len(d) - 700): return loads, sprites
    for _ in range(300):
        op = d[o]
        if op == 0:
            loads.append(struct.unpack('<H', d[o+1:o+3])[0]); o += 3
        elif op == 2:
            sprites.append(struct.unpack('<I', d[o+1:o+5])[0]); o += 7 + 2 * d[o+6]
        elif op == 3: o += 7 + 2 * d[o+6]
        elif op in OPSIZE:
            o += OPSIZE[op]
            if op in (8, 0xF): break
        else: break
    return loads, sprites

def opaque(seg):
    return sum(1 for b in seg for n in (b & 15, b >> 4) if n)

def make_blob(d, pics, pals, tag, shape, size, frames, ptag=None):
    w, h = SHAPE[shape][size]; nt = w * h // 64
    ptr, sz = pics[tag]
    sheet = lz77(d, ptr)
    best = None
    for img in frames:                       # image ids are tile offsets; keep the fullest frame
        seg = sheet[img*32:img*32 + nt*32]
        if len(seg) < nt*32: seg = seg + bytes(nt*32 - len(seg))
        sc = opaque(seg)
        if best is None or sc > best[0]: best = (sc, seg)
    seg = best[1]
    pal = lz77(d, pals[ptag if ptag in pals else tag])[:32]
    pal = pal + bytes(32 - len(pal))
    return bytes([shape, size, nt, 0]) + pal + seg

# hand-picked effects where the script-based choice is wrong: move -> (graphics tag, palette tag or None)
OVERRIDE = {84: (0x271b, None), 85: (0x271b, None), 87: (0x2735, 0x271b)}

def move_choice(d, pics, pals, tm, m):
    """-> (tag, shape, size, frames, ptag) of the effect that best represents move m, or None"""
    if m in OVERRIDE:
        tag, pt = OVERRIDE[m]
        for e in tm.get(tag, []):
            if e[2] <= 32 and e[3] <= 32: return tag, e[0], e[1], e[4], pt or e[5]
    loads, sprites = script(d, m)
    cand = []
    for t in sprites:                        # direct createsprite templates, in script order
        t -= 0x8000000
        if not (0x300000 <= t < len(d) - 24): continue
        tile, ptag, oam, anims = struct.unpack('<HHII', d[t:t+12])
        if tile not in pics or ptag not in pals or tile not in tm: continue
        if not (0x8000000 <= oam < 0x9000000): continue
        a0, a1, _ = struct.unpack('<HHH', d[oam-0x8000000:oam-0x8000000+6])
        shape, sz = a0 >> 14, a1 >> 14
        if shape == 3: continue
        w, h = SHAPE[shape][sz]
        for e in tm[tile]:
            if e[0] == shape and e[1] == sz: cand.append((tile, shape, sz, w, h, e[4], ptag)); break
    cand = [c for c in cand if c[0] not in IMPACT_TAGS and c[3] <= 32 and c[4] <= 32]
    if cand: return cand[0][0], cand[0][1], cand[0][2], cand[0][5], cand[0][6]
    best = None                              # effects made by script tasks: use the loaded graphics
    for tag in loads:
        if tag in IMPACT_TAGS or tag not in tm or tag not in pals: continue
        for e in tm[tag]:
            if e[2] <= 32 and e[3] <= 32:
                if best is None or e[2] * e[3] > best[0]: best = (e[2] * e[3], tag, e[0], e[1], e[4], e[5])
    return (best[1], best[2], best[3], best[4], best[5]) if best else None

def pack(rom):
    """returns the move-effect pack: u32 off[355*2] (main, impact; 0 = none) then blobs"""
    d, pics, pals = load(rom)
    tm = templates(d, pics, pals)
    blobs = {}; order = []
    def add(tag, shape, size, frames, ptag=None):
        k = (tag, shape, size, tuple(frames), ptag)
        if k not in blobs:
            blobs[k] = make_blob(d, pics, pals, tag, shape, size, frames, ptag); order.append(k)
        return k
    star = None
    for e in tm.get(0x2797, []):
        if e[2] <= 32 and e[3] <= 32: star = add(0x2797, e[0], e[1], e[4], e[5]); break
    hands = None
    for e in tm.get(0x279F, []):
        if e[2] <= 32 and e[3] <= 32: hands = add(0x279F, e[0], e[1], e[4], e[5]); break
    entries = []
    for m in range(NMOVES):
        ch = move_choice(d, pics, pals, tm, m) if m and m not in customfx.FORCE else None
        main = add(*ch) if ch else None
        if not main and m in customfx.KINDS:        # no graphics in the game for this move: use an original sprite
            mtype = d[0x250C04 + 12 * m + 2]
            main = ('custom', customfx.KINDS[m], mtype)
            if main not in blobs:
                blobs[main] = customfx.blob(customfx.KINDS[m], mtype); order.append(main)
        loads, _ = script(d, m) if m else ([], [])
        imp = hands if (0x279F in loads and 0x2797 not in loads) else star
        if m in customfx.IMPACT:                      # an original sprite for the impact slot (Dig: the crater)
            mtype = d[0x250C04 + 12 * m + 2]; imp = ('custom', customfx.IMPACT[m], mtype)
            if imp not in blobs:
                blobs[imp] = customfx.blob(customfx.IMPACT[m], mtype); order.append(imp)
        if m == 126: imp = entries[52][0]            # Fire Blast: the impact slot holds Ember's flame, drawn as the trail and the burst
        entries.append((main, imp if m else None))
    base = NMOVES * 2 * 4
    offs = {}; cur = base; body = bytearray()
    for k in order:
        offs[k] = cur; body += blobs[k]; cur += len(blobs[k])
    tab = bytearray()
    for a, b in entries:
        tab += struct.pack('<II', offs[a] if a else 0, offs[b] if b else 0)
    return bytes(tab + body)

if __name__ == '__main__':
    p = pack(sys.argv[1])
    print(len(p), 'bytes')
    if len(sys.argv) > 2: open(sys.argv[2], 'wb').write(p)
