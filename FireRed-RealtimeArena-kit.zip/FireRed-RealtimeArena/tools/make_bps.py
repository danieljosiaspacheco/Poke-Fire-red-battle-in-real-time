#!/usr/bin/env python3
"""make_bps.py SOURCE TARGET OUT.bps  - create a BPS (byuu) patch. Also: make_bps.py --apply SRC PATCH OUT
Needs numpy for speed. Linear (same-offset) diff + run-length via TargetCopy; plenty for this hack."""
import sys, zlib, struct
import numpy as np

def enc(n):
    o = bytearray()
    while True:
        x = n & 0x7F; n >>= 7
        if n == 0: o.append(0x80 | x); return o
        o.append(x); n -= 1

def make(src, tgt):
    out = bytearray(b"BPS1") + enc(len(src)) + enc(len(tgt)) + enc(0)
    s = np.frombuffer(src, np.uint8); t = np.frombuffer(tgt, np.uint8)
    n = len(t); m = min(len(s), n)
    # positions where target differs from source (same offset), or lies beyond source
    diff = np.ones(n, bool); diff[:m] = s[:m] != t[:m]
    # run starts for RLE detection in the "different" areas
    change = np.empty(n, bool); change[0] = True; change[1:] = t[1:] != t[:-1]
    starts = np.flatnonzero(change); ends = np.append(starts[1:], n)
    runs = [(int(a), int(b)) for a, b in zip(starts, ends) if b - a >= 8]   # long constant runs
    state = {"rel": 0}
    def src_read(l): out.extend(enc(((l - 1) << 2) | 0))
    def tgt_read(a, b):
        out.extend(enc(((b - a - 1) << 2) | 1)); out.extend(tgt[a:b])
    def tgt_copy(pos, l, frm):
        d = frm - state["rel"]
        out.extend(enc(((l - 1) << 2) | 3)); out.extend(enc((abs(d) << 1) | (1 if d < 0 else 0)))
        state["rel"] = frm + l
    # build list of segments over [0,n): 'same' (source read), 'lit', 'run'
    # first mark run areas that are NOT identical to source
    pos = 0
    dpos = np.flatnonzero(diff)           # all differing positions
    # iterate over differing regions
    i = 0; nd = len(dpos); ri = 0
    def emit_lit(a, b):
        # literal a..b, but pull out long runs inside
        nonlocal ri
        while ri < len(runs) and runs[ri][1] <= a: ri += 1
        j = ri; cur = a
        while j < len(runs) and runs[j][0] < b:
            ra, rb = max(runs[j][0], a), min(runs[j][1], b)
            if rb - ra >= 8:
                if ra > cur: tgt_read(cur, ra)
                tgt_read(ra, ra + 1); tgt_copy(ra + 1, rb - ra - 1, ra)
                cur = rb
            j += 1
        if cur < b: tgt_read(cur, b)
    while pos < n:
        if pos < m and not diff[pos]:
            # same region: find next diff
            k = np.searchsorted(dpos, pos)
            nxt = int(dpos[k]) if k < nd else n
            src_read(nxt - pos); pos = nxt
        else:
            # literal region until >= 12 identical bytes (only inside source range)
            k = np.searchsorted(dpos, pos); e = pos
            while True:
                # extend through consecutive diffs, merging gaps < 12
                kk = k
                last = int(dpos[kk]) if kk < nd else n
                # advance over contiguous block
                while kk + 1 < nd and dpos[kk + 1] - dpos[kk] < 12: kk += 1
                e = int(dpos[kk]) + 1 if kk < nd else n
                break
            emit_lit(pos, e); pos = e
    out.extend(struct.pack("<I", zlib.crc32(src) & 0xFFFFFFFF)); out.extend(struct.pack("<I", zlib.crc32(tgt) & 0xFFFFFFFF))
    out.extend(struct.pack("<I", zlib.crc32(bytes(out)) & 0xFFFFFFFF))
    return bytes(out)

def apply(src, patch):
    assert patch[:4] == b"BPS1"
    p = [4]
    def dec():
        v = 0; sh = 1
        while True:
            x = patch[p[0]]; p[0] += 1
            v += (x & 0x7F) * sh
            if x & 0x80: return v
            sh <<= 7; v += sh
    ss = dec(); ts = dec(); ms = dec(); p[0] += ms
    assert ss == len(src), "wrong source size"
    if zlib.crc32(src) & 0xFFFFFFFF != struct.unpack_from("<I", patch, len(patch) - 12)[0]: raise SystemExit("source crc mismatch")
    if zlib.crc32(patch[:-4]) & 0xFFFFFFFF != struct.unpack_from("<I", patch, len(patch) - 4)[0]: raise SystemExit("patch crc mismatch")
    out = bytearray(ts); o = 0; sr = 0; tr = 0; end = len(patch) - 12
    while p[0] < end:
        d = dec(); mode = d & 3; l = (d >> 2) + 1
        if mode == 0: out[o:o + l] = src[o:o + l]; o += l
        elif mode == 1: out[o:o + l] = patch[p[0]:p[0] + l]; p[0] += l; o += l
        else:
            v = dec(); off = (-1 if v & 1 else 1) * (v >> 1)
            if mode == 2:
                sr += off; out[o:o + l] = src[sr:sr + l]; sr += l; o += l
            else:
                tr += off
                for _ in range(l): out[o] = out[tr]; o += 1; tr += 1
    assert o == ts
    if zlib.crc32(out) & 0xFFFFFFFF != struct.unpack_from("<I", patch, len(patch) - 8)[0]: raise SystemExit("target crc mismatch")
    return bytes(out)

if __name__ == "__main__":
    if sys.argv[1] == "--apply":
        open(sys.argv[4], "wb").write(apply(open(sys.argv[2], "rb").read(), open(sys.argv[3], "rb").read()))
    else:
        open(sys.argv[3], "wb").write(make(open(sys.argv[1], "rb").read(), open(sys.argv[2], "rb").read()))
