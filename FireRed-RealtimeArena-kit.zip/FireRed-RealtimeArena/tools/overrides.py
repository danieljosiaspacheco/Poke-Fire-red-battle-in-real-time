"""overrides.py - species whose Mystery Dungeon sprites do not suit the arena / overworld; they are drawn from
FireRed's own graphics instead (needs the FireRed ROM: set_firered(path) - make_rom.py does it, and
pack_sprites.py / pack_follow.py take it as a trailing argument; without it the PMD sprites are kept).

* ICON species (Zangoose, Diglett, Dugtrio): the PMD walk animation is on four legs / only the trail of dirt (no head).
  They use the game's own party-menu icon (32x32, two-frame animation) in every direction.
* FRBIG species (large or detailed Pokemon that the PMD sprite renders blurry once shrunk into a 64x64 frame): the
  game's own 64x64 battle sprites (front view for most directions, back view for N / NE / NW), at original size.
"""
import os, struct

_FR = [None]
ICON = ()
FRBIG = ()
DIG = (50, 51)
FRONT_TAB, BACK_TAB, PAL_TAB, S2N = 0x82350AC, 0x823654C, 0x823730C, 0x251FEE
ICON_TAB, ICON_PAL_IDX, ICON_PAL_TAB = 0x3D37A0, 0x3D3E80, 0x3D4038
DIRX = [0, 2, 3, 2, 0, -2, -3, -2]
DIRY = [3, 2, 0, -2, -3, -2, 0, 2]


def set_firered(path):
    _FR[0] = open(path, "rb").read() if path and os.path.exists(path) else None


def anim_list(n, anims):
    """animation ids to extract for species n (comma separated string)"""
    if n in DIG:
        return anims + ",7"
    return anims


def _lz77(d, o):
    n = d[o + 1] | d[o + 2] << 8 | d[o + 3] << 16
    out = bytearray(); p = o + 4
    while len(out) < n:
        f = d[p]; p += 1
        for i in range(8):
            if len(out) >= n:
                break
            if f & (0x80 >> i):
                a, b = d[p], d[p + 1]; p += 2
                ln = (a >> 4) + 3; ds = ((a & 15) << 8 | b) + 1
                for _ in range(ln):
                    out.append(out[-ds])
            else:
                out.append(d[p]); p += 1
    return bytes(out)


def _px(buf, w=64, h=64):
    g = [[0] * w for _ in range(h)]
    tw = w // 8
    for t in range(tw * (h // 8)):
        tx, ty = t % tw, t // tw
        for y in range(8):
            for x in range(8):
                b = buf[t * 32 + y * 4 + x // 2]
                g[ty * 8 + y][tx * 8 + x] = (b >> 4) if x & 1 else b & 15
    return g


def _enc(g):
    out = bytearray()
    for ty in range(8):
        for tx in range(8):
            for r in range(8):
                for c in range(0, 8, 2):
                    out.append(g[ty * 8 + r][tx * 8 + c] | (g[ty * 8 + r][tx * 8 + c + 1] << 4))
    return bytes(out)


def _bbox(g):
    ys = [y for y, r in enumerate(g) if any(r)]
    xs = [x for x in range(len(g[0])) if any(r[x] for r in g)]
    return (min(xs), min(ys), max(xs) + 1, max(ys) + 1) if ys else None


def _internal(fr, nat):
    for i in range(411):
        if struct.unpack_from("<H", fr, S2N + 2 * i)[0] == nat:
            return i + 1
    return None


def _fr_art(fr, nat):
    """-> (palette bytes, [(front, back)] 64x64 grids) of the battle sprites"""
    sp = _internal(fr, nat)
    def pic(tab):
        ptr = struct.unpack_from("<I", fr, tab - 0x8000000 + 8 * sp)[0]
        return _px(_lz77(fr, ptr - 0x8000000))
    pptr = struct.unpack_from("<I", fr, PAL_TAB - 0x8000000 + 8 * sp)[0]
    return _lz77(fr, pptr - 0x8000000)[:32], pic(FRONT_TAB), pic(BACK_TAB)


def _fr_icon(fr, nat):
    """-> (palette bytes, [frame0, frame1]) of the party-menu icon (32x32 grids)"""
    sp = _internal(fr, nat)
    ptr = struct.unpack_from("<I", fr, ICON_TAB + 4 * sp)[0] - 0x8000000
    pi = fr[ICON_PAL_IDX + sp]
    pp = struct.unpack_from("<I", fr, ICON_PAL_TAB + 8 * pi)[0] - 0x8000000
    pal = bytes(fr[pp:pp + 32])
    return pal, [_px(fr[ptr + k * 512:ptr + (k + 1) * 512], 32, 32) for k in range(2)]


def _mir(g):
    return [list(reversed(r)) for r in g]


def _place(g, ybot, up=0):
    """centre the opaque part of grid g on a 64x64 canvas, feet at row ybot (clamped to the canvas)"""
    bb = _bbox(g)
    c = [[0] * 64 for _ in range(64)]
    ox = 32 - (bb[0] + bb[2]) // 2
    oy = min(64 - bb[3], max(-bb[1], ybot - bb[3])) - up
    for y in range(len(g)):
        for x in range(len(g[0])):
            if g[y][x] and 0 <= y + oy < 64 and 0 <= x + ox < 64:
                c[y + oy][x + ox] = g[y][x]
    return c


def _finish(d, info, pal, frames, nf=2):
    open(os.path.join(d, "frames.4bpp"), "wb").write(b"".join(_enc(f) for f in frames))
    open(os.path.join(d, "palette.pal"), "wb").write(pal)
    fi = info["frame"]
    fi.update({"width": 64, "height": 64, "tiles": 64, "bytes_per_frame": 2048, "obj_shape": 0, "obj_size": 3,
               "frame_count": len(frames), "origin_in_frame": [32, 32]})

    def anim(i, seq):
        return {"dir_index": i, "frames": [{"frame": nf * i + f, "pose": nf * i + f, "ticks": t, "dx": dx, "dy": dy, "flags": 0}
                                           for f, t, dx, dy in seq]}
    A = {}
    if nf == 4:
        A["walk"] = {"directions": [anim(i, [(0, 6, 0, 0), (1, 6, 0, 0), (2, 6, 0, 0), (3, 6, 0, 0)]) for i in range(8)]}
        A["attack"] = {"directions": [anim(i, [(0, 3, 0, 0), (1, 3, DIRX[i], DIRY[i]), (2, 4, DIRX[i], DIRY[i]), (0, 4, 0, 0)])
                                      for i in range(8)]}
        A["hurt"] = {"directions": [anim(i, [(1, 4, 0, 0), (0, 4, 1, 0), (3, 4, -1, 0), (0, 4, 0, 0)]) for i in range(8)]}
        A["sleep"] = {"directions": [anim(i, [(0, 30, 0, 0)]) for i in range(8)]}
        info["animations"] = A
        return
    info["animations"] = A


def _ybot(d, info):
    """lowest opaque row of the PMD frames, in the coordinates of a 64x64 frame whose origin is (32, 32)"""
    old = open(os.path.join(d, "frames.4bpp"), "rb").read()
    fi = info["frame"]
    bpf, w, h = fi["bytes_per_frame"], fi["width"], fi["height"]
    yb = 0
    for f in range(len(old) // bpf):
        bb = _bbox(_px(old[f * bpf:(f + 1) * bpf], w, h))
        if bb:
            yb = max(yb, bb[3])
    return 32 + yb - fi["origin_in_frame"][1]


def apply(info, d, nat):
    """replace what extract_species() wrote for species nat (info dict + files in d) where an override exists"""
    if nat in DIG:
        # PMD idle pose (head visible) replaces the walk/attack/hurt/sleep animations
        A = info["animations"]
        idle = A["idle"]
        for k in list(A):
            if k != "idle":
                A[k] = {"id": A[k].get("id"), "directions": [dict(dd) for dd in idle["directions"]]}
        return
    fr = _FR[0]
    if fr is None or (nat not in ICON and nat not in FRBIG):
        return
    yb = _ybot(d, info)
    frames = []
    if nat in ICON:
        pal, ic = _fr_icon(fr, nat)
        for i in range(8):                       # icons face left: mirror E / SE / NE
            m = i in (1, 2, 3)
            frames += [_place(_mir(g) if m else g, yb) for g in ic]
    else:
        pal, front, back = _fr_art(fr, nat)
        img = [front, _mir(front), _mir(front), _mir(back), back, back, front, front]       # S SE E NE N NW W SW
        for g in img:
            frames += [_place(g, yb), _place(g, yb, up=1)]
    _finish(d, info, pal, frames)
