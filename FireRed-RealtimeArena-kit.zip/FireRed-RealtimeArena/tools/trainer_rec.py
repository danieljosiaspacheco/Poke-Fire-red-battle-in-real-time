#!/usr/bin/env python3
"""trainer_rec.py - build arena sprite records for the player character (Red / Leaf)
from the overworld walking sprites of the user's own FireRed ROM (FireRed USA v1.0).
The record uses the same layout as the species records of pack_sprites.py."""
import struct
from pack_sprites import lz77

# overworld frame tables (8 bytes per entry: ptr, size) and palettes in FireRed v1.0
CHARS = {"red": (0x83A00A0, 0x835B968), "leaf": (0x83A0188, 0x835E968)}


def _hflip(tiles):
    """horizontally flip a 16x32 4bpp sprite stored as 2x4 tiles (1D order)."""
    px = [[0] * 16 for _ in range(32)]
    for t in range(8):
        tx, ty = t % 2, t // 2
        for y in range(8):
            for x in range(8):
                b = tiles[t * 32 + y * 4 + x // 2]
                px[ty * 8 + y][tx * 8 + x] = (b >> 4) if x & 1 else b & 15
    out = bytearray(256)
    for t in range(8):
        tx, ty = t % 2, t // 2
        for y in range(8):
            for x in range(8):
                c = px[ty * 8 + y][15 - (tx * 8 + x)]
                i = t * 32 + y * 4 + x // 2
                out[i] |= (c << 4) if x & 1 else c
    return bytes(out)


def build(rom, who):
    tab, pal = CHARS[who]
    o = lambda a: a - 0x8000000
    fr = [bytes(rom[o(struct.unpack_from("<I", rom, o(tab + 8 * i))[0]):][:256]) for i in range(9)]
    fr += [_hflip(fr[2]), _hflip(fr[7]), _hflip(fr[8])]   # 9 = E stand, 10/11 = E walk
    # facing per direction S,SE,E,NE,N,NW,W,SW -> (stand, walk1, walk2)
    D, U, L, R = (0, 3, 4), (1, 5, 6), (2, 7, 8), (9, 10, 11)
    face = [D, R, R, R, U, L, L, L]
    anims = []

    def walk(f):
        return [(f[0], 6, 0, 0, 0), (f[1], 6, 0, 0, 0), (f[0], 6, 0, 0, 0), (f[2], 6, 0, 0, 0)]

    def throw(f, d):
        dx = {0: 0, 1: 2, 2: 2, 3: 2, 4: 0, 5: -2, 6: -2, 7: -2}[d]
        dy = {0: 2, 4: -2}.get(d, 0)
        return [(f[0], 5, 0, 0, 0), (f[1], 6, dx, dy, 2), (f[2], 6, dx, dy, 0), (f[0], 5, 0, 0, 0)]

    def hurt(f):
        return [(f[0], 4, -1, 0, 0), (f[0], 4, 1, 0, 0)]

    def still(f):
        return [(f[0], 30, 0, 0, 0)]
    slots = [lambda f, d: walk(f), throw, throw, lambda f, d: hurt(f), lambda f, d: still(f)]
    head = struct.pack("<BBBBBBBB", 2, 2, 12, 8, 8, 29, 0, 0)
    head += b"".join(struct.pack("<H", struct.unpack_from("<H", rom, o(pal) + 2 * i)[0]) for i in range(16))
    ftab = len(head); head += b"\0" * 48
    atab = len(head); head += b"\0" * (2 * 5 * 8)
    adata = bytearray(); offs = []
    for s in slots:
        for d in range(8):
            offs.append(len(head) + len(adata))
            es = s(face[d], d)
            adata.append(len(es))
            for e in es:
                adata += struct.pack("<BBbbB", *e)
    while len(adata) % 4:
        adata.append(0)
    rec = bytearray(head) + adata
    fo = []
    for f in fr:
        fo.append(len(rec)); rec += lz77(f)
    rec[ftab:ftab + 48] = struct.pack("<12I", *fo)
    rec[atab:atab + len(offs) * 2] = struct.pack("<%dH" % len(offs), *offs)
    return bytes(rec)


def add_to_pack(pack, rom, slots=(509, 510)):
    pack = bytearray(pack)
    for sl, who in zip(slots, ("red", "leaf")):
        while len(pack) % 4:
            pack.append(0)
        struct.pack_into("<I", pack, 4 * sl, len(pack))
        pack += build(rom, who)
    return bytes(pack)
