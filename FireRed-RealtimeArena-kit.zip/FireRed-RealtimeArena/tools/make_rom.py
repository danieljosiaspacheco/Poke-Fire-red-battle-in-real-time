#!/usr/bin/env python3
"""make_rom.py - build the real-time arena ROM from YOUR OWN dumps.

  python3 make_rom.py FIRERED.gba PMD_RRT.gba OUT.gba [--species 1-386 | 1,4,7,25]
  python3 make_rom.py FIRERED.gba --sprites pack.bin OUT.gba     (reuse an existing sprite pack)

Needs: Pokemon FireRed (USA) v1.0 (BPRE rev 0) and, for sprites, Pokemon Mystery Dungeon - Red Rescue Team (USA).
The output ROM contains Nintendo data, so do not distribute it. Only this tool and the arena code are shareable.
"""
import sys, os, struct, hashlib, argparse
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

FR_MD5 = "e26ee0d44e809351c8ce2d73c7400cdd"   # FireRed (USA) 1.0
HOOK_OFFSET = 0x7F68C            # literal pool word of Task_BattleStart: CB2_InitBattle | 1
HOOK_ORIG = 0x0800FD9D
TOWER_HOOKS = (0x15BD54, 0x15E15C)    # literal pools of the Trainer Tower battle-start tasks (CB2_InitBattle | 1)
GUARD_TABLE = 0x13B890           # jump table entry 0 of the link key handler
CODE_OFF = 0x01000000            # bus 0x09000000
PACK_OFF = 0x01020000            # bus 0x09020000
FOLLOW_OFF = 0x01E00000          # bus 0x09E00000: overworld follower sprites (from the PMD ROM)
VENEER_OFF = 0xD0                # unused ROM header padding, reachable by a BL from the field loop
BUILD_OAM_CALL = 0x56592         # bl BuildOamBuffer in the field main loop (OverworldBasic)
BUILD_OAM = 0x08006BA8
STD_WILD_ENCOUNTER = 0x82CBC     # StandardWildEncounter(): random grass / cave / surf encounters (replaced by visible wild Pokemon)
FX_OFF = 0x01C00000              # bus 0x09C00000: move effect sprites taken from FireRed itself
CODE_MAX = PACK_OFF - CODE_OFF
ROM_SIZE = 0x02000000
LEARN_TABLE = 0x25D7B8            # gLevelUpLearnsets: u32 pointer per species -> u16 {move | level << 9}, 0xFFFF end
EVO_TABLE = 0x259754             # gEvolutionTable: 412 species x 5 entries x {u16 method, u16 param, u16 target, u16 pad}
BALL_OFF = FOLLOW_OFF - 0x800      # bus 0x09DFF800: the 12 Poke Ball sprites (tools/pack_balls.py), 12 x 160 bytes
ITEM_OFF = FOLLOW_OFF - 0x2000   # bus 0x09DFE000: u16[412][5] evolution items per species (0 = none)

def parse_species(s):
    out = []
    for part in s.split(","):
        if "-" in part:
            a, b = part.split("-"); out += list(range(int(a), int(b) + 1))
        else:
            out.append(int(part))
    return out

def bl(src, dst):
    off = dst - (src + 4)
    return struct.pack("<HH", 0xF000 | ((off >> 12) & 0x7FF), 0xF800 | ((off >> 1) & 0x7FF))

def install_veneer(rom, entry):
    """B500 push {lr}; bl BuildOamBuffer; call entry with lr = return label; pop {r0}; bx r0"""
    base = 0x08000000 + VENEER_OFF
    if bytes(rom[VENEER_OFF:VENEER_OFF + 28]) != b"\xff" * 28:
        sys.exit("veneer area is not free")
    code = struct.pack("<H", 0xB500) + bl(base + 2, BUILD_OAM)
    code += struct.pack("<HHHHHHH", 0x4803, 0x4903, 0x468E, 0x4700, 0xBC01, 0x4700, 0x46C0)
    code += struct.pack("<II", entry, (base + 14) | 1)
    assert len(code) == 28
    rom[VENEER_OFF:VENEER_OFF + 28] = code
    call = 0x08000000 + BUILD_OAM_CALL
    if bytes(rom[BUILD_OAM_CALL:BUILD_OAM_CALL + 4]) != bl(call, BUILD_OAM):
        sys.exit("field loop call site mismatch")
    rom[BUILD_OAM_CALL:BUILD_OAM_CALL + 4] = bl(call, base)

EVO_VENEER = 0xEC                # 16 free bytes in the header padding
EVO_CALL = 0x12673C              # bl BeginEvolutionScene in PartyMenuTryEvolution (Rare Candy / items in the party menu)
BEGIN_EVO = 0x080CDDA8

def install_evo_gate(rom, entry):
    """push {r4}; ldr r4,[lit]; mov ip,r4; pop {r4}; bx ip  -> EvoGate (keeps r0-r3 and lr)"""
    if bytes(rom[EVO_VENEER:EVO_VENEER + 16]) != b"\xff" * 16:
        sys.exit("evolution veneer area is not free")
    base = 0x08000000 + EVO_VENEER
    rom[EVO_VENEER:EVO_VENEER + 16] = struct.pack("<HHHHHHI", 0xB410, 0x4C02, 0x46A4, 0xBC10, 0x4760, 0x46C0, entry | 1)
    call = 0x08000000 + EVO_CALL
    if bytes(rom[EVO_CALL:EVO_CALL + 4]) != bl(call, BEGIN_EVO):
        sys.exit("BeginEvolutionScene call site mismatch")
    rom[EVO_CALL:EVO_CALL + 4] = bl(call, base)

def install_sailor(rom):
    """Vermilion harbour sailor (between the two pillars): the Seagallop / Aurora / Mystic ticket branch normally needs
    var 0x407E == 3 (S.S. Anne gone) and var 0x4076 >= 5 (story progress).  Both conditions become always-true
    (compare a variable with itself) so the ticket events can be started at any time."""
    chk = [(0x166943, bytes.fromhex("217e400300"), bytes.fromhex("227e407e40")),
           (0x16699B, bytes.fromhex("2176400500"), bytes.fromhex("2276407640"))]
    for off, old, new in chk:
        assert bytes(rom[off:off + 5]) == old, "unexpected script bytes at %#x" % off
        rom[off:off + 5] = new


def install_club(rom, fn):
    """Pokemon Center 2F attendants (Viridian map 5,5 and all others share the 3 call targets): the wireless 'adjustments' scripts
    are replaced by  callnative ClubEntry ; end  so the counter opens the real-time link screen"""
    SCR = 0xFFFF00                                     # free (0xFF) space at the end of the original ROM
    assert set(rom[SCR:SCR + 8]) == {0xFF}
    rom[SCR:SCR + 6] = b"\x23" + struct.pack("<I", fn | 1) + b"\x02"
    for t in (0x1BBA04, 0x1BBB6A, 0x1BBB9C):
        rom[t:t + 1] = b"\x05"                         # goto
        rom[t + 1:t + 5] = struct.pack("<I", 0x08000000 + SCR)

def install_ruin(rom, fn):
    """Ruin Valley (Dotted Hole): the door's script (reached by pressing A on it, map 2.121 tile 24,24) uses Cut on its own:
    already open -> the original 'door is open' text; otherwise a message and callnative RuinEntry (sets the flag, reloads the map)"""
    ORIG = 0x168B94
    if bytes(rom[ORIG:ORIG + 4]) != bytes.fromhex("692be302"):
        sys.exit("Ruin Valley door script mismatch")
    TXT, SCR = 0xFFFF40, 0xFFFF90
    assert set(rom[TXT:0xFFFFF0]) == {0xFF}
    def enc(t):                                          # '/' = new line, '|' = new paragraph
        out = bytearray()
        for ch in t:
            if ch == "/": out.append(0xFE)
            elif ch == "|": out.append(0xFB)
            elif ch.isupper(): out.append(0xBB + ord(ch) - 65)
            elif ch.islower(): out.append(0xD5 + ord(ch) - 97)
            elif ch == " ": out.append(0)
            elif ch == ".": out.append(0xAD)
            elif ch == "!": out.append(0xAB)
            else: raise ValueError(ch)
        return bytes(out + b"\xFF")
    txt = enc("There are dots on the door.|Your party used CUT!/The door opened!")
    rom[TXT:TXT + len(txt)] = txt
    scr = bytes.fromhex("692be302") + b"\x06\x01" + struct.pack("<I", 0x08168BC1)
    scr += b"\x0f\x00" + struct.pack("<I", 0x08000000 + TXT) + b"\x09\x04"
    # setflag door-open, setflag man-hidden, warp to the same tile (reloads the map: the map script opens the door), waitstate, end
    scr += bytes.fromhex("29e302" "298e00") + bytes([0x39, 2, 121, 0xFF]) + struct.pack("<HH", 24, 26) + bytes([0x27, 0x02])
    rom[SCR:SCR + len(scr)] = scr
    # the man standing in front of the door (object 0 of map 2.121, tile 24,25) talks -> the same script, so the door can be reached
    h = struct.unpack_from("<I", rom, struct.unpack_from("<I", rom, 0x3526A8 + 8)[0] - 0x08000000 + 4 * 121)[0] - 0x08000000
    op = struct.unpack_from("<I", rom, struct.unpack_from("<I", rom, h + 4)[0] - 0x08000000 + 4)[0] - 0x08000000
    assert struct.unpack_from("<hh", rom, op + 4) == (24, 25) and struct.unpack_from("<I", rom, op + 16)[0] == 0x08168B6D
    rom[op + 16:op + 20] = struct.pack("<I", 0x08000000 + SCR)
    rom[ORIG:ORIG + 1] = b"\x05"                       # goto
    rom[ORIG + 1:ORIG + 5] = struct.pack("<I", 0x08000000 + SCR)

def patch_pp(rom):
    """moves with 5 or 10 PP get 15"""
    for m in range(1, 355):
        o = 0x250C04 + 12 * m + 4
        if rom[o] in (5, 10): rom[o] = 15

def install_hms(rom, fn):
    """field moves without a Pokemon that knows them: script command 0x7C -> HmCheck, PartyHasMonWithSurf -> true"""
    slot = 0x15F9B4 + 4 * 0x7C
    if struct.unpack_from("<I", rom, slot)[0] != 0x0806C0A9:
        sys.exit("checkpartymove table entry mismatch")
    struct.pack_into("<I", rom, slot, fn | 1)
    if bytes(rom[0x5C83C:0x5C83E]) != b"\x30\xb5":
        sys.exit("PartyHasMonWithSurf mismatch")
    rom[0x5C83C:0x5C840] = b"\x01\x20\x70\x47"           # movs r0,#1 ; bx lr
    # the R button no longer opens the HELP system (it starts Fly, see FieldMoves in arena_f.c): the store of
    # "pressedRButton" in FieldGetPlayerInput becomes a nop
    if bytes(rom[0x6C9A4:0x6C9AC]) != b"\x68\x78\x01\x21\x08\x43\x68\x70":
        sys.exit("pressedRButton code mismatch")
    rom[0x6C9AA:0x6C9AC] = b"\xc0\x46"

def patch_evolutions(rom):
    """trade / item evolutions (Eevee and the multi-branch species keep their item evolutions) become level 36,
    friendship / beauty evolutions become level 22; the evolution items per species go to ITEM_OFF"""
    import struct as st
    if st.unpack_from("<HHH", rom, EVO_TABLE + 4 * 40) != (4, 16, 5):
        sys.exit("evolution table mismatch")
    items = bytearray(412 * 5 * 2)
    conv = {36: 0, 22: 0}
    for sp in range(1, 412):
        o = EVO_TABLE + sp * 40
        ents = [st.unpack_from("<HHHH", rom, o + k * 8) for k in range(5)]
        used = [(k, e) for k, e in enumerate(ents) if e[0]]
        cand = [e[1] for k, e in used if e[0] in (6, 7)]
        if sp == 133:                                        # Eevee: Potion -> Espeon, Antidote -> Umbreon (held item, in the arena code)
            cand += [13, 14]
            for k, e in used:
                if e[0] in (2, 3):
                    st.pack_into("<HHHH", rom, o + k * 8, 0, 0, 0, 0)       # no more friendship evolutions
        for j, it in enumerate(cand[:5]):
            st.pack_into("<H", items, (sp * 5 + j) * 2, it)
        if sp == 133:
            continue                                             # Eevee keeps its stones and friendship evolutions
        if len(used) != 1:
            continue
        k, e = used[0]
        if e[0] in (5, 6, 7):
            st.pack_into("<HH", rom, o + k * 8, 4, 36); conv[36] += 1
        elif e[0] in (1, 2, 3, 15):
            st.pack_into("<HH", rom, o + k * 8, 4, 22); conv[22] += 1
    rom[ITEM_OFF:ITEM_OFF + len(items)] = items
    import pack_balls
    balls, _ = pack_balls.pack(bytes(rom[:0x1000000]))
    assert ITEM_OFF + len(items) <= BALL_OFF and len(balls) <= 0x800 and set(rom[BALL_OFF:BALL_OFF + 0x800]) == {0xFF}
    rom[BALL_OFF:BALL_OFF + len(balls)] = balls
    # level evolutions after level 36 happen at 36; the evolved form learns its later moves that much earlier
    late = 0
    for sp in range(1, 412):
        o = EVO_TABLE + sp * 40
        for k in range(5):
            m, par, tgt, _ = st.unpack_from("<HHHH", rom, o + k * 8)
            if m != 4 or par <= 36 or not tgt:
                continue
            st.pack_into("<H", rom, o + k * 8 + 2, 36)
            shift = par - 36
            lp = st.unpack_from("<I", rom, LEARN_TABLE + tgt * 4)[0] - 0x08000000
            ents = []
            while True:
                e = st.unpack_from("<H", rom, lp + len(ents) * 2)[0]
                if e == 0xFFFF:
                    break
                ents.append(e)
            new = []
            for e in ents:
                lv = e >> 9
                if lv >= par:
                    lv -= shift
                new.append((lv, e & 0x1FF))
            new.sort(key=lambda x: x[0])                       # stable: equal levels stay together, in the original order
            for i, (lv, mv) in enumerate(new):
                st.pack_into("<H", rom, lp + i * 2, mv | (lv << 9))
            late += 1
    print("late level evolutions moved to 36: %d" % late)
    print("evolutions: %d -> level 36, %d -> level 22" % (conv[36], conv[22]))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("firered"); ap.add_argument("pmd", nargs="?"); ap.add_argument("out", nargs="?")
    ap.add_argument("--sprites"); ap.add_argument("--follow"); ap.add_argument("--species", default="1-386")
    ap.add_argument("--code", default=os.path.join(HERE, "..", "build", "arena.bin"))
    ap.add_argument("--force", action="store_true")
    a = ap.parse_args()
    if a.sprites:                       # firered --sprites pack.bin out
        out = a.pmd if a.out is None else a.out
        pmd = None
    else:
        pmd, out = a.pmd, a.out
    if not out:
        ap.error("need an output path")
    fr = bytearray(open(a.firered, "rb").read())
    md5 = hashlib.md5(fr).hexdigest()
    if (md5 != FR_MD5 or len(fr) != 0x1000000) and not a.force:
        sys.exit("This is not Pokemon FireRed (USA) v1.0 (md5 %s, expected %s). Use --force to try anyway." % (md5, FR_MD5))
    code = open(a.code, "rb").read()
    if len(code) > CODE_MAX:
        sys.exit("arena code too big")
    magic, entry, guard, follower, evogate, hmcheck, clubentry, ruinentry = struct.unpack_from("<IIIIIIII", code, 0)
    if magic != 0x414E5241:
        sys.exit("arena.bin has no header (rebuild it with build.sh)")
    if a.sprites:
        pack = open(a.sprites, "rb").read()
    else:
        import pack_sprites, overrides
        overrides.set_firered(a.firered)
        pack = pack_sprites.pack(pmd, parse_species(a.species), os.path.join(HERE, "..", "build", "sprites.bin"))
    import trainer_rec                  # player character sprites (Safari), from FireRed itself
    pack = trainer_rec.add_to_pack(pack, bytes(fr))
    if CODE_OFF + CODE_MAX + len(pack) > ROM_SIZE:
        sys.exit("sprite pack too large (%d bytes)" % len(pack))
    rom = fr + b"\xff" * (ROM_SIZE - len(fr))
    rom[CODE_OFF:CODE_OFF + len(code)] = code
    rom[PACK_OFF:PACK_OFF + len(pack)] = pack
    if PACK_OFF + len(pack) > FX_OFF:
        sys.exit("sprite pack overlaps the move-effect area")
    import extract_movefx
    fx = extract_movefx.pack(a.firered)
    rom[FX_OFF:FX_OFF + len(fx)] = fx
    if FX_OFF + len(fx) > ITEM_OFF:
        sys.exit("move-effect pack overlaps the item table")
    # ---- overworld follower: pack + veneer called right after BuildOamBuffer() ----
    follow = None
    if a.follow and os.path.exists(a.follow):
        follow = open(a.follow, "rb").read()
    elif pmd:
        import pack_follow, overrides
        overrides.set_firered(a.firered)
        follow = pack_follow.pack(pmd, range(1, 387))
    if follow and follower:
        if FOLLOW_OFF + len(follow) > ROM_SIZE:
            sys.exit("follower pack too large")
        rom[FOLLOW_OFF:FOLLOW_OFF + len(follow)] = follow
        install_veneer(rom, follower | 1)
        if bytes(rom[STD_WILD_ENCOUNTER:STD_WILD_ENCOUNTER + 2]) != b"\xf0\xb5":
            sys.exit("StandardWildEncounter mismatch")
        rom[STD_WILD_ENCOUNTER:STD_WILD_ENCOUNTER + 4] = b"\x00\x20\x70\x47"      # movs r0,#0 ; bx lr  (never triggers)
    cur = struct.unpack_from("<I", rom, HOOK_OFFSET)[0]
    if cur != HOOK_ORIG:
        sys.exit("hook point mismatch: found %08x" % cur)
    struct.pack_into("<I", rom, HOOK_OFFSET, entry | 1)
    # the Trainer Tower starts its battles from its own tasks (trainer_tower.c), not through Task_BattleStart: hook those literals too
    for off in TOWER_HOOKS:
        if struct.unpack_from("<I", rom, off)[0] != HOOK_ORIG:
            sys.exit("Trainer Tower hook point mismatch at %x" % off)
        struct.pack_into("<I", rom, off, entry | 1)
    # state 0 of the link/wireless L-R key handler (jump table at 0x0813B890) -> LinkKeyGuard
    if struct.unpack_from("<I", rom, GUARD_TABLE)[0] != 0x0813B8B4 and not a.force:
        sys.exit("link handler table mismatch")
    struct.pack_into("<I", rom, GUARD_TABLE, guard | 1)
    install_evo_gate(rom, evogate)
    install_hms(rom, hmcheck)
    install_sailor(rom)
    install_club(rom, clubentry)
    install_ruin(rom, ruinentry)
    patch_pp(rom)
    patch_evolutions(rom)
    open(out, "wb").write(rom)
    print("wrote %s  (code %d bytes, sprite pack %.2f MB, hook -> %08x)" % (out, len(code), len(pack) / 1e6, entry | 1))

if __name__ == "__main__":
    main()
