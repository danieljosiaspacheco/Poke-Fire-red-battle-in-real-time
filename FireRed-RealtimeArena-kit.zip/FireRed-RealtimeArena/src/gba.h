#ifndef GBA_H
#define GBA_H
typedef unsigned char u8; typedef signed char s8;
typedef unsigned short u16; typedef signed short s16;
typedef unsigned int u32; typedef signed int s32;
typedef volatile u16 vu16; typedef volatile u32 vu32;
#define NULL ((void*)0)

#define REG16(a) (*(volatile u16*)(a))
#define REG32(a) (*(volatile u32*)(a))
#define REG_DISPCNT  REG16(0x04000000)
#define REG_DISPSTAT REG16(0x04000004)
#define REG_BG0CNT   REG16(0x04000008)
#define REG_BG1CNT   REG16(0x0400000A)
#define REG_BG2CNT   REG16(0x0400000C)
#define REG_BG3CNT   REG16(0x0400000E)
#define REG_BG0HOFS  REG16(0x04000010)
#define REG_BG0VOFS  REG16(0x04000012)
#define REG_BG1HOFS  REG16(0x04000014)
#define REG_BG1VOFS  REG16(0x04000016)
#define REG_BG2HOFS  REG16(0x04000018)
#define REG_BG2VOFS  REG16(0x0400001A)
#define REG_BG3HOFS  REG16(0x0400001C)
#define REG_BG3VOFS  REG16(0x0400001E)
#define REG_WIN0H    REG16(0x04000040)
#define REG_WIN1H    REG16(0x04000042)
#define REG_WIN0V    REG16(0x04000044)
#define REG_WIN1V    REG16(0x04000046)
#define REG_WININ    REG16(0x04000048)
#define REG_WINOUT   REG16(0x0400004A)
#define REG_MOSAIC   REG16(0x0400004C)
#define REG_BLDCNT   REG16(0x04000050)
#define REG_BLDALPHA REG16(0x04000052)
#define REG_BLDY     REG16(0x04000054)
#define REG_DMA0CNT_H REG16(0x040000BA)
#define REG_DMA3SAD  REG32(0x040000D4)
#define REG_DMA3DAD  REG32(0x040000D8)
#define REG_DMA3CNT  REG32(0x040000DC)
#define REG_IE       REG16(0x04000200)
#define REG_IF       REG16(0x04000202)
#define REG_IME      REG16(0x04000208)

#define VRAM_BASE  0x06000000
#define OBJ_VRAM   0x06010000
#define PLTT_BASE  0x05000000
#define OBJ_PLTT   0x05000200
#define OAM_BASE   0x07000000

#define KEY_A 1
#define KEY_B 2
#define KEY_SELECT 4
#define KEY_START 8
#define KEY_RIGHT 16
#define KEY_LEFT 32
#define KEY_UP 64
#define KEY_DOWN 128
#define KEY_R 256
#define KEY_L 512

#define DMA_ENABLE 0x80000000
#define DMA_32BIT  0x04000000
#endif
