// arena_e.c - UI (pause/switch/learn/nickname), end-of-battle flow, trainers, entry points
#define POST ((Post *)((u8 *)gEnemyParty + 520))
typedef struct Post {
    u8 step, outcome, nick, lvlMask;
    void (*finalCb)(void);
    u8 nickBuf[12];
} Post;
void PostStep(void);
void ArenaMain(void);

static void Cat(char *d, const char *s) { int n = slen(d); scopy(d + n, s, 32 - n); }
static void CatNum(char *d, int v) { int n = slen(d); if (n < 30) { PutNum(d + n, v, 0); } }

static void EvPush(Arena *A, const char *s, int frames) {
    if (A->evN >= 16) return;
    Ev *e = &A->evq[A->evN++];
    e->type = EV_MSG; e->b = frames; scopy(e->text, s, 32);
}
static int EvBusy(Arena *A) {
    if (A->evT) { A->evT--; return 1; }
    if (A->evI < A->evN) {
        Ev *v = &A->evq[A->evI++];
        Msg(A, v->text, v->b); A->evT = v->b;
        return 1;
    }
    A->evN = A->evI = 0;
    return 0;
}

static void MonName(struct Pokemon *m, char *out) {   // ascii, <=11 chars
    u8 nm[12];
    GetMonData(m, MON_DATA_NICKNAME, nm);
    GameStr(nm, (u8 *)out, 11);
}

// ---------- party helpers ----------
static int OnField(Arena *A, int i) {
    for (int k = 0; k < 4; k += 2)
        if ((A->pm & (1 << k)) && !A->act[k].retired && A->act[k].partyIdx == i) return 1;
    return 0;
}
static int Switchable(Arena *A, int i) {
    if (i >= gPlayerPartyCount || i >= 6) return 0;
    struct Pokemon *m = &gPlayerParty[i];
    u16 sp = GetMonData(m, MON_DATA_SPECIES, 0);
    if (!sp || GetMonData(m, MON_DATA_SANITY_IS_EGG, 0)) return 0;
    if (OnField(A, i)) return 0;
    if (GetMonData(m, MON_DATA_HP, 0) == 0) return 0;
    return RecFor(SpeciesToNationalPokedexNum(sp)) != 0;
}
static int NextAlive(Arena *A) {
    for (int i = 0; i < 6; i++) if (Switchable(A, i)) return i;
    return -1;
}

static void SwitchIn(Arena *A, int idx, int slot) {
    Actor *p = &A->act[slot];
    s32 x = p->x, y = p->y;
    WriteBack(p);
    InitActor(A, p, &gPlayerParty[idx], 1, idx, slot);
    p->x = x; p->y = y; p->invuln = 90; p->flash = 30;
    A->pm |= 1 << slot;
    StartRelease(A, p, slot);
    A->partyUsedMask |= 1 << idx;
    char l[32]; l[0] = 0;
    Cat(l, "GO! "); Cat(l, (char *)p->name); Cat(l, "!");
    Msg(A, l, 90);
}

static void ReloadPlayer(Arena *A) {
    for (int k = 0; k < 4; k += 2) {
        Actor *p = &A->act[k];
        if (!(A->pm & (1 << k)) || p->retired || !p->alive) continue;
        if (GetMonData(p->mon, MON_DATA_HP, 0) == 0) continue;
        s32 x = p->x, y = p->y; int idx = p->partyIdx;
        InitActor(A, p, &gPlayerParty[idx], 1, idx, k);
        p->x = x; p->y = y; p->invuln = 60;
    }
}

static int HasRevive(void) { return CountTotalItemQuantityInBag(24) || CountTotalItemQuantityInBag(25); }
static int PlayersAlive(Arena *A) {
    int n = 0;
    for (int k = 0; k < 4; k += 2) if ((A->pm & (1 << k)) && A->act[k].alive) n++;
    return n;
}
static int FoesPending(Arena *A) {      // enemy actors still fighting or waiting to be processed
    int n = 0;
    for (int k = 1; k < 4; k += 2) if ((A->pm & (1 << k)) && !A->act[k].retired) n++;
    return n;
}

// ---------- bag items ----------
static const u8 *ItemFx(u16 id) { return ((id >= 13 && id <= 79) || (id >= 133 && id <= 175)) ? (const u8 *)gItemEffectTable[id - 13] : 0; }
static int ItemUsable(const u8 *fx) {
    if (!fx) return 0;
    return (fx[3] & 0xFF) || (fx[4] & 0x6F) || (fx[5] & 0x1F) || (fx[0] & 0x7F) || fx[1] || (fx[2] & 0xFF);
}
static int ItemNeedsMove(const u8 *fx) { return (fx[4] & 0x18) == 0x18 || (fx[4] & 0x20) || (fx[5] & 0x10); }
static int ItemNeedsMon(const u8 *fx) { return !((fx[0] & 0x40) && (fx[4] & 0x40)); }   // sacred ash hits the whole party
// bag pockets, the same five as the overworld bag (the item's own "pocket" field in gItems decides)
#define NPOCKET 5
#define POCKET_BALLS 2                                      // index of the Poke Balls pocket
static const char *const POCKET_NAME[NPOCKET] = {"ITEMS", "KEY ITEMS", "POKE BALLS", "TMS AND HMS", "BERRIES"};
static void BuildBag(Arena *A) {
    int n = 0;
    for (u16 id = 1; id < 375 && n < 64; id++) {
        if (gItems[(u32)id * 44 + 26] != A->bagTab + 1) continue;
        if (!CountTotalItemQuantityInBag(id)) continue;
        A->bagIds[n++] = id;
    }
    A->nbag = n;
    if (A->bagSel >= n) A->bagSel = n ? n - 1 : 0;
}
static Actor *FieldActor(Arena *A, int idx) {
    for (int k = 0; k < 4; k += 2)
        if ((A->pm & (1 << k)) && !A->act[k].retired && A->act[k].partyIdx == idx) return &A->act[k];
    return 0;
}
static void RefreshActor(Actor *a) {
    struct Pokemon *m = a->mon;
    a->level = GetMonData(m, MON_DATA_LEVEL, 0);
    a->hp = GetMonData(m, MON_DATA_HP, 0);
    a->maxHp = GetMonData(m, MON_DATA_MAX_HP, 0);
    a->stat[0] = GetMonData(m, MON_DATA_ATK, 0);
    a->stat[1] = GetMonData(m, MON_DATA_DEF, 0);
    a->stat[2] = GetMonData(m, MON_DATA_SPEED, 0);
    a->stat[3] = GetMonData(m, MON_DATA_SPATK, 0);
    a->stat[4] = GetMonData(m, MON_DATA_SPDEF, 0);
    for (int i = 0; i < 4; i++) a->pp[i] = GetMonData(m, MON_DATA_PP1 + i, 0);
    u8 old = a->status;
    a->status = StatusFromMon(GetMonData(m, MON_DATA_STATUS, 0));
    if (a->status == S_NONE) a->statusTimer = 0;
    else if (a->status == S_SLEEP && old != S_SLEEP) a->statusTimer = 120;
}
static int MaxPP(struct Pokemon *m, int i) {
    u16 mv = GetMonData(m, MON_DATA_MOVE1 + i, 0);
    if (!mv) return 0;
    int base = MV_PP(MV(mv));
    int b = (GetMonData(m, MON_DATA_PPBONUS, 0) >> (2 * i)) & 3;
    return base * (5 + b) / 5;
}
static void NumMsg(char *out, const char *a, int n, const char *b) {
    out[0] = 0; Cat(out, a); CatNum(out, n); Cat(out, b);
}
// returns 1 when the item had an effect (message in out); 0 = no effect
static int ApplyItem(Arena *A, u16 id, int idx, int mv, char *out) {
    const u8 *fx = ItemFx(id);
    struct Pokemon *m = &gPlayerParty[idx];
    Actor *a = FieldActor(A, idx);
    char nm[12]; MonName(m, nm);
    out[0] = 0;
    if (!GetMonData(m, MON_DATA_SPECIES, 0) || GetMonData(m, MON_DATA_SANITY_IS_EGG, 0)) return 0;
    if (a && !a->alive && !(fx[4] & 0x40)) return 0;
    if (a) WriteBack(a);
    int hp = GetMonData(m, MON_DATA_HP, 0), mx = GetMonData(m, MON_DATA_MAX_HP, 0), lv = GetMonData(m, MON_DATA_LEVEL, 0);
    u32 st = GetMonData(m, MON_DATA_STATUS, 0);
    int ok = 0;
    if (fx[3] & 0x40) {                                   // rare candy
        if (hp == 0 || lv >= 100) return 0;
        u16 sp = GetMonData(m, MON_DATA_SPECIES, 0);
        int rate = gBaseStats[(u32)sp * 28 + 19];
        u32 ex = gExperienceTables[rate * 101 + lv + 1];
        SetMonData(m, MON_DATA_EXP, &ex);
        u8 nl = lv + 1; SetMonData(m, MON_DATA_LEVEL, &nl);
        CalculateMonStats(m);
        if (!(A->lnMask & (1 << idx))) A->oldLv[idx] = lv;
        A->newLv[idx] = nl; A->lnMask |= 1 << idx; A->lvlMask |= 1 << idx;
        Cat(out, nm); Cat(out, " GREW TO LV"); CatNum(out, nl); Cat(out, "!");
        if (a) RefreshActor(a);
        return 1;
    }
    if (fx[4] & 0x40) {                                   // revive
        if (hp) return 0;
        int nh = fx[6] == 0xFF ? mx : mx / 2; if (nh < 1) nh = 1;
        u32 z = 0;
        SetMonData(m, MON_DATA_HP, &nh); SetMonData(m, MON_DATA_STATUS, &z);
        Cat(out, nm); Cat(out, " WAS REVIVED!");
        if (a) {                                          // the fainted fighter gets back up and keeps fighting
            RefreshActor(a);
            if (!a->alive) { a->alive = 1; a->retired = 0; a->fainted = 0; a->stun = 0; a->phase = PH_FREE; a->invuln = 90; a->flash = 30; PlayAnim(a, ANIM_WALK, 1); }
        }
        return 1;
    }
    if ((fx[4] & 4) || (fx[3] & 0x3F)) {                  // heal hp / status
        if (!hp) return 0;
        int healed = 0, cured = 0;
        if (fx[4] & 4) {
            int amt = fx[6], nh = hp + amt;
            if (amt == 0xFF || nh > mx) nh = mx;
            if (nh > hp) { healed = nh - hp; SetMonData(m, MON_DATA_HP, &nh); }
        }
        u32 mask = 0;
        if (fx[3] & 0x20) mask |= 7;
        if (fx[3] & 0x10) mask |= 0x88;
        if (fx[3] & 0x08) mask |= 0x10;
        if (fx[3] & 0x04) mask |= 0x20;
        if (fx[3] & 0x02) mask |= 0x40;
        if (st & mask) { u32 ns = st & ~mask; SetMonData(m, MON_DATA_STATUS, &ns); cured = 1; }
        if ((fx[3] & 1) && a && a->confTimer) { a->confTimer = 0; cured = 1; }
        if (!healed && !cured) return 0;
        if (healed) { Cat(out, nm); Cat(out, " RECOVERED "); CatNum(out, healed); Cat(out, " HP!"); }
        else { Cat(out, nm); Cat(out, " IS HEALTHY AGAIN!"); }
        if (a) RefreshActor(a);
        return 1;
    }
    if (fx[4] & 8) {                                      // pp restore
        for (int i = 0; i < 4; i++) {
            if (!GetMonData(m, MON_DATA_MOVE1 + i, 0)) continue;
            if ((fx[4] & 0x10) && i != mv) continue;
            int cur = GetMonData(m, MON_DATA_PP1 + i, 0), mxp = MaxPP(m, i);
            int np = fx[6] == 0x7F ? mxp : cur + fx[6];
            if (np > mxp) np = mxp;
            if (np > cur) { u8 v = np; SetMonData(m, MON_DATA_PP1 + i, &v); ok = 1; }
        }
        if (!ok) return 0;
        Cat(out, "PP WAS RESTORED!");
        if (a) RefreshActor(a);
        return 1;
    }
    if ((fx[4] & 0x20) || (fx[5] & 0x10)) {               // pp up / pp max
        u16 mvid = GetMonData(m, MON_DATA_MOVE1 + mv, 0);
        if (!mvid || MV_PP(MV(mvid)) < 5) return 0;
        u32 bon = GetMonData(m, MON_DATA_PPBONUS, 0);
        int b = (bon >> (2 * mv)) & 3;
        if (b >= 3) return 0;
        int nb = (fx[5] & 0x10) ? 3 : b + 1;
        bon = (bon & ~(3u << (2 * mv))) | ((u32)nb << (2 * mv));
        u8 bv = bon; SetMonData(m, MON_DATA_PPBONUS, &bv);
        int cur = GetMonData(m, MON_DATA_PP1 + mv, 0) + MV_PP(MV(mvid)) / 5 * (nb - b);
        int mxp = MaxPP(m, mv); if (cur > mxp) cur = mxp;
        u8 v = cur; SetMonData(m, MON_DATA_PP1 + mv, &v);
        Cat(out, "MAX PP WAS RAISED!");
        if (a) RefreshActor(a);
        return 1;
    }
    {                                                      // vitamins
        int evf = 0;
        if (fx[4] & 1) evf = MON_DATA_HP_EV;
        else if (fx[4] & 2) evf = MON_DATA_ATK_EV;
        else if (fx[5] & 1) evf = MON_DATA_DEF_EV;
        else if (fx[5] & 2) evf = MON_DATA_SPEED_EV;
        else if (fx[5] & 8) evf = MON_DATA_SPATK_EV;
        else if (fx[5] & 4) evf = MON_DATA_SPDEF_EV;
        if (evf && !(fx[0] & 0x4F)) {
            int ev = GetMonData(m, evf, 0);
            if (ev >= 100) return 0;
            ev += fx[6]; if (ev > 100) ev = 100;
            u8 v = ev; SetMonData(m, evf, &v);
            CalculateMonStats(m);
            Cat(out, nm); Cat(out, "'S STAT ROSE!");
            if (a) RefreshActor(a);
            return 1;
        }
    }
    if (a) {                                              // battle items (X..., dire hit, guard spec)
        int d[5] = {fx[0] & 0xF, fx[1] >> 4, fx[1] & 0xF, fx[2] & 0xF, 0};
        int ac = fx[2] >> 4;
        for (int s = 0; s < 4; s++) {
            if (!d[s]) continue;
            int slot = s == 3 ? 3 : s;
            if (a->stage[slot] < 6) { a->stage[slot] += d[s]; if (a->stage[slot] > 6) a->stage[slot] = 6; ok = 1; }
        }
        if (ac && a->stage[5] < 6) { a->stage[5] += ac; if (a->stage[5] > 6) a->stage[5] = 6; ok = 1; }
        if ((fx[0] & 0x30) && !(a->focus & 2)) { a->focus |= 2; ok = 1; }
        if ((fx[3] & 0x80) && !(a->focus & 4)) { a->focus |= 4; ok = 1; }
        if (ok) { Cat(out, nm); Cat(out, "'S STATS WERE BOOSTED!"); FxAdd(A, BodyX(a), BodyY(a), 3); return 1; }
    }
    return 0;
}
static int UseSacredAsh(Arena *A, char *out) {
    int n = 0;
    for (int i = 0; i < gPlayerPartyCount && i < 6; i++) {
        struct Pokemon *m = &gPlayerParty[i];
        if (!GetMonData(m, MON_DATA_SPECIES, 0) || GetMonData(m, MON_DATA_SANITY_IS_EGG, 0)) continue;
        if (GetMonData(m, MON_DATA_HP, 0)) continue;
        Actor *a = FieldActor(A, i);
        if (a && a->alive) continue;
        int mx = GetMonData(m, MON_DATA_MAX_HP, 0); u32 z = 0;
        SetMonData(m, MON_DATA_HP, &mx); SetMonData(m, MON_DATA_STATUS, &z);
        n++;
    }
    out[0] = 0;
    if (!n) return 0;
    Cat(out, "YOUR POKEMON WERE REVIVED!");
    return 1;
}

// ---------- UI ----------
enum { M_RESUME, M_SW1, M_SW2, M_BALL, M_PAGE, M_BAG, M_RUN };
static void UiOpen(Arena *A, int ui, int forced) {
    if (A->state != ST_UI) A->uiPrev = A->state;
    A->state = ST_UI; A->ui = ui; A->uiSel = 0; A->uiForced = forced;
    A->msg[0] = 0; A->msgTimer = 0;
    if (ui == UI_SWITCH) { int n = NextAlive(A); A->uiSel = n < 0 ? 0 : n; }
    if (ui == UI_MENU) {
        int n = 0;
        A->menu[n++] = M_RESUME;
        if (!A->safari) A->menu[n++] = M_SW1;
        if (A->dbl && (A->pm & 4)) A->menu[n++] = M_SW2;
        if (A->safari) {}
        else if (!A->dbl) A->menu[n++] = M_BALL; else A->menu[n++] = M_PAGE;
        if (!A->safari) A->menu[n++] = M_BAG;
        A->menu[n++] = M_RUN;
        A->nmenu = n;
    }
}
static void UiClose(Arena *A) { A->state = A->uiPrev; }

static void BoxText(Arena *A, int x, int y, const char *s, int pal) {
    u16 *m = A->bgmap + y * 32;
    for (; *s && x < 30; s++, x++) {
        int c = (u8)*s;
        if (c >= 'a' && c <= 'z') c -= 32;
        if (c < 32 || c > 95) c = 32;
        m[x] = (101 + c - 32) | ((5 + pal) << 12);
    }
}
static void BoxFill(Arena *A, int x0, int y0, int x1, int y1) {
    for (int y = y0; y <= y1; y++) for (int x = x0; x <= x1; x++) A->bgmap[y * 32 + x] = 101 | (5 << 12);
}

static void BallLine(Arena *A, char *l) {
    l[0] = 0; Cat(l, "BALL: "); Cat(l, BALL_NAMES[A->ballSel]); Cat(l, " X");
    CatNum(l, CountTotalItemQuantityInBag(BALL_ITEMS[A->ballSel]));
}

static void RunAway(Arena *A) {
    if (A->isTrainer) { Msg(A, "NO RUNNING FROM A TRAINER!", 70); UiClose(A); return; }
    UiClose(A);
    A->outcome = 4; A->state = ST_END; A->stateTimer = 0; A->endPhase = 0;
}

static void UiDraw(Arena *A) {
    char l[32];
    if (A->ui == UI_MENU) {
        BoxFill(A, 3, 4, 26, 17);
        BoxText(A, 5, 5, "- PAUSE -  B:BACK", 1);
        for (int k = 0; k < A->nmenu; k++) {
            int it = A->menu[k], sel = A->uiSel == k;
            l[0] = sel ? '>' : ' '; l[1] = ' '; l[2] = 0;
            switch (it) {
            case M_RESUME: Cat(l, "RESUME"); break;
            case M_SW1: Cat(l, A->dbl ? "SWITCH 1ST" : "POKEMON"); break;
            case M_SW2: Cat(l, "SWITCH 2ND"); break;
            case M_BALL: { char t[32]; BallLine(A, t); Cat(l, t); break; }
            case M_PAGE: Cat(l, A->page ? "MOVES: 3 AND 4" : "MOVES: 1 AND 2"); break;
            case M_BAG: Cat(l, "BAG"); break;
            case M_RUN: Cat(l, A->isTrainer ? "RUN (NO)" : "RUN"); break;
            }
            BoxText(A, 5, 7 + k * 2, l, sel ? 1 : (it == M_RUN && A->isTrainer ? 2 : 0));
        }
    } else if (A->ui == UI_BAG) {
        BoxFill(A, 1, 3, 28, 18);
        BoxText(A, 3, 4, "- BAG -  L/R:POCKET  B:BACK", 1);
        {
            char pk[32]; pk[0] = 0; Cat(pk, POCKET_NAME[A->bagTab]); Cat(pk, "  (");
            CatNum(pk, A->bagTab + 1); Cat(pk, "/5)");
            BoxText(A, 3, 5, pk, 3);
        }
        if (!A->nbag) BoxText(A, 4, 9, A->bagTab == POCKET_BALLS ? "NO POKE BALLS" : "THIS POCKET IS EMPTY", 2);
        for (int r = 0; r < 6; r++) {
            int i = A->bagTop + r;
            if (i >= A->nbag) break;
            u16 id = A->bagIds[i];
            char nm[16]; GameStr(gItems + (u32)id * 44, (u8 *)nm, 14);
            l[0] = i == A->uiSel ? '>' : ' '; l[1] = (A->bagTab == POCKET_BALLS && BALL_ITEMS[A->ballSel] == id) ? '*' : ' '; l[2] = 0;
            Cat(l, nm);
            while (slen(l) < 20) Cat(l, " ");
            Cat(l, "X"); CatNum(l, CountTotalItemQuantityInBag(id));
            BoxText(A, 3, 7 + r * 2, l, i == A->uiSel ? 1 : 0);
        }
        if (A->bagTop > 0) BoxText(A, 27, 7, "^", 2);
        if (A->bagTop + 6 < A->nbag) BoxText(A, 27, 17, "V", 2);
        if (A->msg[0]) BoxText(A, 3, 18, A->msg, 3);
    } else if (A->ui == UI_ITEMMV) {
        struct Pokemon *m = &gPlayerParty[A->uiSel2];
        BoxFill(A, 1, 3, 28, 17);
        BoxText(A, 3, 4, "USE ON WHICH MOVE?", 1);
        for (int i = 0; i < 4; i++) {
            u16 mo = GetMonData(m, MON_DATA_MOVE1 + i, 0);
            char on[16]; GameStr(gMoveNames + mo * 13, (u8 *)on, 14);
            l[0] = i == A->uiSel ? '>' : ' '; l[1] = ' '; l[2] = 0; Cat(l, mo ? on : "-");
            while (slen(l) < 17) Cat(l, " ");
            if (mo) { CatNum(l, GetMonData(m, MON_DATA_PP1 + i, 0)); Cat(l, "/"); CatNum(l, MaxPP(m, i)); }
            BoxText(A, 4, 7 + i * 2, l, i == A->uiSel ? 1 : 0);
        }
        BoxText(A, 3, 17, A->msg[0] ? A->msg : "A:USE  B:BACK", A->msg[0] ? 3 : 2);
    } else if (A->ui == UI_SWITCH || A->ui == UI_ITEMTGT) {
        BoxFill(A, 1, 3, 28, 17);
        BoxText(A, 3, 4, A->ui == UI_ITEMTGT ? "USE ON WHICH POKEMON?" : (A->uiForced ? (NextAlive(A) < 0 ? "ALL FAINTED! USE A REVIVE?" : "CHOOSE YOUR NEXT POKEMON") : "SWITCH POKEMON"), 1);
        for (int i = 0; i < 6; i++) {
            if (i >= gPlayerPartyCount) { BoxText(A, 3, 6 + i * 2, "  ---", 2); continue; }
            struct Pokemon *m = &gPlayerParty[i];
            char nm[12]; MonName(m, nm);
            int hp = GetMonData(m, MON_DATA_HP, 0), mx = GetMonData(m, MON_DATA_MAX_HP, 0);
            for (int k = 0; k < 4; k += 2)
                if ((A->pm & (1 << k)) && A->act[k].partyIdx == i && !A->act[k].retired) hp = A->act[k].alive ? (A->act[k].hp < 0 ? 0 : A->act[k].hp) : 0;
            l[0] = i == A->uiSel ? '>' : ' '; l[1] = ' '; l[2] = 0;
            Cat(l, nm);
            while (slen(l) < 13) Cat(l, " ");
            Cat(l, "L"); CatNum(l, GetMonData(m, MON_DATA_LEVEL, 0));
            while (slen(l) < 18) Cat(l, " ");
            CatNum(l, hp); Cat(l, "/"); CatNum(l, mx);
            int pal = i == A->uiSel ? 1 : ((A->ui == UI_ITEMTGT || Switchable(A, i)) ? 0 : (hp == 0 ? 3 : 2));
            BoxText(A, 2, 6 + i * 2, l, pal);
        }
        if (A->msg[0]) BoxText(A, 3, 17, A->msg, 3);
        else BoxText(A, 3, 17, A->ui == UI_ITEMTGT ? "A:USE  B:BACK" : (A->uiForced ? (NextAlive(A) < 0 ? "START:BAG  B:GIVE UP" : "A:SEND OUT  START:BAG") : "A:SEND OUT  B:BACK"), 2);
    } else if (A->ui == UI_LEARN) {
        struct Pokemon *m = &gPlayerParty[A->lnIdx];
        char nm[12]; MonName(m, nm);
        char mv[16]; GameStr(gMoveNames + A->lnMove * 13, (u8 *)mv, 14);
        BoxFill(A, 1, 3, 28, 17);
        l[0] = 0; Cat(l, nm); Cat(l, " WANTS TO LEARN"); BoxText(A, 3, 4, l, 0);
        l[0] = 0; Cat(l, mv); Cat(l, "!"); BoxText(A, 3, 5, l, 1);
        BoxText(A, 3, 7, "FORGET WHICH MOVE?", 0);
        for (int i = 0; i < 4; i++) {
            u16 mo = GetMonData(m, MON_DATA_MOVE1 + i, 0);
            char on[16]; GameStr(gMoveNames + mo * 13, (u8 *)on, 14);
            l[0] = i == A->uiSel ? '>' : ' '; l[1] = ' '; l[2] = 0; Cat(l, on);
            BoxText(A, 4, 9 + i * 2, l, i == A->uiSel ? 1 : 0);
        }
        BoxText(A, 4, 17, A->uiSel == 4 ? "> DON'T LEARN IT" : "  DON'T LEARN IT", A->uiSel == 4 ? 1 : 2);
    } else if (A->ui == UI_EVO) {
        BoxFill(A, 3, 6, 28, 13);
        BoxText(A, 5, 7, "DO YOU WANT TO EVOLVE", 0);
        l[0] = 0; Cat(l, A->evoNm); Cat(l, "?"); BoxText(A, 5, 8, l, 1);
        BoxText(A, 7, 10, A->uiSel == 0 ? "> YES" : "  YES", A->uiSel == 0 ? 1 : 0);
        BoxText(A, 7, 12, A->uiSel == 1 ? "> NO (NEVER EVOLVES)" : "  NO (NEVER EVOLVES)", A->uiSel == 1 ? 1 : 0);
    } else if (A->ui == UI_NICK) {
        struct Pokemon *m = &gEnemyParty[0];
        char nm[12]; MonName(m, nm);
        BoxFill(A, 4, 6, 25, 13);
        BoxText(A, 6, 7, "GIVE A NICKNAME TO", 0);
        l[0] = 0; Cat(l, nm); Cat(l, "?"); BoxText(A, 6, 8, l, 1);
        BoxText(A, 8, 10, A->uiSel == 0 ? "> YES" : "  YES", A->uiSel == 0 ? 1 : 0);
        BoxText(A, 8, 12, A->uiSel == 1 ? "> NO" : "  NO", A->uiSel == 1 ? 1 : 0);
    }
}

static int UiMove(Arena *A, int n) {
    u16 k = gMain.newKeys;
    if (k & KEY_UP) A->uiSel = A->uiSel ? A->uiSel - 1 : n - 1;
    else if (k & KEY_DOWN) A->uiSel = A->uiSel + 1 >= n ? 0 : A->uiSel + 1;
    return k;
}

static void UiFrame(Arena *A) {
    if (A->msgTimer) { A->msgTimer--; if (!A->msgTimer) A->msg[0] = 0; }
    if (A->ui == UI_MENU) {
        u16 k = UiMove(A, A->nmenu);
        if (k & (KEY_B | KEY_START)) { UiClose(A); return; }
        int it = A->menu[A->uiSel];
        if (it == M_BALL && (k & (KEY_LEFT | KEY_RIGHT | KEY_L | KEY_R | KEY_A))) {
            int d = (k & (KEY_LEFT | KEY_L)) ? NBALL - 1 : 1;
            for (int t = 0; t < NBALL; t++) {
                A->ballSel = (A->ballSel + d) % NBALL;
                if (CountTotalItemQuantityInBag(BALL_ITEMS[A->ballSel])) break;
            }
        } else if (it == M_PAGE && (k & (KEY_LEFT | KEY_RIGHT | KEY_L | KEY_R | KEY_A))) {
            A->page ^= 1;
        } else if (k & KEY_A) {
            if (it == M_RESUME) UiClose(A);
            else if (it == M_SW1 || it == M_SW2) {
                A->uiSlot = it == M_SW1 ? 0 : 2;
                A->ui = UI_SWITCH;
                int n = NextAlive(A); A->uiSel = n < 0 ? 0 : n;
            }
            else if (it == M_BAG) { A->ui = UI_BAG; A->uiSel = 0; A->bagSel = 0; A->bagTop = 0; BuildBag(A); }
            else if (it == M_RUN) RunAway(A);
        }
    } else if (A->ui == UI_BAG) {
        u16 k = UiMove(A, A->nbag ? A->nbag : 1);
        if (k & (KEY_LEFT | KEY_L | KEY_RIGHT | KEY_R)) {
            A->bagTab = (k & (KEY_LEFT | KEY_L)) ? (A->bagTab + NPOCKET - 1) % NPOCKET : (A->bagTab + 1) % NPOCKET;
            A->uiSel = 0; A->bagTop = 0; A->bagSel = 0; A->msg[0] = 0; A->msgTimer = 0;
            BuildBag(A);
            return;
        }
        if (A->uiSel < A->bagTop) A->bagTop = A->uiSel;
        if (A->uiSel >= A->bagTop + 6) A->bagTop = A->uiSel - 5;
        if ((k & KEY_B) && A->uiForced) {                      // opened from the "choose your next Pokemon" list
            A->ui = UI_SWITCH; A->msg[0] = 0; A->msgTimer = 0;
            int n = NextAlive(A); A->uiSel = n < 0 ? 0 : n;
        } else if (k & KEY_B) {
            A->ui = UI_MENU; A->msg[0] = 0;
            for (int i = 0; i < A->nmenu; i++) if (A->menu[i] == M_BAG) A->uiSel = i;
        } else if ((k & KEY_A) && A->nbag) {
            u16 id = A->bagIds[A->uiSel];
            const u8 *fx = ItemFx(id);
            A->bagItem = id; A->bagSel = A->uiSel;
            if (A->bagTab == POCKET_BALLS) {                       // pick the ball that SEL throws
                for (int b = 0; b < NBALL; b++) if (BALL_ITEMS[b] == id) A->ballSel = b;
                char t[32]; char nm[16]; GameStr(gItems + (u32)id * 44, (u8 *)nm, 14);
                t[0] = 0; Cat(t, "BALL: "); Cat(t, nm);
                Msg(A, t, 70);
            } else if (!ItemUsable(fx)) {
                Msg(A, A->bagTab == 1 ? "CAN'T USE THAT HERE!" : "CAN'T USE THAT NOW!", 60);
            } else if (!ItemNeedsMon(fx)) {
                char t[32];
                if (UseSacredAsh(A, t)) { RemoveBagItem(id, 1); Msg(A, t, 90); BuildBag(A); A->uiSel = A->bagSel < A->nbag ? A->bagSel : 0; }
                else Msg(A, "IT WON'T HAVE ANY EFFECT!", 60);
            } else { A->ui = UI_ITEMTGT; A->uiSel = 0; A->msg[0] = 0; A->msgTimer = 0; }
        }
    } else if (A->ui == UI_ITEMTGT) {
        u16 k = UiMove(A, 6);
        if (k & KEY_B) { A->ui = UI_BAG; A->uiSel = A->bagSel; A->msg[0] = 0; }
        else if ((k & KEY_A) && A->uiSel < gPlayerPartyCount) {
            const u8 *fx = ItemFx(A->bagItem);
            if (ItemNeedsMove(fx)) { A->uiSel2 = A->uiSel; A->ui = UI_ITEMMV; A->uiSel = 0; A->msg[0] = 0; }
            else {
                char t[32];
                if (ApplyItem(A, A->bagItem, A->uiSel, 0, t)) {
                    RemoveBagItem(A->bagItem, 1); BuildBag(A);
                    A->ui = UI_BAG; A->uiSel = A->bagSel < A->nbag ? A->bagSel : 0;
                    if (A->uiSel < A->bagTop) A->bagTop = A->uiSel;
                    Msg(A, t, 90);
                    if (A->uiForced && A->act[A->uiSlot].alive) { char keep[32]; keep[0] = 0; Cat(keep, t); UiClose(A); Msg(A, keep, 90); }   // the fainted fighter is back
                } else Msg(A, "IT WON'T HAVE ANY EFFECT!", 60);
            }
        }
    } else if (A->ui == UI_ITEMMV) {
        u16 k = UiMove(A, 4);
        if (k & KEY_B) { A->ui = UI_ITEMTGT; A->uiSel = A->uiSel2; A->msg[0] = 0; }
        else if (k & KEY_A) {
            char t[32];
            if (ApplyItem(A, A->bagItem, A->uiSel2, A->uiSel, t)) {
                RemoveBagItem(A->bagItem, 1); BuildBag(A);
                A->ui = UI_BAG; A->uiSel = A->bagSel < A->nbag ? A->bagSel : 0;
                if (A->uiSel < A->bagTop) A->bagTop = A->uiSel;
                Msg(A, t, 90);
            } else Msg(A, "IT WON'T HAVE ANY EFFECT!", 60);
        }
    } else if (A->ui == UI_SWITCH) {
        u16 k = UiMove(A, 6);
        if ((k & KEY_B) && !A->uiForced) { UiClose(A); return; }
        if ((k & KEY_B) && A->uiForced && NextAlive(A) < 0) { A->giveUp = 1; UiClose(A); return; }       // nobody left and no revive used
        if ((k & KEY_START) && A->uiForced) { A->ui = UI_BAG; A->uiSel = 0; A->bagSel = 0; A->bagTop = 0; A->msg[0] = 0; A->msgTimer = 0; BuildBag(A); return; }
        if (k & KEY_A) {
            if (Switchable(A, A->uiSel)) { SwitchIn(A, A->uiSel, A->uiSlot); A->uiPrev = ST_FIGHT; UiClose(A); }
            else Msg(A, "CAN'T SEND THAT ONE OUT!", 40);
        }
    } else if (A->ui == UI_LEARN) {
        u16 k = UiMove(A, 5);
        if (k & KEY_B) A->uiSel = 4, k |= KEY_A;
        if (k & KEY_A) {
            struct Pokemon *m = &gPlayerParty[A->lnIdx];
            char nm[12]; MonName(m, nm);
            char mv[16]; GameStr(gMoveNames + A->lnMove * 13, (u8 *)mv, 14);
            char l[32]; l[0] = 0;
            if (A->uiSel < 4) {
                u16 mo = GetMonData(m, MON_DATA_MOVE1 + A->uiSel, 0);
                char on[16]; GameStr(gMoveNames + mo * 13, (u8 *)on, 14);
                SetMonMoveSlot(m, A->lnMove, A->uiSel);
                Cat(l, nm); Cat(l, " FORGOT "); Cat(l, on); EvPush(A, l, 80);
                l[0] = 0; Cat(l, "AND LEARNED "); Cat(l, mv); Cat(l, "!"); EvPush(A, l, 90);
            } else {
                Cat(l, nm); Cat(l, " DID NOT LEARN"); EvPush(A, l, 70);
                l[0] = 0; Cat(l, mv); Cat(l, "."); EvPush(A, l, 70);
            }
            UiClose(A);
        }
    } else if (A->ui == UI_EVO) {
        u16 k = UiMove(A, 2);
        if (k & KEY_B) { A->evoAns = 2; UiClose(A); }
        else if (k & KEY_A) { A->evoAns = A->uiSel == 0 ? 1 : 2; UiClose(A); }
    } else if (A->ui == UI_NICK) {
        u16 k = UiMove(A, 2);
        if (k & KEY_B) { A->nickWanted = 0; UiClose(A); }
        else if (k & KEY_A) { A->nickWanted = A->uiSel == 0; UiClose(A); }
    }
}

// ---------- start ----------
static int FindLeadFrom(int from) {
    for (int i = from; i < 6 && i < gPlayerPartyCount; i++) {
        struct Pokemon *m = &gPlayerParty[i];
        u16 sp = GetMonData(m, MON_DATA_SPECIES, 0);
        if (!sp) continue;
        if (GetMonData(m, MON_DATA_SANITY_IS_EGG, 0)) continue;
        if (GetMonData(m, MON_DATA_HP, 0) == 0) continue;
        if (!RecFor(SpeciesToNationalPokedexNum(sp))) continue;
        return i;
    }
    return -1;
}

static void SpawnEnemy(Arena *A, int partyIdx, int slot) {
    Actor *e = &A->act[slot];
    InitActor(A, e, &gEnemyParty[partyIdx], 0, partyIdx, slot);
    e->x = 176 << 8;
    e->y = (A->dbl ? (slot == 1 ? 84 : 116) : 90) << 8;
    e->aiMove = -1; e->aiReact = 40;
    if ((gBattleTypeFlags & 0x80000) && CheatOn(2)) { e->maxHp = (e->maxHp + 3) / 4; e->hp = e->maxHp; e->aiReact = 90; }   // easy mode: Trainer Tower foes have a quarter of the HP
    A->pm |= 1 << slot;
    GetSetPokedexFlag(e->nat, 2);
    StartRelease(A, e, slot);
}

static int ArenaStart(void) {
    u32 fl = gBattleTypeFlags;
#ifdef ARENA_DEBUG
    *(volatile u32 *)0x0203F7E8 = fl; *(volatile u16 *)0x0203F7EC = gTrainerBattleOpponent_A;
#endif
    int trainer = 0, cnt = 1, dbl = 0;
    u16 tid = 0;
    const u8 *tr = 0;
    // Trainer Tower (Sevii Islands): the game builds the enemy team itself.  It is used only when gEnemyParty is clearly
    // fresh (different from the team the previous battle left behind); otherwise the vanilla battle runs.
    volatile u32 *stamp = (volatile u32 *)0x0203F7F0;
    int tower = (fl & 0x80000) && (fl & 8) && !(fl & ~0x80009u) && GetMonData(&gEnemyParty[0], MON_DATA_PERSONALITY, 0) != stamp[0];
#ifdef ARENA_DEBUG
    if (tower && *(volatile u8 *)0x0203F7FA) return 0;      // debug: force the game's own battle in the Trainer Tower
#endif
    if (fl == 8 || fl == 9 || fl == 0x18 || tower) {         // 0x18 = the very first rival battle (Oak's lab)
        dbl = (fl & 1) != 0;
        tid = gTrainerBattleOpponent_A;
        if (tower && tid >= 743) tid = 1;                      // the tower's own trainer ids are not in the normal table
        tr = gTrainers + (u32)tid * 40;
        if (!tower && !dbl && *(const u32 *)(tr + 24)) dbl = 1;   // the game sets the double flag later, inside its own battle init (Kindle Road twins etc.)
        if (!tower && dbl && !*(const u32 *)(tr + 24)) return 0;   // a double-battle trainer met with only one usable Pokemon (single battle) is real-time too
        if (!tower) CreateNPCTrainerParty(gEnemyParty, tid);
        cnt = 0;
        for (int i = 0; i < 6; i++) {
            u16 sp = GetMonData(&gEnemyParty[i], MON_DATA_SPECIES, 0);
            if (!sp) break;
            if (!RecFor(SpeciesToNationalPokedexNum(sp))) return 0;
            cnt++;
        }
        if (!cnt) return 0;
        trainer = 1;
    } else if (fl & 0x00010B66) return 0;   // link, multi, tower, tutorial, e-reader, Pokedude: vanilla.  Every other wild battle (scripted, legendary, ghost, Snorlax, safari...) is real-time

    int lead = FindLeadFrom(0);
    if (lead < 0) return 0;
    int second = dbl ? FindLeadFrom(lead + 1) : -1;
    if (dbl && second < 0 && !(fl & 1)) dbl = 0;      // only one usable Pokemon: single battle
    {   // ALL POKEMON: wild Pokemon that did not come from the visible overworld ones (fishing, Rock Smash, Sweet Scent...) are random too
        volatile u8 *own = (volatile u8 *)0x0203F7FC;
        if (!trainer && fl == 0 && !*own && CheatOn(1)) {
            int lv = GetMonData(&gEnemyParty[0], MON_DATA_LEVEL, 0);
            u16 nat = 1 + Random() % 386, sp = 0;
            for (u16 q = 1; q < 412; q++) if (SpeciesToNationalPokedexNum(q) == nat) { sp = q; break; }
            if (sp && RecFor(nat)) CreateMon(&gEnemyParty[0], sp, lv, 32, 0, 0, 0, 0);
        }
        *own = 0;
    }
    u16 es = GetMonData(&gEnemyParty[0], MON_DATA_SPECIES, 0);
    if (!es || !RecFor(SpeciesToNationalPokedexNum(es))) return 0;
    if (!trainer && !GetMonData(&gEnemyParty[0], MON_DATA_HELD_ITEM, 0) && es < 412) {      // wild Pokemon come holding their evolution item (random one if there are several)
        const u16 *it = (const u16 *)0x09DFE000 + es * 5;
        int n = 0;
        while (n < 5 && it[n] && it[n] != 0xFFFF) n++;
        if (n) { u16 item = it[Random() % n]; SetMonData(&gEnemyParty[0], MON_DATA_HELD_ITEM, &item); }
    }
#ifdef ARENA_DEBUG
    *(volatile u16 *)0x0203F020 = GetMonData(&gEnemyParty[0], MON_DATA_HELD_ITEM, 0);
#endif
    Arena *A = (Arena *)AllocZeroed(sizeof(Arena));
    if (!A) return 0;
    HwReset();
    ResetSpriteData(); ResetTasks(); FreeAllSpritePalettes(); ResetPaletteFade();
    *(Arena **)(&gMain.oamBuffer[127 * 8]) = A;
    A->terrain = BattleSetup_GetTerrainId();
    if (A->terrain == 9 && fl == 0) {                 // fishing: you stand on land next to the water
        s16 px, py; PlayerGetDestCoords(&px, &py);
        static const s8 nb[4][2] = {{0, 1}, {0, -1}, {-1, 0}, {1, 0}};
        for (int k = 0; k < 4; k++) {
            u16 mb = MapGridGetMetatileBehaviorAt(px + nb[k][0], py + nb[k][1]);
            if (mb == 0x15 || mb == 0x12 || mb == 0x11) { A->terrain = 4; break; }
            if (mb == 0x10 || mb == 0x17) A->terrain = 5;
        }
    }
#ifdef ARENA_DEBUG
    if (*(volatile u16 *)0x0203F010) A->terrain = *(volatile u16 *)0x0203F010 - 1;
#endif
    *(volatile u8 *)0x2022B50 = A->terrain;       // gBattleTerrain
    {   // ice caves (Seafoam Islands, Icefall Cave): the floor is snow (theme 10 of gFloorPals)
        u8 ms = *(volatile u8 *)(0x2036DFC + 0x14);
        if (ms == 0x8B || ms == 0xB1) A->terrain = 10;
    }
    LoadGfx(A);
    A->dbl = dbl;
    A->safari = fl == 0x80;
    if (!InitActor(A, &A->act[0], &gPlayerParty[lead], 1, lead, 0)) {
        for (int k = 0; k < 4; k++) if (A->bstage[k]) Free(A->bstage[k]);
        Free(A); *(Arena **)(&gMain.oamBuffer[127 * 8]) = 0; return 0;
    }
    A->pm = 1;
    Actor *p = &A->act[0];
    p->x = 64 << 8; p->y = (dbl ? 84 : 100) << 8;
    A->partyUsedMask = 1 << lead;
    if (second >= 0) {
        InitActor(A, &A->act[2], &gPlayerParty[second], 1, second, 2);
        A->act[2].x = 64 << 8; A->act[2].y = 116 << 8;
        A->pm |= 4; A->partyUsedMask |= 1 << second;
    }
    A->isTrainer = trainer; A->enemyCnt = cnt; A->trainerId = tid; A->endSlot = 1;
    SpawnEnemy(A, 0, 1);
    A->enemyNext = 1;
    if (dbl && cnt >= 2) { SpawnEnemy(A, 1, 3); A->enemyNext = 2; }
    StartRelease(A, &A->act[0], 0);
    if (second >= 0) StartRelease(A, &A->act[2], 2);
    Actor *e = &A->act[1];
    for (int i = 0; i < NBALL; i++) if (CountTotalItemQuantityInBag(BALL_ITEMS[i])) { A->ballSel = i; break; }
    if (A->safari) A->ballSel = 4;
    A->state = ST_FADEIN; A->fadeLevel = 16; A->dispcnt = 0x80;
    char l[32]; l[0] = 0;
    if (trainer) {
        u8 tmp[16];
        GameStr(gTrainerClassNames + tr[1] * 13, tmp, 14);
        Cat(A->tname, (char *)tmp); Cat(A->tname, " ");
        GameStr(tr + 4, tmp, 12);
        Cat(A->tname, (char *)tmp);
        Cat(l, (char *)tmp);
        if (A->enemyNext == 2) Cat(l, " SENT OUT 2 POKEMON!");
        else { Cat(l, " SENT OUT "); Cat(l, (char *)e->name); Cat(l, "!"); }
    } else {
        Cat(l, "A WILD "); Cat(l, (char *)e->name); Cat(l, " APPEARED!");
        if (A->safari) { l[0] = 0; Cat(l, "A:BALL  B:BAIT  L:ROCK"); }
    }
    Msg(A, l, 100);
    SetVBlankCallback(ArenaVBlank);
    SetMainCallback2(ArenaMain);
    return 1;
}

// ---------- end of battle ----------
static void GrantExp(Arena *A, Actor *e) {
    int yield = gBaseStats[(u32)e->species * 28 + 9];
    int exp = yield * e->level / 7;
    if (A->isTrainer) exp = exp * 3 / 2;
    if (exp < 1) exp = 1;
    // option EXP FOR ALL (L menu): EVERY Pokemon of the party gets the full amount; otherwise only the ones that took part, sharing it
    int all = CheatOn(3), np = 0, shown = 0;
    for (int i = 0; i < 6; i++) if (A->partMask & (1 << i)) np++;
    int share = all || np < 2 ? exp : exp / np;
    if (share < 1) share = 1;
    for (int i = 0; i < 6; i++) {
        struct Pokemon *m = &gPlayerParty[i];
        if (!GetMonData(m, MON_DATA_SPECIES, 0) || GetMonData(m, MON_DATA_SANITY_IS_EGG, 0)) continue;
        int reserve = !(A->partMask & (1 << i));
        if (reserve && !GetMonData(m, MON_DATA_HP, 0)) continue;      // a fainted Pokemon on the bench gets nothing
        u8 oldLv = GetMonData(m, MON_DATA_LEVEL, 0);
        if (oldLv >= 100) continue;
        int amt = (reserve && !all) ? (share / 2 < 1 ? 1 : share / 2) : share;     // the bench gets half (all of it with EXP FOR ALL)
        u32 cur = GetMonData(m, MON_DATA_EXP, 0) + amt;
        SetMonData(m, MON_DATA_EXP, &cur);
        u8 nl = GetLevelFromMonExp(m);
        char nm[12]; MonName(m, nm);
        char l[32]; l[0] = 0;
        Cat(l, nm); Cat(l, " GAINED "); CatNum(l, amt); Cat(l, " EXP!");
        EvPush(A, l, shown++ ? 40 : 70);
        if (nl > oldLv) {
            SetMonData(m, MON_DATA_LEVEL, &nl);
            CalculateMonStats(m);
            l[0] = 0; Cat(l, nm); Cat(l, " GREW TO LV"); CatNum(l, nl); Cat(l, "!");
            EvPush(A, l, 80);
            if (!(A->lnMask & (1 << i))) A->oldLv[i] = oldLv;
            A->newLv[i] = nl;
            A->lnMask |= 1 << i; A->lvlMask |= 1 << i;
        }
    }
}

// returns 1 while busy (message queued or prompt open)
static int LearnPhase(Arena *A) {
    for (;;) {
        if (!A->lnActive) {
            int i;
            for (i = 0; i < 6; i++) if (A->lnMask & (1 << i)) break;
            if (i >= 6) return 0;
            A->lnMask &= ~(1 << i);
            A->lnIdx = i; A->lnLv = A->oldLv[i] + 1; A->lnTo = A->newLv[i]; A->lnFirst = 1; A->lnActive = 1;
        }
        struct Pokemon *m = &gPlayerParty[A->lnIdx];
        u8 lv = A->lnLv;
        SetMonData(m, MON_DATA_LEVEL, &lv);
        u16 r = MonTryLearningNewMove(m, A->lnFirst);
        A->lnFirst = 0;
        if (r == 0) {
            if (A->lnLv >= A->lnTo) {
                u8 f = A->lnTo; SetMonData(m, MON_DATA_LEVEL, &f);
                A->lnActive = 0;
            } else { A->lnLv++; A->lnFirst = 1; }
            continue;
        }
        if (r == 0xFFFE) continue;
        if (r == 0xFFFF) {
            A->lnMove = gMoveToLearn;
            UiOpen(A, UI_LEARN, 0);
            return 1;
        }
        char nm[12]; MonName(m, nm);
        char mv[16]; GameStr(gMoveNames + r * 13, (u8 *)mv, 14);
        char l[32]; l[0] = 0;
        Cat(l, nm); Cat(l, " LEARNED"); EvPush(A, l, 60);
        l[0] = 0; Cat(l, mv); Cat(l, "!"); EvPush(A, l, 80);
        return 1;
    }
}


// ---------- evolution inside the arena ----------
static void EvoCommit(Arena *A, int i, u16 sp, Actor *a) {
    struct Pokemon *m = &gPlayerParty[i];
    u16 old = GetMonData(m, MON_DATA_SPECIES, 0);
    u8 nm[12]; GetMonData(m, MON_DATA_NICKNAME, nm);
    int same = 1;
    for (int k = 0; k < 11; k++) {
        if (nm[k] != gSpeciesNames[old * 11 + k]) { same = 0; break; }
        if (nm[k] == 0xFF) break;
    }
    if (a) WriteBack(a);
    EvoConsumeItem(m, old, sp);
    SetMonData(m, MON_DATA_SPECIES, &sp);
    if (same) SetMonData(m, MON_DATA_NICKNAME, gSpeciesNames + sp * 11);
    CalculateMonStats(m);
    u16 nat = SpeciesToNationalPokedexNum(sp);
    GetSetPokedexFlag(nat, 2); GetSetPokedexFlag(nat, 3);
    if (a) {
        s32 x = a->x, y = a->y; int k = a - A->act;
        InitActor(A, a, m, 1, i, k);
        a->x = x; a->y = y; a->invuln = 60;
    }
    u8 lv = GetMonData(m, MON_DATA_LEVEL, 0);
    A->oldLv[i] = lv - 1; A->newLv[i] = lv; A->lnMask |= 1 << i;   // moves learnt at this level by the new species
    PlayCry1(sp, 0);
}

// returns 1 while busy
static int EvoPhase(Arena *A) {
    char l[40];
    if (A->evoSt == 0) {
        int i; u16 sp = 0;
        for (i = 0; i < 6; i++) {
            if (!(A->lvlMask & (1 << i))) continue;
            A->lvlMask &= ~(1 << i);
            struct Pokemon *m = &gPlayerParty[i];
            if (!GetMonData(m, MON_DATA_SPECIES, 0) || GetMonData(m, MON_DATA_SANITY_IS_EGG, 0)) continue;
            sp = EvoTarget(m);
            if (sp && RecFor(SpeciesToNationalPokedexNum(sp))) break;
            sp = 0;
        }
        if (!sp) return 0;
        A->evoIdx = i; A->evoSp = sp; A->evoT = 0; A->evoSt = 1;
        MonName(&gPlayerParty[i], A->evoNm);
        l[0] = 0; Cat(l, A->evoNm); Cat(l, " IS EVOLVING!"); EvPush(A, l, 70);
        return 1;
    }
    Actor *a = FieldActor(A, A->evoIdx);
    if (A->evoSt == 1) {
        if (EvBusy(A)) return 1;
        A->evoAns = 0; A->evoSt = 3;
        UiOpen(A, UI_EVO, 0);
        return 1;
    }
    if (A->evoSt == 3) {                                  // answer to "do you want to evolve?"
        if (!A->evoAns) return 1;
        if (A->evoAns == 1) { A->evoSt = 2; A->evoT = a ? 0 : 98; return 1; }
        u8 mark = 255; SetMonData(&gPlayerParty[A->evoIdx], MON_DATA_CUTE, &mark);
#ifdef ARENA_DEBUG
        for (int q = 0; q < 14; q++) ((volatile u16 *)0x0203F030)[q] = GetMonData(&gPlayerParty[A->evoIdx], 20 + q, 0);
#endif
        l[0] = 0; Cat(l, A->evoNm); Cat(l, " WILL NEVER EVOLVE."); EvPush(A, l, 90);
        A->evoSt = 0;
        return 1;
    }
    A->evoT++;
    if (a && A->evoT < 100) a->flash = 6;                 // white flicker
    if (A->evoT == 60 || (!a && A->evoT == 99)) EvoCommit(A, A->evoIdx, A->evoSp, a);
    if (A->evoT >= 100) {
        char y[14]; GameStr(gSpeciesNames + A->evoSp * 11, (u8 *)y, 12);
        l[0] = 0; Cat(l, A->evoNm); Cat(l, " EVOLVED INTO"); EvPush(A, l, 60);
        l[0] = 0; Cat(l, y); Cat(l, "!"); EvPush(A, l, 90);
        A->evoSt = 0;
    }
    return 1;
}

static int BadgeCount(void) {
    u8 b = gSaveBlock1Ptr[0xEE0 + 0x104];
    int n = 0;
    for (int i = 0; i < 8; i++) if (b & (1 << i)) n++;
    return n;
}

static void StartFade(Arena *A) {
    A->state = ST_FADEOUT; A->stateTimer = 0; FadeOutBGM(4);
}

static void ActiveMask(Arena *A) {
    A->partyUsedMask = 0;
    for (int k = 0; k < 4; k += 2) if ((A->pm & (1 << k)) && !A->act[k].retired && A->act[k].alive) A->partyUsedMask |= 1 << A->act[k].partyIdx;
}

static void EndFrame(Arena *A) {
    Actor *e = &A->act[A->endSlot];
    A->stateTimer++;
    for (int i = 0; i < 4; i++) if (A->pm & (1 << i)) { UpdateActor(A, &A->act[i]); UploadFrame(A, &A->act[i], i); }
    UpdateProjectiles(A); UpdateAging(A);
    char l[32];
    switch (A->endPhase) {
    case 0:
        for (int k = 0; k < 4; k += 2) if ((A->pm & (1 << k)) && !A->act[k].retired) WriteBack(&A->act[k]);
        if (A->outcome == 1) {
            e->retired = 1; A->defeated++;
            l[0] = 0; Cat(l, "FOE "); Cat(l, (char *)e->name); Cat(l, " FAINTED!");
            EvPush(A, l, 70);
            GrantExp(A, e);
        } else if (A->outcome == 2) {
            EvPush(A, "YOU HAVE NO USABLE POKEMON!", 100);
            u32 *money = (u32 *)(gSaveBlock1Ptr + 0x290);
            static const u8 mult[9] = {2, 4, 6, 9, 12, 16, 20, 25, 30};
            int mx = 1;
            for (int i = 0; i < 6; i++) { int lv = GetMonData(&gPlayerParty[i], MON_DATA_LEVEL, 0); if (lv > mx && GetMonData(&gPlayerParty[i], MON_DATA_SPECIES, 0)) mx = lv; }
            u32 loss = mx * 4 * mult[BadgeCount()];
            u32 have = GetMoney(money);
            if (loss > have) loss = have;
            if (loss) { RemoveMoney(money, loss); l[0] = 0; Cat(l, "YOU PAID "); CatNum(l, loss); Cat(l, "..."); EvPush(A, l, 90); }
        } else if (A->outcome == 4) EvPush(A, "GOT AWAY SAFELY!", 60);
        else if (A->outcome == 6) { l[0] = 0; Cat(l, (char *)e->name); Cat(l, " RAN AWAY!"); EvPush(A, l, 80); }
        else if (A->outcome == 8) EvPush(A, "OUT OF SAFARI BALLS!", 90);
        A->endPhase = 1;
        break;
    case 1:
        if (EvBusy(A)) break;
        if (LearnPhase(A)) break;
        if (EvoPhase(A)) break;
        A->endPhase = 2;
        break;
    case 2:
        if (A->outcome == 1) {
            ReloadPlayer(A);
            ActiveMask(A);
            if (A->isTrainer) {
                if (A->enemyNext < A->enemyCnt) {      // trainer sends out the next Pokemon into this slot
                    SpawnEnemy(A, A->enemyNext++, A->endSlot);
                    Actor *ne = &A->act[A->endSlot];
                    l[0] = 0; Cat(l, "FOE SENT OUT "); Cat(l, (char *)ne->name); Cat(l, "!");
                    Msg(A, l, 90);
                    PlayCry1(ne->species, 25); A->cryPending = 1;
                    A->state = ST_INTRO; A->stateTimer = 20; A->endPhase = 0;
                    break;
                }
                if (FoesPending(A)) {                   // the other foe keeps fighting
                    A->state = ST_INTRO; A->stateTimer = 40; A->endPhase = 0;
                    break;
                }
                const u8 *tr = gTrainers + (u32)A->trainerId * 40;
                int val = 0;
                const u8 *mt = gTrainerMoneyTable;
                for (; mt[0] != 0xFF; mt += 4) { val = mt[1]; if (mt[0] == tr[1]) break; }
                int lastLv = GetMonData(&gEnemyParty[A->enemyCnt - 1], MON_DATA_LEVEL, 0);
                u32 prize = 4 * lastLv * val;
                if (A->dbl) prize *= 2;
                AddMoney((u32 *)(gSaveBlock1Ptr + 0x290), prize);
                l[0] = 0; Cat(l, "YOU BEAT "); Cat(l, A->tname); Cat(l, "!");
                EvPush(A, l, 90);
                l[0] = 0; Cat(l, "GOT "); CatNum(l, prize); Cat(l, " FOR WINNING!");
                EvPush(A, l, 90);
            }
        } else if (A->outcome == 2 && A->isTrainer) {
            l[0] = 0; Cat(l, "YOU LOST TO "); Cat(l, A->tname); Cat(l, "!");
            EvPush(A, l, 80);
        }
        A->endPhase = 3;
        break;
    case 3:
        if (EvBusy(A)) break;
        A->endPhase = 4;
        break;
    case 4:
        if (A->msgTimer) break;
        if (A->outcome == 7) { A->endPhase = 5; UiOpen(A, UI_NICK, 0); break; }
        StartFade(A);
        break;
    case 5:
        StartFade(A);
        break;
    }
}

static void ArenaExit(Arena *A) {
    Post *P = POST;
    P->step = 0; P->outcome = A->outcome; P->nick = A->nickWanted; P->lvlMask = A->lvlMask;
    P->finalCb = gMain.savedCallback ? gMain.savedCallback : CB2_EndWildBattle;
    if (A->outcome != 1 && A->outcome != 7) P->lvlMask = A->lvlMask;   // kept: levels already gained still evolve
    if (A->cryPending) m4aMPlayVolumeControl(gMPlayInfo_BGM, 0xFFFF, 0x100);
    SetVBlankCallback(0);
    REG_DISPCNT = 0x80; REG_BLDCNT = 0; REG_BLDY = 0; REG_BLDALPHA = 0;
    *(Arena **)(&gMain.oamBuffer[127 * 8]) = 0;
    for (int k = 0; k < 4; k++) if (A->bstage[k]) Free(A->bstage[k]);
    Free(A);
    SetMainCallback2(PostStep);
}

// runs after the arena: nickname screen, give the caught mon, evolution scenes, then back to the game
void PostStep(void) {
    Post *P = POST;
    switch (P->step) {
    case 0:
        if (P->outcome == 7 && P->nick) {
            struct Pokemon *m = &gEnemyParty[0];
            GetMonData(m, MON_DATA_NICKNAME, P->nickBuf);
            P->step = 1;
            DoNamingScreen(2, P->nickBuf, GetMonData(m, MON_DATA_SPECIES, 0), GetMonGender(m),
                           GetMonData(m, MON_DATA_PERSONALITY, 0), PostStep);
            return;
        }
        P->step = 2;
        return;
    case 1:
        SetMonData(&gEnemyParty[0], MON_DATA_NICKNAME, P->nickBuf);
        P->step = 2;
        return;
    case 2:
        if (P->outcome == 7) GiveMonToPlayer(&gEnemyParty[0]);
        P->step = 3;
        return;
    case 3:
        for (int i = 0; i < 6; i++) {
            if (!(P->lvlMask & (1 << i))) continue;
            P->lvlMask &= ~(1 << i);
            u16 sp = EvoTarget(&gPlayerParty[i]);
            if (sp) { EvoConsumeItem(&gPlayerParty[i], GetMonData(&gPlayerParty[i], MON_DATA_SPECIES, 0), sp); gCB2_AfterEvolution = PostStep; EvolutionScene(&gPlayerParty[i], sp, 0x81, i); return; }
        }
        P->step = 4;
        return;
    default:
        gBattleOutcome = P->outcome;
        if (gBattleTypeFlags & 0x80000) *(volatile u16 *)0x020370D0 = P->outcome;      // Trainer Tower: the scripts read the result of the fight from VAR_RESULT (1 won, 2 lost, 3 drew); the game's own battle end sets it
        SetMainCallback2(P->finalCb);
        return;
    }
}

static void IdleFrame(Arena *A) {
    for (int i = 0; i < 4; i++) if (A->pm & (1 << i)) { A->act[i].moving = 0; UpdateActor(A, &A->act[i]); UploadFrame(A, &A->act[i], i); }
    UpdateAging(A);
}

static void FightFrame(Arena *A) {
    int pa[2], np = 0;
    for (int k = 0; k < 4; k += 2) if ((A->pm & (1 << k)) && A->act[k].alive && !A->act[k].retired) pa[np++] = k;
    if (np == 2) { PlayerInput(A, &A->act[pa[0]], 1); if (A->state != ST_FIGHT) return; PlayerInput(A, &A->act[pa[1]], 2); }
    else if (np == 1) PlayerInput(A, &A->act[pa[0]], 0);
    if (A->state != ST_FIGHT) return;
    for (int k = 1; k < 4; k += 2) {
        if (!(A->pm & (1 << k))) continue;
        Actor *e = &A->act[k];
        if (A->safari) SafariAi(A, e, &A->act[0]); else AiStep(A, e, FoeOf(A, e));
    }
    for (int i = 0; i < 4; i++) if (A->pm & (1 << i)) UpdateActor(A, &A->act[i]);
    SeparateActors(A);
    UpdateProjectiles(A);
    CaptureUpdate(A);
    UpdateAging(A);
    for (int i = 0; i < 4; i++) if (A->pm & (1 << i)) UploadFrame(A, &A->act[i], i);
    if (A->state != ST_FIGHT) return;
    if (A->safari && !gNumSafariBalls && A->capState == CAP_NONE && !A->ballCd && A->act[0].phase == PH_FREE && !A->outcome) {
        A->outcome = 8; A->endSlot = 1; A->state = ST_END; A->stateTimer = 0; A->endPhase = 0;   // out of safari balls
        return;
    }
    for (int i = 0; i < 4; i++) {
        if (!(A->pm & (1 << i))) continue;
        Actor *x = &A->act[i];
        if (x->alive || x->retired || x->fainted <= 40) continue;
        if (!(i & 1)) {                                   // one of ours fainted
            if ((NextAlive(A) >= 0 || (!A->giveUp && HasRevive())) && FoesPending(A)) { A->uiSlot = i; UiOpen(A, UI_SWITCH, 1); return; }
            x->retired = 1; WriteBack(x);
            if (!PlayersAlive(A)) { A->outcome = 2; A->state = ST_END; A->stateTimer = 0; A->endPhase = 0; A->endSlot = 1; return; }
        } else {                                          // a foe fainted
            if (A->capState != CAP_NONE) continue;
            A->outcome = 1; A->endSlot = i; A->state = ST_END; A->stateTimer = 0; A->endPhase = 0;
            return;
        }
    }
}

// ---------- real-time link battle (lockstep): both consoles run the same simulation; only the keys travel ----------
typedef struct { LinkCtx L; u8 txr[256], rxr[256]; struct Pokemon mon[4] __attribute__((aligned(4))); struct Pokemon rs[2][6] __attribute__((aligned(4))); u8 rn[2], rx[2]; } LinkBat;

// exchanges this frame's keys with the other console.  Returns 0 ok, 1 link lost, 2 out of sync.
static int LinkKeys(Arena *A, u16 *k) {
    LinkBat *B = (LinkBat *)A->lk; LinkCtx *L = &B->L;
    u16 mine = gMain.heldKeys & (A->dbl ? 0x3F7 : 0x3F3);    // START is not used in link battles; SELECT only in doubles (page of moves)
    B->txr[L->txLen++ & 255] = mine & 0xFF;
    B->txr[L->txLen++ & 255] = ((mine >> 8) & 3) | (A->lkHash << 2);
    L->rxLen += 2;
    L->guard = 600000;
    int tmo = A->frame < 400 ? 300 : 120;
    u16 lastV = *(volatile u16 *)0x04000006;
    while (L->rxPos < L->rxLen) {
        if (LinkTransfer(L)) { tmo = 120; continue; }
        u16 v = *(volatile u16 *)0x04000006;
        if (v >= 160 && lastV < 160 && --tmo <= 0) { L->guard = 4000; return 1; }
        lastV = v;
    }
    L->guard = 4000;
    u8 b0 = B->rxr[(L->rxPos - 2) & 255], b1 = B->rxr[(L->rxPos - 1) & 255];
    u16 peer = b0 | (u16)(b1 & 3) << 8;
    if (A->frame > 1 && (b1 >> 2) != A->lkHash) { if (++A->lkBad >= 4) return 2; } else A->lkBad = 0;
    k[A->lkMaster ? 0 : 1] = mine; k[A->lkMaster ? 1 : 0] = peer;
    return 0;
}

static u8 LinkHash(Arena *A) {
    u32 h = 0;
    for (int i = 0; i < 4; i++) { if (!(A->pm & (1 << i))) continue; Actor *a = &A->act[i]; h = h * 31 + (a->x >> 8) + (a->y >> 8) * 7 + a->hp * 13 + a->phase; }
    return (h ^ (h >> 6) ^ (h >> 12)) & 63;
}

static int SideDead(Arena *A, int side) {
    LinkBat *B = (LinkBat *)A->lk;
    if (B->rx[side] < B->rn[side]) return 0;                // the team still has Pokemon waiting
    for (int i = side; i < 4; i += 2) {
        if (!(A->pm & (1 << i))) continue;
        Actor *a = &A->act[i];
        if (a->alive || a->fainted <= 40) return 0;
    }
    return 1;
}

// a fainted Pokemon is replaced by the next one of its team (both consoles know both teams, so this is deterministic)
static void LinkSendOut(Arena *A) {
    LinkBat *B = (LinkBat *)A->lk;
    int mineSide = A->lkMaster ? 0 : 1;
    for (int q = 0; q < 4; q++) {
        if (!(A->pm & (1 << q))) continue;
        Actor *a = &A->act[q];
        int s = q & 1;
        if (a->alive || a->fainted <= 40 || B->rx[s] >= B->rn[s]) continue;
        u8 *d = (u8 *)&B->mon[q], *sr = (u8 *)&B->rs[s][B->rx[s]++];
        for (int i = 0; i < 100; i++) d[i] = sr[i];
        if (!InitActor(A, a, &B->mon[q], !(q & 1), 0, q)) { a->alive = 0; a->fainted = 99; continue; }
        a->x = ((q & 1) ? 176 : 64) << 8;
        a->y = (A->dbl ? (q < 2 ? 84 : 116) : (q & 1 ? 90 : 100)) << 8;
        a->invuln = 60; a->flash = 30;
        StartRelease(A, a, q);
        for (int i = 0; i < 4; i++) if (a->moves[i]) a->pp[i] = MV_PP(MV(a->moves[i]));
        char l[32]; l[0] = 0;
        Cat(l, s == mineSide ? "GO! " : "FOE "); Cat(l, (char *)a->name); Cat(l, s == mineSide ? "!" : " APPEARS!");
        Msg(A, l, 90);
    }
}

static void LinkFightFrame(Arena *A) {
    u16 k[2];
    int r = LinkKeys(A, k);
    if (r) { A->outcome = r == 1 ? 9 : 10; A->state = ST_END; A->stateTimer = 0; return; }
    u16 sh = gMain.heldKeys, sn = gMain.newKeys;
    for (int p = 0; p < 2; p++) {
        gMain.heldKeys = k[p]; gMain.newKeys = k[p] & ~A->lkHeld[p]; A->lkHeld[p] = k[p];
        A->page = A->lkPage[p];
        int a0 = (A->pm & (1 << p)) && A->act[p].alive, a2 = (A->pm & (4 << p)) && A->act[2 + p].alive;
        if (a0 && a2) { PlayerInput(A, &A->act[p], 1); PlayerInput(A, &A->act[2 + p], 2); }
        else if (a0) PlayerInput(A, &A->act[p], 0);
        else if (a2) PlayerInput(A, &A->act[2 + p], 0);
        A->lkPage[p] = A->page;
    }
    A->page = A->lkPage[A->lkMaster ? 0 : 1];
    gMain.heldKeys = sh; gMain.newKeys = sn;
    for (int i = 0; i < 4; i++) if (A->pm & (1 << i)) UpdateActor(A, &A->act[i]);
    SeparateActors(A);
    UpdateProjectiles(A);
    UpdateAging(A);
    for (int i = 0; i < 4; i++) if (A->pm & (1 << i)) UploadFrame(A, &A->act[i], i);
#ifdef ARENA_DEBUG
    { volatile u8 *kf = (volatile u8 *)0x0203F7D0; if (*kf) { Faint(A, &A->act[*kf - 1]); *kf = 0; } }
#endif
    LinkSendOut(A);
    A->lkHash = LinkHash(A);
    {   // team counters for the HUD (Pokemon still in the fight + waiting)
        LinkBat *B = (LinkBat *)A->lk;
        for (int sd = 0; sd < 2; sd++) { int n = B->rn[sd] - B->rx[sd]; for (int i = sd; i < 4; i += 2) if ((A->pm & (1 << i)) && A->act[i].alive) n++; A->lkLeft[sd] = n; }
    }
    int d0 = SideDead(A, 0), d1 = SideDead(A, 1);
    if (d0 || d1) { A->outcome = d0 && d1 ? 3 : (d1 ? 1 : 2); A->state = ST_END; A->stateTimer = 0; }
}

static void LinkBattleExit(Arena *A) {
    SetVBlankCallback(0);
    REG_DISPCNT = 0x80; REG_BLDCNT = 0; REG_BLDY = 0; REG_BLDALPHA = 0;
    *(Arena **)(&gMain.oamBuffer[127 * 8]) = 0;
    for (int k = 0; k < 4; k++) if (A->bstage[k]) Free(A->bstage[k]);
    Free(A->lk); Free(A);
    LINKMODE = 0;
    LK_SIOCNT = 0;
    gBattleTypeFlags = 0;
    gBattleOutcome = 4;
    SetMainCallback2(CB2_EndWildBattle);
}

static void LinkArenaMain(Arena *A) {
    A->frame++;
    switch (A->state) {
    case ST_FADEIN:
        if (A->fadeLevel) A->fadeLevel--; else { A->state = ST_INTRO; A->stateTimer = 0; }
        IdleFrame(A);
        break;
    case ST_INTRO:
        IdleFrame(A);
        if (++A->stateTimer >= 70) { A->state = ST_FIGHT; A->frame = 0; }
        break;
    case ST_FIGHT: LinkFightFrame(A); break;
    case ST_END: {
        for (int i = 0; i < 4; i++) if (A->pm & (1 << i)) { A->act[i].moving = 0; UpdateActor(A, &A->act[i]); UploadFrame(A, &A->act[i], i); }
        UpdateProjectiles(A); UpdateAging(A);
        LinkPump(&((LinkBat *)A->lk)->L, 8);          // keep serving transfers so the other console receives our last keys
        if (A->stateTimer == 0) {
            int o = A->outcome, me = A->lkMaster ? 1 : 2;
            Msg(A, o == 3 ? "DRAW!" : o == 9 ? "LINK LOST" : o == 10 ? "OUT OF SYNC" : (o == me ? "YOU WIN!" : "YOU LOSE..."), 150);
        }
        if (++A->stateTimer > 160) A->state = ST_FADEOUT;
        break;
    }
    case ST_FADEOUT:
        IdleFrame(A);
        if (A->fadeLevel < 16) A->fadeLevel++;
        else { LinkBattleExit(A); return; }
        break;
    }
    Render(A);
    HudDraw(A);
    A->dispcnt = 0x1340;
}

void ArenaMain(void) {
    Arena *A = AR();
    if (A->link) { LinkArenaMain(A); return; }
    A->frame++;
    if (A->cryPending && ++A->cryPending > 100) { m4aMPlayVolumeControl(gMPlayInfo_BGM, 0xFFFF, 0x100); A->cryPending = 0; }
    switch (A->state) {
    case ST_FADEIN:
        if (A->fadeLevel) A->fadeLevel--; else { A->state = ST_INTRO; A->stateTimer = 0; PlayCry1(A->act[1].species, 25); A->cryPending = 1; }
        IdleFrame(A);
        break;
    case ST_INTRO:
        IdleFrame(A);
        if (++A->stateTimer >= 70) A->state = ST_FIGHT;
        break;
    case ST_FIGHT: FightFrame(A); break;
    case ST_END: EndFrame(A); break;
    case ST_UI:
        for (int i = 0; i < 4; i++) if (A->pm & (1 << i)) UploadFrame(A, &A->act[i], i);
        UiFrame(A);
        break;
    case ST_FADEOUT:
        IdleFrame(A);
        if (A->fadeLevel < 16) A->fadeLevel++;
        else { ArenaExit(A); return; }
        break;
    }
    Render(A);
    HudDraw(A);
    A->dispcnt = 0x1340;
}

// ---------- entry points (hooked) ----------
// The game's main loop runs a wireless-adapter key handler (state 0 of the table at ROM 0x0813B890)
// that reacts to L/R: it plays a buzzer and, in some states, tears down the VBlank callback.
// make_rom redirects state 0 here; while the arena is the main callback the handler is skipped.
// ---------- cheat menu (L in the overworld) ----------
// While the player is free in the overworld, L opens this screen instead of the game's help system.
typedef struct { u16 bgmap[1024]; u8 sel, done, dirty, pad; } CheatMenu;
#define CM() (*(CheatMenu **)(&gMain.oamBuffer[127 * 8]))

static void CheatVBlank(void) {
    CheatMenu *M = CM();
    if (!M) return;
    REG_DISPCNT = 0x0100;
    if (M->dirty) { Dma3(M->bgmap, (void *)(VRAM_BASE + 0xF800), 512); M->dirty = 0; }
}

static void CmText(CheatMenu *M, int x, int y, const char *s, int pal) {
    u16 *m = M->bgmap + y * 32;
    for (; *s && x < 32; s++, x++) {
        int c = (u8)*s;
        if (c >= 'a' && c <= 'z') c -= 32;
        if (c < 32 || c > 95) c = 32;
        m[x] = (c - 32) | (pal << 12);
    }
}

void LinkScreenInit(void);
static void CheatDraw(CheatMenu *M) {
    for (int i = 0; i < 1024; i++) M->bgmap[i] = 0;
    CmText(M, 2, 1, "- CHEATS -", 3);
    CmText(M, 2, 3, "UP/DOWN  A:CHANGE  B:BACK", 2);
    static const char *const nm[4] = {"EASY CAPTURE", "ALL POKEMON", "EASY MODE", "EXP FOR ALL"};
    for (int k = 0; k < 4; k++) {
        char l[32]; int on = CheatOn(k);
        l[0] = M->sel == k ? '>' : ' '; l[1] = ' '; l[2] = 0;
        Cat(l, nm[k]);
        while (slen(l) < 20) Cat(l, " ");
        Cat(l, on ? "[ON ]" : "[OFF]");
        CmText(M, 2, 5 + k * 2, l, M->sel == k ? 3 : (on ? 0 : 2));
    }
    CmText(M, 2, 13, M->sel == 4 ? "> LINK BATTLE (CABLE)" : "  LINK BATTLE (CABLE)", M->sel == 4 ? 3 : 0);
    CmText(M, 2, 15, M->sel == 5 ? "> BACK TO THE GAME" : "  BACK TO THE GAME", M->sel == 5 ? 3 : 0);
    if (M->sel == 0) {
        CmText(M, 2, 17, "ANY BALL ALWAYS CATCHES THE", 2);
        CmText(M, 2, 18, "POKEMON, EVEN LEGENDARIES.", 2);
    } else if (M->sel == 1) {
        CmText(M, 2, 17, "WILD POKEMON ON THE MAP ARE", 2);
        CmText(M, 2, 18, "RANDOM: ALL 386 SPECIES,", 2);
        CmText(M, 2, 19, "LEGENDARIES, OTHER REGIONS.", 2);
    } else if (M->sel == 2) {
        CmText(M, 2, 17, "ENEMY POKEMON DEAL ALMOST NO", 2);
        CmText(M, 2, 18, "DAMAGE, EVEN WITH TYPE", 2);
        CmText(M, 2, 19, "ADVANTAGE (WATER VS FIRE...).", 2);
    } else if (M->sel == 3) {
        CmText(M, 2, 17, "ON: THE WHOLE TEAM GETS ALL", 2);
        CmText(M, 2, 18, "THE EXP.  OFF: ONLY THOSE", 2);
        CmText(M, 2, 19, "THAT FOUGHT SHARE IT.", 2);
    }
    M->dirty = 1;
}

void CheatMenuMain(void) {
    CheatMenu *M = CM();
    u16 k = gMain.newKeys;
    int redraw = 0;
    if (k & 0x40) { M->sel = M->sel ? M->sel - 1 : 5; redraw = 1; }
    if (k & 0x80) { M->sel = M->sel < 5 ? M->sel + 1 : 0; redraw = 1; }
    if (k & 0x01) {
        if (M->sel < 4) { CheatSet(M->sel, !CheatOn(M->sel)); redraw = 1; }
        else if (M->sel == 4) {
            SetVBlankCallback(0);
            *(CheatMenu **)(&gMain.oamBuffer[127 * 8]) = 0;
            Free(M);
            SetMainCallback2(LinkScreenInit);
            return;
        }
        else M->done = 1;
    }
    if (k & 0x02) M->done = 1;
    if (M->done) {
        SetVBlankCallback(0);
        REG_DISPCNT = 0x80;
        *(CheatMenu **)(&gMain.oamBuffer[127 * 8]) = 0;
        Free(M);
        gBattleTypeFlags = 0;
        gBattleOutcome = 4;
        SetMainCallback2(CB2_EndWildBattle);               // reloads the map exactly where the player stands
        return;
    }
    if (redraw) CheatDraw(M);
}

void CheatMenuInit(void) {
    CheatMenu *M = (CheatMenu *)AllocZeroed(sizeof(CheatMenu));
    if (!M) { SetMainCallback2(CB2_Overworld); return; }
    HwReset();
    ResetSpriteData(); ResetTasks(); FreeAllSpritePalettes(); ResetPaletteFade();
    *(CheatMenu **)(&gMain.oamBuffer[127 * 8]) = M;
    CopyTiles(gFontTiles, 64, VRAM_BASE);
    u16 *bp = (u16 *)PLTT_BASE;
    for (int i = 0; i < 16; i++) { bp[i] = gBgPalText[i]; bp[32 + i] = gBgPalText[i]; bp[48 + i] = gBgPalText[i]; }
    bp[0] = 0;
    bp[32 + 1] = 0x5EF7;                      // gray
    bp[48 + 1] = 0x1B7F;                      // yellow
    REG_BG0CNT = 0x1F00;
    REG_BG0HOFS = 0; REG_BG0VOFS = 0;
    CheatDraw(M);
    SetVBlankCallback(CheatVBlank);
    SetMainCallback2(CheatMenuMain);
}

// ---------- link screen: exchanges the parties over the cable and shows the opponent's team ----------
#define LK_PARTY_BYTES 600
#define LK_MSG_BYTES (8 + LK_PARTY_BYTES + 2)
typedef struct { u16 bgmap[1024]; u8 sel, done, dirty, pad; u8 st, wait; u16 frames; u8 pressed, pad2, lvl, dbl; u8 gotx[4], gorx[4]; u8 mode, curs, offOwn, offPeer;
                 LinkCtx L; u8 txb[LK_MSG_BYTES] __attribute__((aligned(4))), rxb[LK_MSG_BYTES] __attribute__((aligned(4))); } LinkScr;

static void Num3(char *out, int v) { char d[4]; d[0] = '0' + v / 100 % 10; d[1] = '0' + v / 10 % 10; d[2] = '0' + v % 10; d[3] = 0; Cat(out, d[0] == '0' ? d + 1 : d); }
static void MonLine(struct Pokemon *m, char *l) {
    l[0] = 0; MonName(m, l);
    while (slen(l) < 12) Cat(l, " ");
    Cat(l, "LV"); Num3(l, GetMonData(m, MON_DATA_LEVEL, 0));
}

static void LinkScrDraw(LinkScr *M) {
    CheatMenu *C = (CheatMenu *)M;
    struct Pokemon *op = (struct Pokemon *)(M->rxb + 8);
    int on = M->rxb[2] > 6 ? 6 : M->rxb[2];
    for (int i = 0; i < 1024; i++) M->bgmap[i] = 0;
    CmText(C, 2, 1, M->st >= 5 && M->st <= 7 ? "- LINK TRADE -" : "- LINK -", 3);
    if (M->st == 0) {
        CmText(C, 2, 4, "CONNECT THE LINK CABLE.", 0);
        CmText(C, 2, 5, "WAITING FOR THE OTHER GBA...", 0);
        CmText(C, 2, 8, M->L.master ? "YOU ARE: PLAYER 1" : "YOU ARE: PLAYER 2", 2);
        CmText(C, 2, 10, "B: CANCEL", 2);
    } else if (M->st == 1) {
        CmText(C, 2, 4, "CONNECTED! EXCHANGING TEAMS...", 0);
    } else if (M->st == 2) {
        CmText(C, 2, 3, "OPPONENT TEAM:", 0);
        for (int i = 0; i < on; i++) { char l[28]; MonLine(&op[i], l); CmText(C, 4, 5 + i * 2, l, 3); }
        { char lv[28]; lv[0] = 0; Cat(lv, "LEVEL: "); if (M->lvl) { Num3(lv, M->lvl); Cat(lv, " (BOTH)"); } else Cat(lv, "ORIGINAL");
          CmText(C, 2, 16, lv, 3);
          CmText(C, 2, 17, M->dbl ? "MODE: DOUBLES 2X2 (SELECT)" : "MODE: SINGLES 1X1 (SELECT)", 3);
          if (!M->pressed) CmText(C, 2, 18, "D-PAD: LEVEL", 2); }
        CmText(C, 2, 19, M->pressed ? "WAITING FOR THE OTHER PLAYER..." : "A:BATTLE START:TRADE B:BACK", M->pressed ? 3 : 2);
    } else if (M->st == 5) {                                   // trade
        if (M->mode == 0) {
            CmText(C, 2, 3, "CHOOSE A POKEMON TO GIVE:", 0);
            for (int i = 0; i < gPlayerPartyCount && i < 6; i++) {
                char l[32]; l[0] = M->curs == i ? '>' : ' '; l[1] = ' '; l[2] = 0;
                char q[24]; MonLine(&gPlayerParty[i], q); Cat(l, q);
                CmText(C, 2, 5 + i * 2, l, M->curs == i ? 3 : 0);
            }
            CmText(C, 2, 19, "A: OFFER   B: CANCEL", 2);
        } else if (M->mode == 1 || M->mode == 3) {
            CmText(C, 2, 5, M->mode == 1 ? "WAITING FOR THEIR OFFER..." : "WAITING FOR THEIR CONFIRMATION...", 3);
        } else {
            char l[32], q[24];
            CmText(C, 2, 4, "YOU GIVE:", 0); MonLine(&gPlayerParty[M->offOwn], q); CmText(C, 4, 6, q, 3);
            CmText(C, 2, 9, "YOU GET:", 0); MonLine(&op[M->offPeer], q); CmText(C, 4, 11, q, 3);
            CmText(C, 2, 19, "A: CONFIRM   B: CANCEL", 2);
        }
    } else if (M->st == 7) {
        char q[24]; MonLine(&gPlayerParty[M->offOwn], q);
        CmText(C, 2, 4, "TRADE COMPLETE! YOU GOT:", 0); CmText(C, 4, 6, q, 3);
        CmText(C, 2, 19, "A: BACK TO THE GAME", 2);
    } else {
        CmText(C, 2, 4, M->pad2 == 1 ? "NO USABLE POKEMON (YOURS)" : M->pad2 == 4 ? "NO USABLE POKEMON (THEIRS)" : M->pad2 == 2 ? "OUT OF MEMORY." : M->pad2 == 5 ? "THE OTHER PLAYER CHOSE" : "CONNECTION FAILED.", 0);
        if (M->pad2 == 5) CmText(C, 2, 5, "SOMETHING ELSE.", 0);
        CmText(C, 2, 7, "A/B: BACK", 2);
    }
    M->dirty = 1;
}

static void LinkScrExit(LinkScr *M) {
    SetVBlankCallback(0);
    REG_DISPCNT = 0x80;
    *(LinkScr **)(&gMain.oamBuffer[127 * 8]) = 0;
    LK_SIOCNT = 0;
    Free(M);
    gBattleTypeFlags = 0;
    gBattleOutcome = 4;
    SetMainCallback2(CB2_EndWildBattle);                   // reloads the map where the player stands
}

static int LeadFrom(struct Pokemon *arr, int cnt, int from) {
    for (int i = from; i < cnt && i < 6; i++) {
        u16 sp = GetMonData(&arr[i], MON_DATA_SPECIES, 0);
        if (!sp || sp > 411) continue;
        if (GetMonData(&arr[i], MON_DATA_SANITY_IS_EGG, 0)) continue;
        if (GetMonData(&arr[i], MON_DATA_HP, 0) == 0) continue;
        if (!RecFor(SpeciesToNationalPokedexNum(sp))) continue;
        return i;
    }
    return -1;
}

static void LinkBattleStart(LinkScr *M) {
    int master = M->L.master;
    struct Pokemon *rp = (struct Pokemon *)(M->rxb + 8);
    int rc = M->rxb[2] > 6 ? 6 : M->rxb[2];
    int dbl = (master ? M->gotx[1] : M->gorx[1]) == 2;
    int li = LeadFrom(gPlayerParty, gPlayerPartyCount, 0), ri = LeadFrom(rp, rc, 0);
    if (li < 0 || ri < 0) { M->st = 3; M->pad2 = li < 0 ? 1 : 4; M->pressed = 0; LinkScrDraw(M); return; }       // somebody has no usable Pokemon
    Arena *A = (Arena *)AllocZeroed(sizeof(Arena));
    LinkBat *B = (LinkBat *)AllocZeroed(sizeof(LinkBat));
    if (!A || !B) { if (A) Free(A); if (B) Free(B); M->st = 3; M->pad2 = 2; LinkScrDraw(M); return; }
    int ms = master ? 0 : 1, hs = master ? 1 : 0;                 // team 0 = console 1 (left), team 1 = console 2 (right)
    for (int t = 0; t < 2; t++) {                                  // the whole team of each side, in party order
        struct Pokemon *src = t == ms ? gPlayerParty : rp;
        int cnt = t == ms ? gPlayerPartyCount : rc;
        if (cnt > 6) cnt = 6;
        for (int i = 0; i < cnt; i++) {
            if (LeadFrom(src, cnt, i) != i) continue;
            u8 *d = (u8 *)&B->rs[t][B->rn[t]++], *sr = (u8 *)&src[i];
            for (int j = 0; j < 100; j++) d[j] = sr[j];
        }
    }
    int pmask = 0;
    for (int t = 0; t < 2; t++)
        for (int k = 0; k < (dbl ? 2 : 1); k++) {
            if (B->rx[t] >= B->rn[t]) break;
            int q = t + 2 * k;
            u8 *d = (u8 *)&B->mon[q], *sr = (u8 *)&B->rs[t][B->rx[t]++];
            for (int j = 0; j < 100; j++) d[j] = sr[j];
            pmask |= 1 << q;
        }
    u32 own = M->txb[4] | M->txb[5] << 8 | M->txb[6] << 16 | (u32)M->txb[7] << 24;
    u32 hisn = M->rxb[4] | M->rxb[5] << 8 | M->rxb[6] << 16 | (u32)M->rxb[7] << 24;
    u32 seed = (master ? own : hisn) * 0x9E3779B1u + (master ? hisn : own);
    {   // same level for both sides (the master's choice); full HP, no status; applies to the whole team
        int lv = (master ? M->gotx[0] : M->gorx[0]) - 1;
        for (int t = 0; t < 2; t++)
            for (int q = 0; q < B->rn[t]; q++) {
                struct Pokemon *m = &B->rs[t][q];
                if (lv > 0) {
                    u16 sp = GetMonData(m, MON_DATA_SPECIES, 0);
                    u8 l8 = lv; SetMonData(m, MON_DATA_LEVEL, &l8);
                    u32 ex = gExperienceTables[gBaseStats[(u32)sp * 28 + 19] * 101 + lv]; SetMonData(m, MON_DATA_EXP, &ex);
                    CalculateMonStats(m);
                }
                u16 hp = GetMonData(m, MON_DATA_MAX_HP, 0); SetMonData(m, MON_DATA_HP, &hp);
                u32 st = 0; SetMonData(m, MON_DATA_STATUS, &st);
            }
        for (int q = 0; q < 4; q++)                                // the fighters already copied out of the lists
            if (pmask & (1 << q)) { u8 *d = (u8 *)&B->mon[q], *sr = (u8 *)&B->rs[q & 1][q >> 1]; for (int j = 0; j < 100; j++) d[j] = sr[j]; }
    }
    B->L = M->L;
    B->L.tx = B->txr; B->L.rx = B->rxr; B->L.txPos = B->L.txLen = B->L.rxPos = B->L.rxLen = 0; B->L.mask = 255;
    Free(M);
    LINKMODE = seed | 1;
    HwReset();
    ResetSpriteData(); ResetTasks(); FreeAllSpritePalettes(); ResetPaletteFade();
    *(Arena **)(&gMain.oamBuffer[127 * 8]) = A;
    A->terrain = 0;
    *(volatile u8 *)0x2022B50 = 0;
    LoadGfx(A);
    A->link = 1; A->lkMaster = master; A->lk = B; A->dbl = dbl;
    for (int q = 0; q < 4; q++) {
        if (!(pmask & (1 << q))) continue;
        InitActor(A, &A->act[q], &B->mon[q], !(q & 1), 0, q);
        A->act[q].x = ((q & 1) ? 176 : 64) << 8;
        A->act[q].y = (dbl ? (q < 2 ? 84 : 116) : (q & 1 ? 90 : 100)) << 8;
        for (int i = 0; i < 4; i++) if (A->act[q].moves[i]) A->act[q].pp[i] = MV_PP(MV(A->act[q].moves[i]));
    }
    A->pm = pmask; A->isTrainer = 1;
    for (int q = 0; q < 4; q++) if (pmask & (1 << q)) StartRelease(A, &A->act[q], q);
    A->pm = pmask; A->isTrainer = 1; A->enemyCnt = 1; A->endSlot = 1;
    Cat(A->tname, "LINK");
    A->state = ST_FADEIN; A->fadeLevel = 16; A->dispcnt = 0x80;
    Msg(A, "LINK BATTLE!", 100);
    SetVBlankCallback(ArenaVBlank);
    SetMainCallback2(ArenaMain);
}

static void TradeBegin(LinkScr *M) {
    M->st = 5; M->mode = 0; M->curs = 0; M->pressed = 0;
    M->L.tx = M->gotx; M->L.txPos = 0; M->L.txLen = 0; M->L.rx = M->gorx; M->L.rxPos = 0; M->L.rxLen = 2;
    M->gotx[0] = M->gotx[1] = M->gorx[0] = M->gorx[1] = 0;
    LinkScrDraw(M);
}

void LinkScreenMain(void) {
    LinkScr *M = (LinkScr *)CM();
    u16 k = gMain.newKeys;
    if ((k & 0x02) && M->st != 7) { LinkScrExit(M); return; }
    if (M->st == 0) {
        M->frames++;
        LinkPump(&M->L, 1);
        if (M->L.transfers > 2 && (M->L.rxPos || M->L.txPos)) { M->st = 1; LinkScrDraw(M); M->wait = 2; }   // partner found
        else if (M->frames > 900) { M->st = 3; LinkScrDraw(M); }                                                  // 15 s without a partner
    } else if (M->st == 1) {
        if (M->wait) { M->wait--; return; }                                  // let the text appear
        int ok = LinkExchange(&M->L, 2000);
        if (ok) {
            u16 ck = 0;
            for (int i = 0; i < LK_MSG_BYTES - 2; i++) ck += M->rxb[i];
            ok = M->rxb[0] == 'P' && M->rxb[1] == 'K' && ck == (u16)(M->rxb[LK_MSG_BYTES - 2] | M->rxb[LK_MSG_BYTES - 1] << 8);
        }
        M->st = ok ? 2 : 3; LinkScrDraw(M);
        if (ok) { M->L.tx = M->gotx; M->L.txPos = 0; M->L.txLen = 0; M->L.rx = M->gorx; M->L.rxPos = 0; M->L.rxLen = 2; }   // 2-byte handshake: [level+1 | 0xF0 = trade, singles/doubles]
    } else if (M->st == 2) {
        LinkPump(&M->L, 4);
        if (!M->pressed) {
            int l = M->lvl, o = l;
            if (k & 0x10) l++; if (k & 0x20) l--; if (k & 0x40) l += 10; if (k & 0x80) l -= 10;
            if (l < 0) l = 0; if (l > 100) l = 100;
            if (l != o) { M->lvl = l; LinkScrDraw(M); }
            if (k & 0x04) { M->dbl ^= 1; LinkScrDraw(M); }
            if (k & 0x09) {                                                  // A = battle, START = trade
                M->pressed = (k & 0x01) ? 1 : 2;
                M->gotx[0] = M->pressed == 1 ? M->lvl + 1 : 0xF0; M->gotx[1] = M->dbl + 1; M->L.txLen = 2;
                LinkScrDraw(M);
            }
        }
        if (M->pressed && M->L.txPos >= 2 && M->L.rxPos >= 2) {
            int peer = M->gorx[0] == 0xF0 ? 2 : 1;
            if (peer != M->pressed) { M->st = 3; M->pad2 = 5; M->pressed = 0; LinkScrDraw(M); }
            else if (M->pressed == 1) LinkBattleStart(M);
            else TradeBegin(M);
        }
    } else if (M->st == 5) {                                                 // trade
        LinkPump(&M->L, 4);
        int n = gPlayerPartyCount > 6 ? 6 : gPlayerPartyCount;
        if (M->mode == 0) {
            int c = M->curs;
            if ((k & 0x40) && c > 0) c--;
            if ((k & 0x80) && c < n - 1) c++;
            if (c != M->curs) { M->curs = c; LinkScrDraw(M); }
            if (k & 0x01) { M->offOwn = M->curs; M->gotx[0] = M->curs + 1; M->L.txLen = 1; M->mode = 1; LinkScrDraw(M); }
        }
        if (M->mode == 1 && M->L.txPos >= 1 && M->L.rxPos >= 1) {
            int pr = M->gorx[0] - 1;
            if (pr < 0 || pr >= (M->rxb[2] > 6 ? 6 : M->rxb[2])) { M->st = 3; M->pad2 = 0; LinkScrDraw(M); return; }
            M->offPeer = pr; M->mode = 2; LinkScrDraw(M);
        } else if (M->mode == 2 && (k & 0x01)) { M->gotx[1] = 1; M->L.txLen = 2; M->mode = 3; LinkScrDraw(M); }
        if (M->mode == 3 && M->L.txPos >= 2 && M->L.rxPos >= 2 && M->gorx[1] == 1) {
            struct Pokemon *op = (struct Pokemon *)(M->rxb + 8);
            u8 *d = (u8 *)&gPlayerParty[M->offOwn], *sr = (u8 *)&op[M->offPeer];
            for (int i = 0; i < 100; i++) d[i] = sr[i];
            u16 nat = SpeciesToNationalPokedexNum(GetMonData(&gPlayerParty[M->offOwn], MON_DATA_SPECIES, 0));
            GetSetPokedexFlag(nat, 2); GetSetPokedexFlag(nat, 3);
            M->st = 7; M->wait = 0; LinkScrDraw(M);
        }
    } else if (M->st == 7) {
        LinkPump(&M->L, 4);                                                  // keep serving transfers so the other side gets our last acknowledgement
        if (M->wait < 120) M->wait++;
        else if (k & 0x01) { LinkScrExit(M); return; }
    } else if (M->st == 3 && (k & 0x01)) { LinkScrExit(M); return; }
}

void LinkScreenInit(void) {
    LinkScr *M = (LinkScr *)AllocZeroed(sizeof(LinkScr));
    if (!M) { SetMainCallback2(CB2_Overworld); return; }
    HwReset();
    ResetSpriteData(); ResetTasks(); FreeAllSpritePalettes(); ResetPaletteFade();
    *(LinkScr **)(&gMain.oamBuffer[127 * 8]) = M;
    CopyTiles(gFontTiles, 64, VRAM_BASE);
    u16 *bp = (u16 *)PLTT_BASE;
    for (int i = 0; i < 16; i++) { bp[i] = gBgPalText[i]; bp[32 + i] = gBgPalText[i]; bp[48 + i] = gBgPalText[i]; }
    bp[0] = 0; bp[32 + 1] = 0x5EF7; bp[48 + 1] = 0x1B7F;
    REG_BG0CNT = 0x1F00; REG_BG0HOFS = 0; REG_BG0VOFS = 0;
    u8 *t = M->txb;
    t[0] = 'P'; t[1] = 'K'; t[2] = gPlayerPartyCount; t[3] = 0;
    { u32 nz = Random() | ((u32)Random() << 16); t[4] = nz; t[5] = nz >> 8; t[6] = nz >> 16; t[7] = nz >> 24; }   // seed contribution
    for (int i = 0; i < LK_PARTY_BYTES; i++) t[8 + i] = ((u8 *)gPlayerParty)[i];
    u16 ck = 0; for (int i = 0; i < LK_MSG_BYTES - 2; i++) ck += t[i];
    t[LK_MSG_BYTES - 2] = ck & 0xFF; t[LK_MSG_BYTES - 1] = ck >> 8;
    M->lvl = 20;
    LinkOpen(&M->L);
    M->L.tx = M->txb; M->L.txLen = LK_MSG_BYTES; M->L.rx = M->rxb; M->L.rxLen = LK_MSG_BYTES;
    LinkScrDraw(M);
    SetVBlankCallback(CheatVBlank);
    SetMainCallback2(LinkScreenMain);
}

// called from the key handler below: returns 1 when the L press was taken by the cheat menu
int LinkKeyCheck(void) {
    if (gMain.callback2 != CB2_Overworld) return 0;
    if ((gMain.newKeys & 0x300) != 0x200) return 0;                 // L alone
    if (!FieldFree()) return 0;                                     // dialogs, scripts and menus keep the help system
    SetMainCallback2(CheatMenuInit);
    return 1;
}

// The game's main loop runs a key handler (state 0 of the table at ROM 0x0813B890) that reacts to L/R: it opens the
// help system (and, for the wireless adapter, plays a buzzer / tears down the VBlank callback).
// make_rom redirects state 0 here: while the arena is the main callback it is skipped, and L alone in the free
// overworld opens the cheat menu instead of the help system.
__attribute__((naked, used)) void LinkKeyGuard(void) {
    __asm__ volatile(
        ".thumb\n"
        "ldr r0, =0x030030F4\n"
        "ldr r0, [r0]\n"
        "ldr r1, =ArenaMain\n"
        "cmp r0, r1\n"
        "beq 2f\n"
        "bl LinkKeyCheck\n"
        "cmp r0, #0\n"
        "bne 2f\n"
        "ldr r1, =0x0813B8B5\n"
        "bx r1\n"
        "2:\n"
        "movs r0, #0\n"
        "ldr r1, =0x0813BB29\n"
        "bx r1\n"
        ".ltorg\n");
}


// ---------- "evolve?" question for evolutions in the overworld (Rare Candy in the party menu) ----------
// A ROM veneer sends the call to BeginEvolutionScene() from PartyMenuTryEvolution() here. A Pokemon the player refused
// before never evolves; otherwise a YES / NO screen is shown, and NO marks the Pokemon (Cute contest stat = 255).
typedef struct { u16 bgmap[1024]; u8 sel, done, dirty, ans; u8 partyId, canStop; u16 species; u32 vb; char nm[12]; } EvoAsk;
extern void BeginEvolutionScene(struct Pokemon *mon, u16 species, u8 canStop, u8 partyId);
#define GTASK(i) ((volatile u8 *)(0x03005090 + (i) * 0x28))
#define CB2_AFTER_EVO (*(void (**)(void))0x0300537C)
extern u8 CreateTask(void (*func)(u8), u8 priority);
static void EvoStub(u8 id) { (void)id; }

static void EvoAskDraw(EvoAsk *M) {
    for (int i = 0; i < 1024; i++) M->bgmap[i] = 0;
    CmText((CheatMenu *)M, 3, 5, "DO YOU WANT TO EVOLVE", 0);
    char l[20]; l[0] = 0; Cat(l, M->nm); Cat(l, "?");
    CmText((CheatMenu *)M, 3, 7, l, 3);
    CmText((CheatMenu *)M, 5, 10, M->sel == 0 ? "> YES" : "  YES", M->sel == 0 ? 3 : 0);
    CmText((CheatMenu *)M, 5, 12, M->sel == 1 ? "> NO (NEVER EVOLVES)" : "  NO (NEVER EVOLVES)", M->sel == 1 ? 3 : 0);
    M->dirty = 1;
}

void EvoAskMain(void) {
    EvoAsk *M = (EvoAsk *)CM();
    u16 k = gMain.newKeys;
    int redraw = 0;
    if (k & 0x40) { M->sel = M->sel ? 0 : 1; redraw = 1; }
    if (k & 0x80) { M->sel = M->sel ? 0 : 1; redraw = 1; }
    if (k & 0x01) M->ans = M->sel == 0 ? 1 : 2;
    if (k & 0x02) M->ans = 2;
    if (M->ans) {
        int yes = M->ans == 1;
        u8 pid = M->partyId, cs = M->canStop; u16 sp = M->species; u32 vb = M->vb;
        SetVBlankCallback((void (*)(void))vb);          // the party menu's own: the evolution scene needs its palette transfer
        REG_DISPCNT = 0x80;
        *(EvoAsk **)(&gMain.oamBuffer[127 * 8]) = 0;
        Free(M);
        if (yes) BeginEvolutionScene(&gPlayerParty[pid], sp, cs, pid);
        else {
            u8 mark = 255; SetMonData(&gPlayerParty[pid], MON_DATA_CUTE, &mark);
            SetMainCallback2(CB2_AFTER_EVO);
        }
        return;
    }
    if (redraw) EvoAskDraw(M);
}

void EvoAskInit(void) {
    int id = -1;
    for (int i = 0; i < 16; i++) if (GTASK(i)[4] && *(volatile u32 *)GTASK(i) == ((u32)EvoStub | 1)) { id = i; break; }
    if (id < 0) { SetMainCallback2(CB2_AFTER_EVO); return; }
    volatile s16 *d = (volatile s16 *)(GTASK(id) + 8);
    u8 pid = d[4], cs = d[3]; u16 sp = d[2];
    EvoAsk *M = (EvoAsk *)AllocZeroed(sizeof(EvoAsk));
    if (!M) { BeginEvolutionScene(&gPlayerParty[pid], sp, cs, pid); return; }
    M->partyId = pid; M->canStop = cs; M->species = sp; M->vb = (u16)d[5] | ((u32)(u16)d[6] << 16);
    MonName(&gPlayerParty[pid], M->nm);
    HwReset();
    ResetSpriteData(); ResetTasks(); FreeAllSpritePalettes(); ResetPaletteFade();
    *(EvoAsk **)(&gMain.oamBuffer[127 * 8]) = M;
    CopyTiles(gFontTiles, 64, VRAM_BASE);
    u16 *bp = (u16 *)PLTT_BASE;
    for (int i = 0; i < 16; i++) { bp[i] = gBgPalText[i]; bp[32 + i] = gBgPalText[i]; bp[48 + i] = gBgPalText[i]; }
    bp[0] = 0;
    bp[32 + 1] = 0x5EF7;
    bp[48 + 1] = 0x1B7F;
    REG_BG0CNT = 0x1F00;
    REG_BG0HOFS = 0; REG_BG0VOFS = 0;
    EvoAskDraw(M);
    SetVBlankCallback(CheatVBlank);
    SetMainCallback2(EvoAskMain);
}

void EvoGate(struct Pokemon *mon, u16 species, u8 canStop, u8 partyId) {
    if (GetMonData(mon, MON_DATA_CUTE, 0) == 255) { SetMainCallback2(CB2_AFTER_EVO); return; }
    u8 id = CreateTask(EvoStub, 0);
    volatile s16 *d = (volatile s16 *)(GTASK(id) + 8);
    u32 vb = *(volatile u32 *)(0x030030F0 + 0xC);
    d[2] = species; d[3] = canStop; d[4] = partyId; d[5] = (s16)(vb & 0xFFFF); d[6] = (s16)(vb >> 16);
    SetMainCallback2(EvoAskInit);
}

void ArenaEntry(void) {
    int r = ArenaStart();
    *(volatile u32 *)0x0203F7F0 = GetMonData(&gEnemyParty[0], MON_DATA_PERSONALITY, 0);   // remembers the enemy team of this battle (Trainer Tower freshness check)
    if (r) return;
    CB2_InitBattle();
}

#ifdef ARENA_DEBUG
// debug: link ping - exchanges 64 bytes with the other console and records the result in EWRAM (see tools)
void LinkTest(void) {
    volatile u8 *m = (volatile u8 *)0x0203F700;
    LinkCtx *L = (LinkCtx *)m;
    u8 *txb = (u8 *)(m + 0x40), *rxb = (u8 *)(m + 0x80);
    if (!L->init) {
        LinkOpen(L);
        for (int i = 0; i < 64; i++) { txb[i] = (u8)(i * 7 + (L->master ? 0x11 : 0x22)); rxb[i] = 0; }
        L->tx = txb; L->txLen = 64; L->rx = rxb; L->rxLen = 64;
    }
    LinkPump(L, 8);
}
#endif

#ifdef ARENA_DEBUG
extern u8 AddBagItem(u16 item, u16 count);
void ArenaDebugEntry(void) {
    gBattleTypeFlags = 0;
    if (!gPlayerPartyCount) {
        CreateMon(&gPlayerParty[0], 25, 12, 32, 0, 0, 0, 0);
        CreateMon(&gPlayerParty[1], 4, 10, 32, 0, 0, 0, 0);
        gPlayerPartyCount = 2;
        AddBagItem(4, 10); AddBagItem(3, 3); AddBagItem(1, 1);
    }
    CreateMon(&gEnemyParty[0], 19, 6, 32, 0, 0, 0, 0);
    gMain.savedCallback = CB2_EndWildBattle;
    if (!ArenaStart()) SetMainCallback2(0);
}

#ifdef ARENA_DEBUG
// debug: species prm[2] level prm[3] holding prm[9]; writes EvoTarget to 0x0203F030
void DebugEvoT(void) {
    volatile u16 *prm = (volatile u16 *)0x0203F000;
    CreateMon(&gPlayerParty[0], prm[2], prm[3], 32, 0, 0, 0, 0);
    u16 hi = prm[9]; SetMonData(&gPlayerParty[0], MON_DATA_HELD_ITEM, &hi);
    ((volatile u16 *)0x0203F030)[0] = EvoTarget(&gPlayerParty[0]);
    ((volatile u16 *)0x0203F030)[1] = 0x7777;
}
#endif
extern void CB2_Overworld(void);
// debug: lead = species prm[2] at level prm[3] plus Rare Candies, back to the overworld
void DebugCandy(void) {
    volatile u16 *prm = (volatile u16 *)0x0203F000;
    CreateMon(&gPlayerParty[0], prm[2], prm[3], 32, 0, 0, 0, 0);
    if (!gPlayerPartyCount) gPlayerPartyCount = 1;
    AddBagItem(68, 9);
    gSaveBlock1Ptr[0xEE0 + 0x105] |= 1;               // FLAG_SYS_POKEMON_GET: the START menu shows POKEMON
    SetMainCallback2(CB2_Overworld);
}
// debug: poke gMain.callback2 to this inside the overworld to trigger a normal wild battle start
void DebugStartWild(void) {
    volatile u16 *prm = (volatile u16 *)0x0203F000;   // [0]=species [1]=level [2]=party species [3]=party level [4]=trainer id
    if (!gPlayerPartyCount) {
        CreateMon(&gPlayerParty[0], 25, 12, 32, 0, 0, 0, 0);
        CreateMon(&gPlayerParty[1], 4, 10, 32, 0, 0, 0, 0);
        gPlayerPartyCount = 2;
        AddBagItem(4, 10); AddBagItem(3, 3); AddBagItem(1, 1);
    }
    for (int q = 5; q <= 12; q++) AddBagItem(q, 3); AddBagItem(13, 5); AddBagItem(139, 3); AddBagItem(289, 1); AddBagItem(14, 2); AddBagItem(34, 3); AddBagItem(68, 2); AddBagItem(74, 4); AddBagItem(2, 4); AddBagItem(24, 3); AddBagItem(25, 2);
    if (prm[2]) CreateMon(&gPlayerParty[0], prm[2], prm[3], 32, 0, 0, 0, 0);
    if (prm[10]) { u16 mv = prm[10]; u8 pp = 30; SetMonData(&gPlayerParty[0], 13, &mv); SetMonData(&gPlayerParty[0], 17, &pp); }   // debug: first move
    if (prm[7]) {                                       // debug: both lead mons one exp point short of the next level
        CreateMon(&gPlayerParty[0], prm[2], prm[3], 32, 0, 0, 0, 0);
        CreateMon(&gPlayerParty[1], prm[2], prm[3], 32, 0, 0, 0, 0);
        for (int q = 0; q < 2; q++) {
            int rate = gBaseStats[(u32)prm[2] * 28 + 19];
            u32 ex = gExperienceTables[rate * 101 + prm[3] + 1] - 1;
            SetMonData(&gPlayerParty[q], MON_DATA_EXP, &ex);
            if (prm[9]) { u16 hi = prm[9]; SetMonData(&gPlayerParty[q], MON_DATA_HELD_ITEM, &hi); }
        }
    }
    if (prm[4]) {
        gTrainerBattleOpponent_A = prm[4];
        gBattleTypeFlags = prm[5] ? prm[5] : 8;
        gMain.savedCallback = CB2_EndWildBattle;
        if (!ArenaStart()) SetMainCallback2(CB2_Overworld);
        return;
    }
    CreateMon(&gEnemyParty[0], prm[0] ? prm[0] : 19, prm[1] ? prm[1] : 5, 32, 0, 0, 0, 0);
    if (prm[6]) { SetMainCallback2(CB2_Overworld); return; }   // only create the enemy mon
    if (prm[5]) {
        gBattleTypeFlags = prm[5];
        gMain.savedCallback = CB2_EndWildBattle;
        if (!ArenaStart()) SetMainCallback2(CB2_Overworld);
        return;
    }
    SetMainCallback2(CB2_Overworld);
    BattleSetup_StartWildBattle();
}
#endif

// Script command checkpartymove (0x7C) replaced: the field moves (Cut, Fly, Surf, Strength, Waterfall, Flash, Rock Smash,
// Dive) no longer need a Pokemon that knows them.  The scripts keep their own badge checks, so the actions work once
// the gym leader's badge is won.  A real move user is still preferred (its name shows in the message).
typedef u8 (*ScrCmdFn)(void *ctx);
u8 HmCheck(void *ctx) {
    u8 r = ((ScrCmdFn)(0x0806C0A9u))(ctx);                         // original ScrCmd_checkpartymove
    const u8 *p = *(const u8 *const *)((u8 *)ctx + 8);             // scriptPtr, just past the move halfword
    u16 mv = (u16)(p[-2] | (p[-1] << 8));
    vu16 *res = (vu16 *)0x20370D0, *sp = (vu16 *)0x20370C0;
    if (*res == 6 && (mv == 15 || mv == 19 || mv == 57 || mv == 70 || mv == 127 || mv == 148 || mv == 249 || mv == 291)) {
        *res = 0;
        *sp = (u16)GetMonData(&gPlayerParty[0], 11, 0);
    }
    return r;
}

// Ruin Valley door (the Dotted Hole): interacting with it uses Cut by itself - sets the "door opened" flag and reloads the map
void RuinEntry(void) {
    u32 id = 0x2E3; gSaveBlock1Ptr[0xEE0 + (id >> 3)] |= 1 << (id & 7);
    id = 0x8E; gSaveBlock1Ptr[0xEE0 + (id >> 3)] |= 1 << (id & 7);   // hides the man standing in front of the door
    gBattleTypeFlags = 0;
    gBattleOutcome = 4;
    SetMainCallback2(CB2_EndWildBattle);
}

// script command callnative from the Cable Club attendants: opens the real-time link screen
void ClubEntry(void) { SetMainCallback2(LinkScreenInit); }

__attribute__((section(".header"), used)) const u32 ArenaHeader[8] = { 0x414E5241u, (u32)ArenaEntry, (u32)LinkKeyGuard, (u32)FollowerEntry, (u32)EvoGate, (u32)HmCheck, (u32)ClubEntry, (u32)RuinEntry };
