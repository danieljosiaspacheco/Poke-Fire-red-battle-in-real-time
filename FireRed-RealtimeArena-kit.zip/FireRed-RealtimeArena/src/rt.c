// tiny runtime: memcpy/memset + integer division through the GBA BIOS
#include "gba.h"
void *memcpy(void *d, const void *s, unsigned n) {
    u8 *dd = d; const u8 *ss = s;
    if ((((u32)d | (u32)s | n) & 3) == 0) {
        u32 *dw = d; const u32 *sw = s;
        for (unsigned i = 0; i < n / 4; i++) dw[i] = sw[i];
    } else {
        for (unsigned i = 0; i < n; i++) dd[i] = ss[i];
    }
    return d;
}
void *memset(void *d, int c, unsigned n) {
    u8 *dd = d;
    for (unsigned i = 0; i < n; i++) dd[i] = (u8)c;
    return d;
}
void __aeabi_memcpy(void *d, const void *s, unsigned n) { memcpy(d, s, n); }
void __aeabi_memcpy4(void *d, const void *s, unsigned n) { memcpy(d, s, n); }
void __aeabi_memcpy8(void *d, const void *s, unsigned n) { memcpy(d, s, n); }
void __aeabi_memset(void *d, unsigned n, int c) { memset(d, c, n); }
void __aeabi_memclr(void *d, unsigned n) { memset(d, 0, n); }
void __aeabi_memclr4(void *d, unsigned n) { memset(d, 0, n); }
void __aeabi_memclr8(void *d, unsigned n) { memset(d, 0, n); }
