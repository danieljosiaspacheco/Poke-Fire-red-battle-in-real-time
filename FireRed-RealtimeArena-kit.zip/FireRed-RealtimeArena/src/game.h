#ifndef GAME_H
#define GAME_H
#include "gba.h"

// ---- struct Pokemon is opaque (100 bytes); gPlayerParty[6], gEnemyParty[6] ----
struct Pokemon { u8 raw[100]; };
extern struct Pokemon gPlayerParty[6];
extern struct Pokemon gEnemyParty[6];
extern u8 gPlayerPartyCount;
extern u32 gBattleTypeFlags;
extern u8 gBattleOutcome;
extern u32 gBattleExtraFlags;

// gMain (struct Main) subset at 0x030030F0
struct Main {
    void (*callback1)(void);      // 0x00
    void (*callback2)(void);      // 0x04
    void (*savedCallback)(void);  // 0x08
    void (*vblankCallback)(void); // 0x0C
    void (*hblankCallback)(void); // 0x10
    void (*vcountCallback)(void); // 0x14
    void (*serialCallback)(void); // 0x18
    vu16 intrCheck;               // 0x1C
    u16 pad1e;
    u32 vblankCounter1;           // 0x20
    u32 vblankCounter2;           // 0x24
    u16 heldKeysRaw;              // 0x28
    u16 newKeysRaw;               // 0x2A
    u16 heldKeys;                 // 0x2C
    u16 newKeys;                  // 0x2E
    u16 newAndRepeatedKeys;       // 0x30
    u16 keyRepeatCounter;         // 0x32
    u16 watchedKeysPressed;       // 0x34
    u16 watchedKeysMask;          // 0x36
    u8 oamBuffer[0x400];          // 0x38  (128 * 8)
    u8 state;
};
extern struct Main gMain;

// ---- game functions ----
void SetMainCallback2(void (*cb)(void));
void SetVBlankCallback(void (*cb)(void));
u16 Random(void);
void ResetSpriteData(void);
void ResetTasks(void);
void ResetPaletteFade(void);
void FreeAllSpritePalettes(void);
void CB2_InitBattle(void);
void CB2_EndWildBattle(void);
void CB2_Overworld(void);
void LZ77UnCompWram(const void *src, void *dst);
void CpuSet(const void *src, void *dst, u32 control);
void CpuFastSet(const void *src, void *dst, u32 control);
void *AllocZeroed(u32 size);
void Free(void *p);
u32 GetMonData(struct Pokemon *mon, u32 field, void *dst);
void SetMonData(struct Pokemon *mon, u32 field, const void *src);
void CalculateMonStats(struct Pokemon *mon);
u8 GetLevelFromMonExp(struct Pokemon *mon);
u8 GiveMonToPlayer(struct Pokemon *mon);
u8 CheckBagHasItem(u16 item, u16 count);
u8 RemoveBagItem(u16 item, u16 count);
u16 SpeciesToNationalPokedexNum(u16 species);
u8 GetSetPokedexFlag(u16 nationalNum, u8 caseId);
void PlayCry1(u16 species, s8 pan);
void PlaySE(u16 song);
void CreateMon(struct Pokemon *mon, u16 species, u8 level, u8 fixedIV, u8 hasFixedPersonality, u32 fixedPersonality, u8 otIdType, u32 fixedOtId);
void ZeroMonData(struct Pokemon *mon);
void CopyMon(void *dst, const void *src, u32 size);
void HealPlayerParty(void);
void FadeOutBGM(u8 speed);
void m4aMPlayVolumeControl(void *mplay, u16 trackBits, u16 volume);
u8 IsCryFinished(void);
extern u8 gMPlayInfo_BGM[];

extern const u8 gBattleMoves[];        // 12 bytes each
extern const u8 gTypeEffectiveness[];  // {atk,def,mult} triples, 0xFE / 0xFF
extern const u8 gSpeciesNames[];       // 11 bytes each
extern const u8 gMoveNames[];          // 13 bytes each
extern const u8 gPokemonNames[];       // 11 bytes each
extern const u8 gBaseStats[];          // 28 bytes each

// MON_DATA ids
#define MON_DATA_SPECIES 11
#define MON_DATA_HELD_ITEM 12
#define MON_DATA_MOVE1 13
#define MON_DATA_PP1 17
#define MON_DATA_CUTE 24            // contest stat, unused by this hack: 255 = "never evolve"
#define MON_DATA_EXP 25
#define MON_DATA_FRIENDSHIP 32
#define MON_DATA_POKEBALL 38
#define MON_DATA_STATUS 55
#define MON_DATA_LEVEL 56
#define MON_DATA_HP 57
#define MON_DATA_MAX_HP 58
#define MON_DATA_ATK 59
#define MON_DATA_DEF 60
#define MON_DATA_SPEED 61
#define MON_DATA_SPATK 62
#define MON_DATA_SPDEF 63
#define MON_DATA_SANITY_IS_EGG 6
#define MON_DATA_PERSONALITY 0
u16 MonTryLearningNewMove(struct Pokemon *mon, u8 firstMove);
void SetMonMoveSlot(struct Pokemon *mon, u16 move, u8 slot);
u16 GetEvolutionTargetSpeciesOld(struct Pokemon *mon, u8 type, u16 item);
void BeginEvolutionScene(struct Pokemon *mon, u16 species, u8 canStop, u8 partyId);
u8 DoNamingScreen(u8 caseId, u8 *dst, u16 species, u8 gender, u32 personality, void (*cb)(void));
u8 GetMonGender(struct Pokemon *mon);
void CreateNPCTrainerParty(struct Pokemon *party, u16 trainerId);
void AddMoney(u32 *money, u32 amount);
extern u16 gMoveToLearn;
extern void (*gCB2_AfterEvolution)(void);
extern u16 gTrainerBattleOpponent_A;
extern const u8 gTrainers[];            // 40 bytes each
extern const u8 gTrainerClassNames[];   // 13 bytes each
extern const u8 gTrainerMoneyTable[];   // {class, value, 0, 0}, 0xFF end
u8 BattleSetup_GetTerrainId(void);
void PlayerGetDestCoords(s16 *x, s16 *y);
void BattleSetup_StartWildBattle(void);
u16 MapGridGetMetatileBehaviorAt(s16 x, s16 y);
extern u8 *gSaveBlock1Ptr;
extern u8 *gSaveBlock2Ptr;
#define MON_DATA_NICKNAME 2
void RemoveMoney(u32 *money, u32 amount);
u32 GetMoney(u32 *money);
void EvolutionScene(struct Pokemon *mon, u16 species, u8 canStop, u8 partyId);
extern const u32 gItemEffectTable[];
extern const u8 gItems[];            // 44 bytes each
extern const u32 gExperienceTables[];  // [6][101]
#define MON_DATA_PPBONUS 21
#define MON_DATA_HP_EV 26
#define MON_DATA_ATK_EV 27
#define MON_DATA_DEF_EV 28
#define MON_DATA_SPEED_EV 29
#define MON_DATA_SPATK_EV 30
#define MON_DATA_SPDEF_EV 31
u16 CountTotalItemQuantityInBag(u16 item);
#define gNumSafariBalls (*(volatile u8 *)0x2039994)
#endif
