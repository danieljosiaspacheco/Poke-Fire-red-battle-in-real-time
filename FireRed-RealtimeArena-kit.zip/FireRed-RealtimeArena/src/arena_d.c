// arena_d.c - rendering, HUD, vblank, init/exit, entry points
#define OBJGFX 128
#define OBJFONT 160
static const u8 POP_BANK[8] = {12, 15, 12, 13, 14, 13, 15, 14};

static void Draw(Arena *A, u16 a0, u16 a1, u16 a2, int key) {
    if (A->ndl >= 110) return;
    DObj *d = &A->dl[A->ndl++];
    d->a0 = a0; d->a1 = a1; d->a2 = a2; d->key = key;
}

static void DrawActor(Arena *A, Actor *a) {
    if (a->relDelay || a->relT > REL_TOT - REL_APP) return;          // still in its ball
    if (!a->alive && a->fainted >= 45) return;
    if (!a->alive && ((a->fainted / 3) & 1)) return;
    if (a->phase == PH_CAPTURED) {
        if (A->capState != CAP_ABSORB || (A->capTimer & 2)) return;
    }
    const u8 *d = AnimData(a);
    u8 idx = a->aIdx >= d[0] ? (d[0] ? d[0] - 1 : 0) : a->aIdx;
    const u8 *e = d + 1 + idx * 5;
    int dx = (s8)e[2], dy = (s8)e[3];
    int x = (a->x >> 8) - a->ox + dx, y = (a->y >> 8) - a->oy + dy;
    if (a->cols) {
        for (int k = 0; k < a->np; k++) {
            int px = x + (k % a->cols) * 64, py = y + (k / a->cols) * 64;
            if (px <= -64 || px >= 240 || py <= -64 || py >= 160) continue;
            Draw(A, (py & 0xFF), (px & 0x1FF) | (3 << 14), a->pb[k] | (1 << 10) | (a->palBank << 12), a->y >> 8);
        }
    } else
    Draw(A, (y & 0xFF) | (a->shape << 14), (x & 0x1FF) | (a->size << 14),
         a->objBase | (1 << 10) | (a->palBank << 12), a->y >> 8);
    int sx = (a->x >> 8) - 8, sy = (a->y >> 8) - 9;
    Draw(A, (sy & 0xFF) | (1 << 10), (sx & 0x1FF) | (1 << 14), (OBJGFX + 0) | (1 << 10) | (2 << 12), -30000);
}

__attribute__((noinline)) static void DrawFx(Arena *A, int s, int cx, int cy, int key, int flip) {
    if (!A->fxN[s]) return;
    int w = SHAPE_W[A->fxShape[s]][A->fxSize[s]], h = SHAPE_H[A->fxShape[s]][A->fxSize[s]];
    int x = cx - w / 2, y = cy - h / 2;
    Draw(A, (y & 0xFF) | (A->fxShape[s] << 14), (x & 0x1FF) | (A->fxSize[s] << 14) | (flip ? 0x1000 : 0),
         FXTILE(s) | (1 << 10) | ((8 + s) << 12), key);
}


__attribute__((noinline)) static void DrawProjFx(Arena *A, Proj *p) {
    int s = (p->owner & 1) * 2, x = p->x >> 8, y = p->y >> 8, key = y + 40, fl = (A->frame >> 2) & 1;
    int age = 70 - p->life, big = SHAPE_W[A->fxShape[s]][A->fxSize[s]] > 16;
    switch (FxStyle(p->move)) {
    case ST_POWDER: {
        int n = big ? 3 : 5, sp = 3 + age / 6;
        for (int i = 0; i < n; i++) {
            int ox = ((i * 7 + (age >> 1) * (i + 2)) % 17 - 8) * sp / 4;
            int oy = ((i * 11 + (age >> 1) * (i + 1) * 3) % 15 - 7) * sp / 4 + (age >> 3);
            DrawFx(A, s, x + ox, y + oy, key + i, (i + fl) & 1);
        }
        break; }
    case ST_STREAM: {
        for (int i = 0; i < 4; i++) {
            if (i * 3 > age) break;
            DrawFx(A, s, (p->x - p->vx * i * 2 / 3 * 3) >> 8, (p->y - p->vy * i * 2 / 3 * 3) >> 8, key - i, (fl + i) & 1);
        }
        break; }
    case ST_FIRESTAR: {                                       // trail of flames (Ember's sprite) behind a spinning fire star
        static const s8 wob[4] = {0, 2, 0, -2};
        for (int i = 7; i >= 1; i--) {
            if (i * 2 > age || !A->fxN[s + 1]) continue;
            DrawFx(A, s + 1, (p->x - p->vx * i * 2) >> 8, ((p->y - p->vy * i * 2) >> 8) + wob[((A->frame >> 1) + i) & 3], key - i, (fl + i) & 1);
        }
        DrawFx(A, s, x, y, key, (A->frame >> 1) & 1);
        break; }
    case ST_TORNADO: {                                        // the funnel spins (mirrors every other frame), sways and drags a fainter copy behind it
        static const s8 sway[4] = {0, 2, 0, -2};
        int sp = (A->frame >> 1) & 1;
        DrawFx(A, s, (p->x - p->vx * 5) >> 8, ((p->y - p->vy * 5) >> 8) + 2, key - 1, !sp);
        DrawFx(A, s, x + sway[(A->frame >> 1) & 3], y - 2, key, sp);
        break; }
    case ST_JET: {                                            // Hydro Pump: blobs of water one behind the other, a continuous jet from the user to the head
        int back = p->vx < 0;
        for (int i = 0; i < 18; i++) {
            if (i * 2 > age) break;
            int bx = (p->x - p->vx * i * 2) >> 8, by = (p->y - p->vy * i * 2) >> 8;
            DrawFx(A, s, bx, by + ((((A->frame >> 1) + i) & 1) ? 2 : -2), key - i, ((A->frame >> 2) + i) & 1 ? back : !back);
        }
        break; }
    case ST_ECG: {                                            // Thunder Shock: a heartbeat trace, copies joined edge to edge, scrolling and jittering like a monitor
        int back = p->vx < 0;
        for (int i = 0; i < 4; i++) {
            if (i * 8 > age) break;
            int bx = (p->x - p->vx * i * 6) >> 8, by = (p->y - p->vy * i * 6) >> 8;
            DrawFx(A, s, bx - (back ? -1 : 1) * i * 2, by + ((((A->frame >> 1) + i) & 1) ? 1 : -1), key - i, back);
        }
        break; }
    case ST_WAVE: {                                           // a train of waves seen from the side, rolling in the direction of travel (the sprite faces right)
        int back = p->vx < 0;
        for (int c = 0; c < 3; c++) {
            if (c * 6 > age) break;
            int bx = (p->x - p->vx * c * 6) >> 8, by = (p->y - p->vy * c * 6) >> 8;
            int bob = (((A->frame >> 2) + c) & 1) ? 1 : -1;
            DrawFx(A, s, bx, by + bob + c, key - c, back);
        }
        break; }
    case ST_GALE: {                                           // Blizzard: ONE icy gust flying forward (like Ember), swaying a little
        static const s8 jit[4] = {0, 2, 0, -2};
        DrawFx(A, s, x, y + jit[(A->frame >> 1) & 3], key, p->vx < 0);
        break; }
    case ST_BEANS: {                                          // a heap of ice beans streaming forward, each copy tumbling (mirrored) and scattered
        static const s8 sc[5][2] = {{0, 0}, {-7, 5}, {6, -6}, {-10, -4}, {10, 6}};
        for (int i = 0; i < 5; i++) {
            if (i * 3 > age) break;
            DrawFx(A, s, ((p->x - p->vx * i * 2) >> 8) + sc[i][0], ((p->y - p->vy * i * 2) >> 8) + sc[i][1], key - i, (fl + i) & 1);
        }
        break; }
    case ST_QUAKE: {                                          // ground cracks rolling forward, the ground shakes up and down
        for (int c = 0; c < 4; c++) {
            if (c * 5 > age) break;
            int bx = (p->x - p->vx * c * 5) >> 8, by = (p->y - p->vy * c * 5) >> 8;
            DrawFx(A, s, bx, by + 6 + ((((A->frame >> 1) + c) & 1) ? 2 : -2), key - c, c & 1);
        }
        break; }
    case ST_MOUND: {                                          // a mound of earth ploughing along the ground, leaving lower humps behind it
        for (int c = 2; c >= 0; c--) {
            if (c * 5 > age) continue;
            DrawFx(A, s, (p->x - p->vx * c * 5) >> 8, ((p->y - p->vy * c * 5) >> 8) + 4 + c * 2 + ((((A->frame >> 1) + c) & 1) ? 1 : -1), key - c, p->vx < 0);
        }
        break; }
    case ST_RINGS: {                                          // water rings, one behind the other, each bobbing a little
        for (int c = 3; c >= 0; c--) {
            if (c * 6 > age) continue;
            DrawFx(A, s, (p->x - p->vx * c * 6) >> 8, ((p->y - p->vy * c * 6) >> 8) + ((((A->frame >> 1) + c) & 1) ? 1 : -1), key - c, p->vx < 0);
        }
        break; }
    case ST_FALL: {                                           // a waterfall: the column is stacked two high and falls (the streaks shift every frame)
        int sh = (A->frame >> 1) & 1;
        DrawFx(A, s, x, y - 14, key, sh);
        DrawFx(A, s, x, y + 12, key - 1, !sh);
        break; }
    case ST_DIVE: {                                           // the leap: the arch of water rides a sine path, ripples trail along the ground
        static const s8 arc[8] = {-4, -9, -12, -9, -4, 3, 8, 3};
        for (int c = 2; c >= 1; c--) {
            if (c * 7 > age) continue;
            DrawFx(A, s, (p->x - p->vx * c * 7) >> 8, ((p->y - p->vy * c * 7) >> 8) + 8, key - c, c & 1);
        }
        DrawFx(A, s, x, y + arc[(A->frame >> 1) & 7], key, p->vx < 0);
        break; }
    case ST_WHIPS: {                                          // Vine Whip: two vines lashing forward, one a beat behind the other, each dragging a trailing copy
        static const s8 lash[4] = {-3, 0, 3, 0};
        int ph = (A->frame >> 1) & 3;
        for (int w = 0; w < 2; w++) {
            int oy = w ? 8 : -8, ly = lash[(ph + w * 2) & 3] * (w ? -1 : 1);
            DrawFx(A, s, (p->x - p->vx * 4) >> 8, ((p->y - p->vy * 4) >> 8) + oy - ly, key - 1 - w, p->vx < 0);
            DrawFx(A, s, x, y + oy + ly, key - w, p->vx < 0);
        }
        break; }
    case ST_DRAGON: {                                         // Dragon Rage: a yellow dragon undulating towards the target
        static const s8 bob[8] = {0, -3, -4, -3, 0, 3, 4, 3};
        DrawFx(A, s, x, y + bob[(A->frame >> 1) & 7], key, p->vx < 0);
        break; }
    case ST_FLAME: {
        static const s8 wob[4] = {0, 2, 0, -2};
        for (int i = 0; i < 10; i++) {
            if (i * 2 > age) break;
            DrawFx(A, s, (p->x - p->vx * i * 5 / 2) >> 8, ((p->y - p->vy * i * 5 / 2) >> 8) + wob[((A->frame >> 1) + i) & 3], key - i, (fl + i) & 1);
        }
        break; }
    case ST_MULTI: {
        s32 vl = isqrt((p->vx >> 4) * (p->vx >> 4) + (p->vy >> 4) * (p->vy >> 4)); if (!vl) vl = 1;
        s32 nx = -(p->vy >> 4) * 9 / vl, ny = (p->vx >> 4) * 9 / vl;      // perpendicular
        for (int i = -1; i <= 1; i++) DrawFx(A, s, x + nx * i - (i & 1) * (p->vx >> 10), y + ny * i - (i & 1) * (p->vy >> 10), key + i, fl);
        break; }
    case ST_ORBIT: {
        static const s8 sn[8] = {0, 7, 10, 7, 0, -7, -10, -7};
        for (int i = 0; i < 3; i++) {
            int a = (A->frame / 2 + i * 8 / 3 * 1) & 7, b = (a + 2) & 7;
            DrawFx(A, s, x + sn[b], y + sn[a] * 3 / 4, key + i, (i + fl) & 1);
        }
        break; }
    default: DrawFx(A, s, x, y, key, fl);
    }
}

static void DrawSprite16(Arena *A, int tile, int pal, int x, int y, int key) {
    Draw(A, ((y - 8) & 0xFF), ((x - 8) & 0x1FF) | (1 << 14), tile | (1 << 10) | (pal << 12), key);
}

static void DrawRelease(Arena *A, Actor *a) {
    if (a->relDelay) { a->relDelay--; return; }
    if (!a->relT) return;
    int e = REL_TOT - a->relT;
    a->relT--;
    int bank = a->isPlayer ? 6 : 3;
    if (e >= REL_APP + 3) return;
    if (!(bank == 3 && A->capState != CAP_NONE)) SetBallPalBank(A, bank, a->relBall);
    int tx = a->x >> 8, ty = (a->y >> 8) - (a->cols ? a->uh / 3 : 14);
    int ox = a->isPlayer ? 10 : 230, oy = a->isPlayer ? 140 : 30;
    int tile = BALLGFX + a->relBall * 4;
    if (e < REL_FL) {                                            // flight: a slow arc with the ball spinning
        static const u8 fl[4] = {0, 1, 3, 2};
        int x = ox + (tx - ox) * e / REL_FL, y = oy + (ty - oy) * e / REL_FL - 120 * e * (REL_FL - e) / (REL_FL * REL_FL);
        Draw(A, ((y - 8) & 0xFF), ((x - 8) & 0x1FF) | (1 << 14) | (fl[(e >> 2) & 3] << 12), tile | (1 << 10) | (bank << 12), 28000);
    } else {                                                     // opening: the ball flickers and a burst flies out
        int r = (e - REL_FL + 1) * 2;
        if (!(e & 2)) DrawSprite16(A, tile, bank, tx, ty, 28000);
        DrawSprite16(A, OBJGFX + 16, 4, tx + r, ty, 28000);
        DrawSprite16(A, OBJGFX + 16, 4, tx - r, ty, 28000);
        DrawSprite16(A, OBJGFX + 16, 4, tx, ty + r / 2, 28000);
        DrawSprite16(A, OBJGFX + 16, 4, tx, ty - r / 2, 28000);
    }
}

static void Render(Arena *A) {
    A->ndl = 0;
    for (int i = 0; i < 4; i++) if (A->pm & (1 << i)) DrawActor(A, &A->act[i]);
    for (int i = 0; i < 4; i++) if (A->pm & (1 << i)) DrawRelease(A, &A->act[i]);
    for (int i = 0; i < 10; i++) {
        Proj *p = &A->proj[i];
        if (!p->active) continue;
        if (!p->kind && A->fxN[(p->owner & 1) * 2]) DrawProjFx(A, p);
        else DrawSprite16(A, p->kind == 1 ? BALLGFX + A->ballTile * 4 : OBJGFX + (p->kind == 2 ? 24 : (p->kind == 3 ? 28 : 4)), p->pal, p->x >> 8, p->y >> 8, (p->y >> 8) + 40);
    }
    for (int i = 0; i < 8; i++) {
        Fx *f = &A->fx[i];
        if (!f->active) continue;
        int so = (f->pad & 1) * 2;
        if (f->kind == 4) {
            if (A->fxN[so] && !(f->timer > 10 && (f->timer & 1))) {
                int t = f->timer;
                if (A->fxMove[f->pad & 1] == 337) {                        // Dragon Claw: one set of yellow claws slashing down across the target
                    DrawFx(A, so, f->x + 6 - t / 2, f->y - 4 + t / 3, 29500, 0);
                } else
                DrawFx(A, so, f->x, f->y - t / 2, 29500, 0);
                if (t > 3 && A->fxMove[f->pad & 1] != 59 && A->fxMove[f->pad & 1] != 337) DrawFx(A, so, f->x - 9, f->y + 5 - t / 3, 29500, 1);
                if (t > 6 && A->fxMove[f->pad & 1] != 59 && A->fxMove[f->pad & 1] != 337) DrawFx(A, so, f->x + 9, f->y - 4 - t / 3, 29500, 0);
            }
        } else if (f->kind == 7 && A->fxN[so]) {                  // Rain Dance: a drizzle of streaks falling over the user
            Actor *ra = &A->act[f->pad >> 1];
            int t = f->timer, cx = ra->x >> 8, cy = (ra->y >> 8) - 8;
            if (!(t > 100 && (t & 1)))
                for (int q = 0; q < 6; q++) DrawFx(A, so, cx - 30 + q * 12 + (q & 1) * 3, cy - 58 + (t * 3 + q * 37) % 72, 29500, 0);
        } else if (f->kind == 6 && A->fxN[so + 1]) {              // Dig: a crater opens in the ground under the target and stays for a while
            if (!(f->timer > 34 && (f->timer & 1))) DrawFx(A, so + 1, f->x, f->y + 8, 2000, 0);
        } else if (f->kind == 5 && A->fxN[so]) {                  // wing moves: exactly two wings, one each side of the target, flapping
            if (!(f->timer > 12 && (f->timer & 1))) {
                int t = f->timer, fl = (t >> 1) & 1;
                DrawFx(A, so, f->x - 19 - fl, f->y - 7 - fl * 2, 29500, 1);      // stretched out sideways like an aeroplane, flapping
                DrawFx(A, so, f->x + 19 + fl, f->y - 7 - fl * 2, 29500, 0);
            }
        } else if (f->kind == 0 && A->fxMove[f->pad & 1] == 91) {
        } else if (f->kind == 0 && A->fxN[so + 1]) {
            if (f->timer < 12) DrawFx(A, so + 1, f->x, f->y, 29000, f->timer & 1);
        } else if (f->kind == 2 && A->fxN[so]) {
            int r = f->timer * 3 + 6;
            DrawFx(A, so, f->x + r, f->y, 28000, 0); DrawFx(A, so, f->x - r, f->y, 28000, 1);
            DrawFx(A, so, f->x, f->y + r / 2, 28000, 0); DrawFx(A, so, f->x, f->y - r / 2, 28000, 1);
        } else if (f->kind == 0) {
            if (f->timer & 1) DrawSprite16(A, OBJGFX + 12, 4, f->x, f->y, 29000);
            DrawSprite16(A, OBJGFX + 12, 4, f->x + (f->timer & 1 ? 4 : -4), f->y - 3, 29000);
        } else if (f->kind == 2) {
            int r = f->timer * 4;
            DrawSprite16(A, OBJGFX + 16, 4, f->x + r, f->y, 28000);
            DrawSprite16(A, OBJGFX + 16, 4, f->x - r, f->y, 28000);
            DrawSprite16(A, OBJGFX + 16, 4, f->x, f->y + r / 2, 28000);
            DrawSprite16(A, OBJGFX + 16, 4, f->x, f->y - r / 2, 28000);
        } else {
            DrawSprite16(A, OBJGFX + 20, 4, f->x, f->y - 8 - f->timer, 28000);
        }
    }
    // capture ball
    if (A->capState == CAP_ABSORB || A->capState == CAP_SHAKE || A->capState == CAP_SUCCESS || A->capState == CAP_BREAK) {
        static const s8 wob[8] = {0, 2, 3, 2, 0, -2, -3, -2};
        int off = 0;
        if (A->capState == CAP_SHAKE) {
            int t = A->capTimer % 40;
            if (t >= 10 && t < 30) off = wob[(t >> 1) & 7];
        }
        if (A->capState == CAP_ABSORB) {
            int yy = A->capY - (A->capTimer < 12 ? 8 : 0) + (A->capTimer < 12 ? 0 : (A->capTimer - 12));
            DrawSprite16(A, BALLGFX + A->ballTile * 4, 3, A->capX, yy, 20000);
        } else if (A->capState != CAP_BREAK || A->capTimer < 6) {
            DrawSprite16(A, BALLGFX + A->ballTile * 4, 3, A->capX + off, A->capY + 4, 20000);
        }
    }
    for (int i = 0; i < 8; i++) {
        Popup *p = &A->pop[i];
        if (!p->timer) continue;
        if (p->timer < 12 && (p->timer & 2)) continue;
        for (int k = 0; k < p->len; k++) {
            int c = p->text[k];
            if (c >= 'a' && c <= 'z') c -= 32;
            if (c < 32 || c > 95) c = 32;
            if (c == 32) continue;
            int x = p->x + k * 6, y = p->y;
            Draw(A, (y & 0xFF), (x & 0x1FF), (OBJFONT + c - 32) | (0 << 10) | (POP_BANK[p->pal & 7] << 12), 30000);
        }
    }
    // sort by key descending (insertion sort)
    for (int i = 1; i < A->ndl; i++) {
        DObj t = A->dl[i]; int j = i - 1;
        while (j >= 0 && A->dl[j].key < t.key) { A->dl[j + 1] = A->dl[j]; j--; }
        A->dl[j + 1] = t;
    }
    u16 *oam = (u16 *)gMain.oamBuffer;
    int n = A->ndl > 127 ? 127 : A->ndl;
    for (int i = 0; i < n; i++) {
        oam[i * 4 + 0] = A->dl[i].a0; oam[i * 4 + 1] = A->dl[i].a1; oam[i * 4 + 2] = A->dl[i].a2;
    }
    for (int i = n; i < 127; i++) { oam[i * 4 + 0] = 0x200; oam[i * 4 + 1] = 0; oam[i * 4 + 2] = 0; }
    // palettes (hit flash)
    for (int w = 0; w < 4; w++) {
        if (!(A->pm & (1 << w))) continue;
        Actor *a = &A->act[w];
        if ((a->flash && (A->frame & 2)) || (a->relT && !a->relDelay && a->relT <= REL_TOT - REL_APP && a->relT > REL_TOT - REL_APP - 8)) {
            for (int i = 1; i < 16; i++) A->objPal[a->palBank * 16 + i] = 0x7FFF;
        } else SetPal(A, a->palBank, RecPal(a->rec));
    }
}

// ---------- HUD ----------
static void PutText(Arena *A, int x, int y, const char *s, int pal) {
    u16 *m = A->bgmap + y * 32;
    for (; *s && x < 30; s++, x++) {
        int c = (u8)*s;
        if (c >= 'a' && c <= 'z') c -= 32;
        if (c < 32 || c > 95) c = 32;
        m[x] = (c - 32) | (pal << 12);
    }
}
static void PutBar(Arena *A, int x, int y, int hp, int mx) {
    u16 *m = A->bgmap + y * 32;
    int pix = mx > 0 ? hp * 64 / mx : 0;
    if (hp > 0 && pix < 1) pix = 1;
    int col = hp * 100 > mx * 50 ? 0 : (hp * 100 > mx * 20 ? 1 : 2);
    for (int i = 0; i < 8; i++) {
        int f = clampi(pix - i * 8, 0, 8);
        m[x + i] = 64 + col * 9 + f;
    }
}
static int PutNum(char *b, int v, int pad) {
    char t[12]; int n = itoa_(v, t), len = 0;
    for (int i = n; i < pad; i++) b[len++] = ' ';
    for (int i = 0; i < n; i++) b[len++] = t[i];
    b[len] = 0; return len;
}
static void StatusText(Actor *a, char *out) {
    static const char *nm[7] = {"", "SLP", "PSN", "BRN", "FRZ", "PAR", "PSN"};
    scopy(out, nm[a->status], 4);
    if (!a->status && a->confTimer) scopy(out, "CNF", 4);
}

static void UiDraw(Arena *A);
static void HudMon(Arena *A, int x, int y, Actor *a) {
    char b[12]; int n = 0;
    for (int i = 0; a->name[i] && n < 7; i++) b[n++] = a->name[i];
    b[n] = 0;
    PutText(A, x, y, b, (a->status || !a->alive) ? 4 : 0);
    PutBar(A, x + 7, y, a->alive ? a->hp : 0, a->maxHp);
}

static void HudDraw(Arena *A) {
    u16 *m = A->bgmap;
    for (int r = 0; r < 3; r++) for (int c = 0; c < 32; c++) m[r * 32 + c] = 0;
    for (int r = 3; r < 20; r++) for (int c = 0; c < 32; c++) m[r * 32 + c] = 0;
    Actor *p = &A->act[0], *e = &A->act[1];
    if (A->link && !A->lkMaster) { p = &A->act[1]; e = &A->act[0]; }      // link battle: the HUD always shows your own Pokemon on the left
    char b[16];
    if (A->dbl) {
        if (A->pm & 1) HudMon(A, 0, 0, &A->act[0]);
        if (A->pm & 4) HudMon(A, 0, 1, &A->act[2]);
        if (A->pm & 2) HudMon(A, 15, 0, &A->act[1]);
        if (A->pm & 8) HudMon(A, 15, 1, &A->act[3]);
        if (!A->link) { char r[4]; r[0] = 'X'; PutNum(r + 1, A->enemyCnt - A->defeated, 0); PutText(A, 28, 2, r, 3); }
        else { char r[4]; r[0] = 'X'; PutNum(r + 1, A->lkLeft[A->lkMaster ? 1 : 0], 0); PutText(A, 28, 2, r, 3); }
        int sw = A->link && !A->lkMaster;                                   // link: the bottom rows show your own two Pokemon
        if (A->msg[0]) PutText(A, 1, 2, A->msg, 0);
        else PutText(A, 1, 2, A->link ? (A->page ? "SEL:MOVES 3-4" : "SEL:MOVES 1-2") : A->page ? "SEL:MOVES 3-4  START:MENU" : "SEL:MOVES 1-2  START:MENU", 2);
        static const char keys2[2][2] = {{'A', 'L'}, {'B', 'R'}};
        for (int w = 0; w < 2; w++) {
            Actor *pa = &A->act[w * 2 + sw];
            if (!(A->pm & (1 << (w * 2 + sw))) || !pa->alive) continue;
            int both = (A->pm & (1 << sw)) && (A->pm & (4 << sw)) && A->act[sw].alive && A->act[2 + sw].alive;
            for (int k = 0; k < (both ? 2 : 4); k++) {
                int slot = both ? A->page * 2 + k : k;
                int x = (k & 1) ? 15 : 0, y = both ? 18 + w : 18 + (k >> 1);
                if (!pa->moves[slot]) continue;
                char nm[16]; GameStr(gMoveNames + pa->moves[slot] * 13, (u8 *)nm, 11);
                char l[20]; int q = 0;
                static const char kk4[4] = {'A', 'B', 'L', 'R'};
                l[q++] = both ? keys2[w][k] : kk4[k]; l[q++] = ' ';
                for (int j = 0; nm[j] && j < 9; j++) l[q++] = nm[j];
                l[q] = 0;
                int pal = (pa->pp[slot] == 0) ? 4 : (pa->cd[slot] ? 2 : 0);
                PutText(A, x, y, l, pal);
                char pp[8]; PutNum(pp, pa->pp[slot], 2);
                PutText(A, x + 12, y, pp, pal);
            }
        }
        goto hud_done;
    }
    PutText(A, 0, 0, (char *)p->name, 0);
    if (!A->safari) { scopy(b, "LV", 3); PutNum(b + 2, p->level, 0); PutText(A, 10, 0, b, 3); }
    PutText(A, 15, 0, (char *)e->name, 0);
    scopy(b, "LV", 3); PutNum(b + 2, e->level, 0); PutText(A, 25, 0, b, 3);
    if (!A->safari) {
        PutBar(A, 0, 1, p->hp, p->maxHp);
        int n = PutNum(b, p->hp < 0 ? 0 : p->hp, 0); b[n++] = '/'; PutNum(b + n, p->maxHp, 0);
        PutText(A, 9, 1, b, 0);
    }
    PutBar(A, 15, 1, e->hp, e->maxHp);
    StatusText(e, b); PutText(A, 24, 1, b, 4);
    if (!A->isTrainer && !A->link && e->mon) {      // wild: gender sign, and a Poke Ball when the species is already caught
        u8 g = GetMonGender(e->mon);
        if (g == 0) PutText(A, 23, 1, "@", 9); else if (g == 0xFE) PutText(A, 23, 1, "\\", 10);
        if (!b[0] && GetSetPokedexFlag(e->nat, 1)) PutText(A, 24, 1, "$", 4);
    }
    if (A->isTrainer && !A->link) { char r[4]; r[0] = 0x58; PutNum(r + 1, A->enemyCnt - A->defeated, 0); PutText(A, 28, 1, r, 3); }
    if (A->link) { char r[4]; r[0] = 0x58; PutNum(r + 1, A->lkLeft[A->lkMaster ? 1 : 0], 0); PutText(A, 28, 1, r, 3); }
    // message / ball line (row 2)
    if (A->msg[0]) PutText(A, 1, 2, A->msg, 0);
    else if (A->link) PutText(A, 1, 2, A->lkMaster ? "LINK BATTLE  YOU: LEFT" : "LINK BATTLE  YOU: RIGHT", 2);
    else if (A->safari) {
        char l[32]; scopy(l, "BALLS X", 10);
        PutNum(l + 7, gNumSafariBalls, 0);
        PutText(A, 1, 2, l, 3);
        if (A->sfBait) PutText(A, 12, 2, "EATING", 1);
        else if (A->sfAngry) PutText(A, 12, 2, "ANGRY", 4);
        PutText(A, 19, 2, "START:MENU", 2);
    } else {
        char l[32]; scopy(l, "SEL:", 8);
        int sel = A->ballSel;
        int k = slen(l);
        for (int i = 0; BALL_NAMES[sel][i]; i++) l[k++] = BALL_NAMES[sel][i];
        l[k++] = ' '; l[k++] = 'X';
        k += PutNum(l + k, CountTotalItemQuantityInBag(BALL_ITEMS[sel]), 0);
        PutText(A, 1, 2, l, 3);
        PutText(A, 18, 2, "START:MENU", 2);
        char st[4]; StatusText(p, st);
        if (st[0]) PutText(A, 27, 2, st, 4);
    }
    // moves
    static const char keys[4] = {'A', 'B', 'L', 'R'};
    if (A->safari) {
        PutText(A, 0, 18, "A SAFARI BALL", gNumSafariBalls ? 0 : 4);
        PutText(A, 0, 19, "B BAIT", 0);
        PutText(A, 15, 19, "L ROCK", 0);
        goto hud_done;
    }
    for (int i = 0; i < 4; i++) {
        int x = (i & 1) ? 15 : 0, y = 18 + (i >> 1);
        if (!p->moves[i]) continue;
        char nm[16]; GameStr(gMoveNames + p->moves[i] * 13, (u8 *)nm, 11);
        char l[20]; int k = 0;
        l[k++] = keys[i]; l[k++] = ' ';
        for (int j = 0; nm[j] && j < 9; j++) l[k++] = nm[j];
        l[k] = 0;
        int pal = (p->pp[i] == 0) ? 4 : (p->cd[i] ? 2 : 0);
        PutText(A, x, y, l, pal);
        char pp[8]; PutNum(pp, p->pp[i], 2);
        PutText(A, x + 12, y, pp, pal);
    }
hud_done:
    if (A->state == ST_UI) UiDraw(A);
    // dirty check
    u32 h = 0;
    for (int i = 0; i < 32 * 32; i++) h = h * 31 + m[i];
    if ((u16)h != A->hudCache || (u16)(h >> 16) != A->hudCache2) {
        A->hudCache = (u16)h; A->hudCache2 = (u16)(h >> 16);
        A->bgDirty = 1;
    }
}

// ---------- vblank ----------
static void Dma3(const void *src, void *dst, u32 words) {
    REG_DMA3SAD = (u32)src; REG_DMA3DAD = (u32)dst;
    REG_DMA3CNT = DMA_ENABLE | DMA_32BIT | words;
}
static void ArenaVBlank(void) {
    Arena *A = AR();
    if (!A) return;
    REG_DISPCNT = A->dispcnt;
    REG_BLDCNT = (3 << 6) | 0x3F | 0x0F00;
    REG_BLDALPHA = (8 << 8) | 8;
    REG_BLDY = A->fadeLevel;
    Dma3(gMain.oamBuffer, (void *)OAM_BASE, 127 * 2);
    Dma3(A->objPal, (void *)OBJ_PLTT, 128);
    if (A->bgDirty) { Dma3(A->bgmap, (void *)(VRAM_BASE + 0xF800), 512); A->bgDirty = 0; }
    for (int s = 0; s < 4; s++) if (A->fxPend & (1 << s)) {
        Dma3(A->fxSrc[s], (void *)(OBJ_VRAM + FXTILE(s) * 32), A->fxN[s] * 8);
    }
    A->fxPend = 0;
    for (int i = 0; i < 4; i++) {
        Actor *a = &A->act[i];
        if (a->upPending) {
            if (a->cols) { for (int k = 0; k < a->np; k++) Dma3(A->bstage[i] + k * 2048, (void *)(OBJ_VRAM + a->pb[k] * 32), 2048 / 4); }
            else Dma3(A->stage[i], (void *)(OBJ_VRAM + a->objBase * 32), (a->tiles * 32) / 4);
            a->upPending = 0;
        }
    }
}

// ---------- hardware / graphics setup ----------
static void HwReset(void) {
    SetVBlankCallback(0);
    gMain.hblankCallback = 0; gMain.vcountCallback = 0;
    REG_DISPCNT = 0x80;
    // keep the VCount IRQ (the game calls m4aSoundVSync from it; killing it garbles the music), drop only HBlank
    REG_IE &= ~0x0002;
    REG_DISPSTAT = (REG_DISPSTAT & 0xFF28) | 0x08;
    REG_DMA0CNT_H = 0;
    REG_BLDCNT = 0; REG_BLDALPHA = 0; REG_BLDY = 0; REG_MOSAIC = 0;
    REG_WIN0H = 0; REG_WIN1H = 0; REG_WIN0V = 0; REG_WIN1V = 0; REG_WININ = 0; REG_WINOUT = 0;
    REG_BG0HOFS = 0; REG_BG0VOFS = 0; REG_BG1HOFS = 0; REG_BG1VOFS = 0;
    REG_BG2HOFS = 0; REG_BG2VOFS = 0; REG_BG3HOFS = 0; REG_BG3VOFS = 0;
    static const u32 zero = 0;
    CpuFastSet(&zero, (void *)VRAM_BASE, (1 << 24) | (0x18000 / 4));
    CpuFastSet(&zero, (void *)PLTT_BASE, (1 << 24) | (0x400 / 4));
    u16 *oam = (u16 *)OAM_BASE;
    for (int i = 0; i < 128; i++) { oam[i * 4] = 0x200; oam[i * 4 + 1] = 0; oam[i * 4 + 2] = 0; oam[i * 4 + 3] = 0; }
}

static void CopyTiles(const u32 (*src)[8], int count, u32 dst) {
    u32 *d = (u32 *)dst;
    for (int i = 0; i < count; i++) for (int j = 0; j < 8; j++) *d++ = src[i][j];
}

static void LoadGfx(Arena *A) {
    // BG tiles: font 0..63, bars 64..91, exp bar 92..100 ; floor in charblock 1
    CopyTiles(gFontTiles, 64, VRAM_BASE);
    CopyTiles(gBarTiles, 28, VRAM_BASE + 64 * 32);
    CopyTiles(gExpTiles, 9, VRAM_BASE + 92 * 32);
    CopyTiles(gFloorTiles, 11, VRAM_BASE + 0x4000);
    {   // floor theme from the battle terrain: water waves / building plates / recoloured grass tiles
        int th = A->terrain > 10 ? 8 : A->terrain;
        if (gFloorSet[th] == 1) CopyTiles(gFloorWater, 8, VRAM_BASE + 0x4000);
        else if (gFloorSet[th] == 2) CopyTiles(gFloorBldg, 8, VRAM_BASE + 0x4000);
    }
    {   // opaque-background font for UI boxes: tiles 101..164
        u32 *bd = (u32 *)(VRAM_BASE + 101 * 32);
        for (int i = 0; i < 64; i++) for (int j = 0; j < 8; j++) {
            u32 w = gFontTiles[i][j], o = 0;
            for (int n = 0; n < 8; n++) { u32 v = (w >> (n * 4)) & 15; if (!v) v = 2; o |= v << (n * 4); }
            *bd++ = o;
        }
    }
    u16 *fm = (u16 *)(VRAM_BASE + 0xF000);
    for (int y = 0; y < 20; y++) for (int x = 0; x < 32; x++) fm[y * 32 + x] = gFloorMap[y][x];
    for (int i = 0; i < 32 * 32; i++) A->bgmap[i] = 0;
    // OBJ tiles
    CopyTiles(gObjTiles, 24, OBJ_VRAM + OBJGFX * 32);
    CopyTiles(gSafariTiles, 8, OBJ_VRAM + (OBJGFX + 24) * 32);
    for (int k = 0; k < NBALL; k++) CopyTiles((const u32 (*)[8])(BALLPACK + k * 160 + 32), 4, OBJ_VRAM + (BALLGFX + k * 4) * 32);
    CopyTiles(gFontTiles, 64, OBJ_VRAM + OBJFONT * 32);
    // BG palettes
    u16 *bp = (u16 *)PLTT_BASE;
    for (int i = 0; i < 16; i++) {
        bp[i] = gBgPalText[i]; bp[16 + i] = gFloorPals[A->terrain > 10 ? 8 : A->terrain][i];
        bp[32 + i] = gBgPalText[i]; bp[48 + i] = gBgPalText[i]; bp[64 + i] = gBgPalText[i];
    }
    bp[32 + 1] = 0x5EF7;                      // gray text
    bp[48 + 1] = 0x1B7F;                      // yellow text
    bp[64 + 1] = 0x2A5F;                      // red text
    for (int i = 0; i < 16; i++) { bp[144 + i] = gBgPalText[i]; bp[160 + i] = gBgPalText[i]; }
    bp[144 + 1] = 0x7EEB;                     // blue (male sign)
    bp[160 + 1] = 0x5A1F;                     // pink (female sign)
    {
        static const u16 col[4] = {0x7FFF, 0x1B7F, 0x5EF7, 0x2A5F};
        for (int k = 0; k < 4; k++) { u16 *q = bp + (5 + k) * 16; for (int i = 0; i < 16; i++) q[i] = 0x30A2; q[0] = 0; q[1] = col[k]; q[2] = 0x30A2; }
    }
    // OBJ palettes (shadow copy)
    for (int i = 0; i < 16; i++) {
        A->objPal[2 * 16 + i] = gObjPalShadow[i];
        A->objPal[3 * 16 + i] = gObjPalBall[i];
        if (i == 15) SetBallPal(A, 0);
        A->objPal[4 * 16 + i] = gObjPalFx[i];
        A->objPal[6 * 16 + i] = gObjPalSafari[i];
        for (int k = 12; k < 16; k++) A->objPal[k * 16 + i] = gObjPalText[i];
    }
    A->objPal[12 * 16 + 1] = 0x7FFF;
    A->objPal[13 * 16 + 1] = 0x1B7F;          // yellow
    A->objPal[14 * 16 + 1] = 0x2A5F;          // red
    A->objPal[15 * 16 + 1] = 0x2FE5;          // green
    REG_BG0CNT = 0x1F00 | 0;                  // prio0, cb0, sb31
    REG_BG1CNT = 0x1E00 | 4 | 1;              // prio1, cb1, sb30
}

