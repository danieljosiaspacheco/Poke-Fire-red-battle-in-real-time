// arena_l.c - own SIO multi-player link layer (stop-and-wait with 4-bit sequence numbers), used for real-time link battles
//   word = txSeq(4) | ack(4) | data(8).  The master (SIOCNT bit 2 low, id 0) starts every transfer; both sides send at once.
#define LK_SIOCNT   (*(volatile u16 *)0x04000128)
#define LK_RCNT     (*(volatile u16 *)0x04000134)
#define LK_SEND     (*(volatile u16 *)0x0400012A)
#define LK_RECV(i)  (*(volatile u16 *)(0x04000120 + 2 * (i)))

typedef struct {
    u8 init, master, txSeq, rxLast, ready;
    const u8 *tx; u32 txLen, txPos;       // byte stream to send
    u8 *rx; u32 rxLen, rxPos; u32 mask;             // byte stream to receive
    u16 errors, transfers; u32 guard;
} LinkCtx;

static void LinkOpen(LinkCtx *L) {
    LK_RCNT = 0;
    LK_SIOCNT = 0x2003;                    // multi-player mode, 115200 baud
    L->master = !(LK_SIOCNT & 4);          // SI low = parent
    L->txSeq = 1; L->rxLast = 0; L->txPos = 0; L->rxPos = 0; L->mask = 0xFFFFFFFFu; L->init = 1; L->errors = 0; L->transfers = 0; L->guard = 4000;
}

static u16 LinkWord(LinkCtx *L) {
    int has = L->txPos < L->txLen;
    u8 data = has ? L->tx[L->txPos & L->mask] : 0;
    return (u16)((has ? L->txSeq : 0) << 12 | (L->rxLast & 15) << 8 | data);   // seq 0 = nothing to send (seqs run 1..14 so a word is never 0xFFFF)
}

// one transfer; returns 1 if it completed.  The master starts it, the slave waits for it.
static int LinkTransfer(LinkCtx *L) {
    LK_SEND = LinkWord(L);
    int guard = 0;
    if (L->master) {
        if (LK_SIOCNT & 0x80) return 0;
        LK_SIOCNT |= 0x80;
        while ((LK_SIOCNT & 0x80) && guard++ < 20000) {}
        if (LK_SIOCNT & 0x80) return 0;
    } else {
        // wait for the master to run a transfer (bit 7 goes high, then low); give up after a while
        while (!(LK_SIOCNT & 0x80) && guard++ < L->guard) {}
        if (!(LK_SIOCNT & 0x80)) return 0;
        guard = 0;
        while ((LK_SIOCNT & 0x80) && guard++ < 20000) {}
        if (LK_SIOCNT & 0x80) return 0;
    }
    if (LK_SIOCNT & 0x40) { L->errors++; return 0; }
    u16 w = LK_RECV(L->master ? 1 : 0);
    if (w == 0xFFFF) return 0;
    L->transfers++;
    u8 seq = (w >> 12) & 15, ack = (w >> 8) & 15, data = w & 0xFF;
    if (L->txPos < L->txLen && ack == L->txSeq) { L->txPos++; L->txSeq = L->txSeq % 14 + 1; }   // the other side got our byte
    if (seq && seq == L->rxLast % 14 + 1) {
        if (L->rxPos < L->rxLen) { L->rx[L->rxPos++ & L->mask] = data; L->rxLast = seq; }
        // beyond the expected length the byte is not accepted (and not acknowledged)
    }
    return 1;
}

// run up to n transfers; returns the number that completed
static int LinkPump(LinkCtx *L, int n) {
    int done = 0;
    for (int i = 0; i < n; i++) if (LinkTransfer(L)) done++;
    return done;
}
static int LinkDone(const LinkCtx *L) { return L->txPos >= L->txLen && L->rxPos >= L->rxLen; }

// blocking exchange of both streams (both sides sit in this loop, so neither misses a transfer); returns 1 when complete
static int LinkExchange(LinkCtx *L, int maxTransfers) {
    L->guard = 600000;
    int fails = 0, tries = 0, lin = 0;
    while (tries++ < maxTransfers * 4) {
        if (LinkTransfer(L)) { fails = 0; } else if (++fails > 40) break;
        if (LinkDone(L)) { if (++lin > 12) break; }          // linger so the peer receives the last acknowledgement
    }
    L->guard = 4000;
    return LinkDone(L);
}
