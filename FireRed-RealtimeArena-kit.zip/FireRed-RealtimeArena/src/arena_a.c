// arena_a.c - utilities, data access, actors, animation
#include "arena1.h"

#define AR() (*(Arena **)(&gMain.oamBuffer[127 * 8]))

static const s8 DIRX[8] = {0, 1, 1, 1, 0, -1, -1, -1};
static const s8 DIRY[8] = {1, 1, 0, -1, -1, -1, 0, 1};
static const u16 DIRLEN[8] = {256, 362, 256, 362, 256, 362, 256, 362};

static s32 iabs(s32 v) { return v < 0 ? -v : v; }
static s32 clampi(s32 v, s32 lo, s32 hi) { return v < lo ? lo : (v > hi ? hi : v); }
static u32 isqrt(u32 n) {
    u32 r = 0, b = 1u << 30;
    while (b > n) b >>= 2;
    while (b) {
        if (n >= r + b) { n -= r + b; r = (r >> 1) + b; }
        else r >>= 1;
        b >>= 2;
    }
    return r;
}
// link battles use a private xorshift generator seeded identically on both consoles (state in EWRAM; 0 = off, use the game's RNG)
#define LINKMODE (*(volatile u32 *)0x0203F7E0)
static u32 rnd(u32 n) {
    if (!n) return 0;
    volatile u32 *s = (volatile u32 *)0x0203F7E0;
    if (!*s) return (u32)Random() % n;
    u32 x = *s; x ^= x << 13; x ^= x >> 17; x ^= x << 5; *s = x;
    return (x >> 4) % n;
}

// ---------- game string -> ascii ----------
static void GameStr(const u8 *src, u8 *dst, int max) {
    int i = 0;
    for (; i < max - 1 && src[i] != 0xFF; i++) {
        u8 c = src[i], o = '?';
        if (c == 0) o = ' ';
        else if (c >= 0xA1 && c <= 0xAA) o = '0' + (c - 0xA1);
        else if (c == 0xAB) o = '!';
        else if (c == 0xAC) o = '?';
        else if (c == 0xAD) o = '.';
        else if (c == 0xAE) o = '-';
        else if (c == 0xB4) o = '\'';
        else if (c == 0xB5) o = 'M';
        else if (c == 0xB6) o = 'F';
        else if (c == 0xB8) o = ',';
        else if (c == 0xBA) o = '/';
        else if (c >= 0xBB && c <= 0xD4) o = 'A' + (c - 0xBB);
        else if (c >= 0xD5 && c <= 0xEE) o = 'A' + (c - 0xD5);
        else if (c == 0x1B) o = 'E';
        dst[i] = o;
    }
    dst[i] = 0;
}

static int slen(const char *s) { int n = 0; while (s[n]) n++; return n; }

// true while the player controls the character in the overworld (no script, dialog or menu has locked the field controls)
static int FieldFree(void) { return !((u8 (*)(void))0x08069959)(); }

// held-item evolutions: {species, held item, evolves into, minimum level}; the item is consumed
static const u16 EVO_HELD[9][4] = { {236, 4, 237, 15}, {236, 3, 106, 15}, {236, 2, 107, 15},
                                     {61, 187, 186, 36}, {79, 187, 199, 36}, {373, 192, 374, 36}, {373, 193, 375, 36},
                                    {133, 13, 196, 22}, {133, 14, 197, 22} };
static u16 EvoTarget(struct Pokemon *m) {
    u16 sp = GetMonData(m, MON_DATA_SPECIES, 0), it = GetMonData(m, MON_DATA_HELD_ITEM, 0);
    if (GetMonData(m, MON_DATA_CUTE, 0) == 255) return 0;          // the player refused to evolve it: never again
    if (it)
        for (int i = 0; i < 9; i++)
            if (EVO_HELD[i][0] == sp && EVO_HELD[i][1] == it && GetMonData(m, MON_DATA_LEVEL, 0) >= EVO_HELD[i][3]) return EVO_HELD[i][2];
    return GetEvolutionTargetSpeciesOld(m, 0, 0);
}
static void EvoConsumeItem(struct Pokemon *m, u16 old, u16 now) {
    u16 it = GetMonData(m, MON_DATA_HELD_ITEM, 0);
    for (int i = 0; i < 9; i++) if (EVO_HELD[i][0] == old && EVO_HELD[i][1] == it && EVO_HELD[i][2] == now) { u16 z = 0; SetMonData(m, MON_DATA_HELD_ITEM, &z); }
}

// cheat options, stored in two unused system flags at the very end of the flag array (so they live in the save file)
// n = 0: easy capture, 1: random wild Pokemon from every species, 2: easy mode (flag 0x8FD: enemies deal almost no damage)
static int CheatOn(int n) { u32 id = n == 2 ? 0x8FD : n == 3 ? 0x8FC : 0x8FE + n; return (gSaveBlock1Ptr[0xEE0 + (id >> 3)] >> (id & 7)) & 1; }
static void CheatSet(int n, int on) {
    u32 id = n == 2 ? 0x8FD : n == 3 ? 0x8FC : 0x8FE + n; u8 *b = &gSaveBlock1Ptr[0xEE0 + (id >> 3)];
    if (on) *b |= 1 << (id & 7); else *b &= ~(1 << (id & 7));
}
static void scopy(char *d, const char *s, int max) {
    int i = 0;
    for (; i < max - 1 && s[i]; i++) d[i] = s[i];
    d[i] = 0;
}
static int itoa_(int v, char *out) {   // returns length, no terminator
    char tmp[12]; int n = 0, neg = 0;
    if (v < 0) { neg = 1; v = -v; }
    if (v == 0) tmp[n++] = '0';
    while (v > 0) { tmp[n++] = '0' + v % 10; v /= 10; }
    int len = 0;
    if (neg) out[len++] = '-';
    while (n) out[len++] = tmp[--n];
    return len;
}

// ---------- game data ----------
static const u8 *MV(u16 id) { return gBattleMoves + (u32)id * 12; }
#define MV_EFFECT(m) ((m)[0])
#define MV_POWER(m)  ((m)[1])
#define MV_TYPE(m)   ((m)[2])
#define MV_ACC(m)    ((m)[3])
#define MV_PP(m)     ((m)[4])
#define MV_SEC(m)    ((m)[5])
#define MV_TARGET(m) ((m)[6])
#define MV_PRIO(m)   ((s8)(m)[7])
#define MV_FLAGS(m)  ((m)[8])

static int TypeMult(int atk, int d1, int d2) {   // x10
    int m = 10;
    const u8 *t = gTypeEffectiveness;
    for (; t[0] != 0xFF; t += 3) {
        if (t[0] == 0xFE) continue;
        if (t[0] != atk) continue;
        if (t[1] == d1) m = m * t[2] / 10;
        if (t[1] == d2 && d2 != d1) m = m * t[2] / 10;
    }
    return m;
}

static int MoveKind(const u8 *m) {
    u8 tgt = MV_TARGET(m);
    if (tgt == 0x10 || tgt == 0x02 || tgt == 0x40) return K_SELF;
    if (MV_FLAGS(m) & 1) return K_MELEE;
    if (tgt == 0x08 || tgt == 0x20) return K_SPREAD;
    return K_BOLT;
}

static int StageMul(int v, int stage) {     // stat stages
    static const u8 num[13] = {2, 2, 2, 2, 2, 2, 2, 3, 4, 5, 6, 7, 8};
    static const u8 den[13] = {8, 7, 6, 5, 4, 3, 2, 2, 2, 2, 2, 2, 2};
    stage = clampi(stage, -6, 6) + 6;
    return v * num[stage] / den[stage];
}
static int AccMul(int st) {                  // returns x100
    static const u16 t[13] = {33, 36, 43, 50, 60, 75, 100, 133, 166, 200, 233, 266, 300};
    return t[clampi(st, -6, 6) + 6];
}

// ---------- sprite record access ----------
static const u8 *RecFor(u16 nat) {
    if (nat == 0 || nat >= 512) return 0;
    u32 off = ((const u32 *)PACK)[nat];
    return off ? PACK + off : 0;
}
static const u16 *RecPal(const u8 *r) { return (const u16 *)(r + 8); }
static const u32 *RecFrameOff(const u8 *r) { return (const u32 *)(r + 40); }
static const u16 *RecAnimOff(const u8 *r) { return (const u16 *)(r + 40 + 4 * r[2]); }

static const u8 SHAPE_W[3][4] = {{8, 16, 32, 64}, {16, 32, 32, 64}, {8, 8, 16, 32}};
static const u8 SHAPE_H[3][4] = {{8, 16, 32, 64}, {8, 8, 16, 32}, {16, 32, 32, 64}};

// ---------- actors ----------
static const u8 *AnimData(Actor *a) { return a->rec + RecAnimOff(a->rec)[a->anim * 8 + a->dir]; }

static void PlayAnim(Actor *a, int slot, int loop) {
    a->anim = slot; a->aIdx = 0; a->aTick = 0; a->aLoop = loop; a->animDone = 0; a->hitFired = 0;
    const u8 *d = AnimData(a);
    u8 cnt = d[0], hi = 0xFF;
    for (u8 i = 0; i < cnt; i++) if (d[1 + i * 5 + 4] & 2) { hi = i; break; }
    if (hi == 0xFF) hi = cnt / 2;
    a->hitIdx = hi;
}

static void AnimStep(Actor *a) {
    const u8 *d = AnimData(a);
    u8 cnt = d[0];
    if (!cnt) return;
    if (a->aIdx >= cnt) a->aIdx = cnt - 1;
    const u8 *e = d + 1 + a->aIdx * 5;
    a->aTick++;
    if (a->aTick >= e[1]) {
        a->aTick = 0;
        a->aIdx++;
        if (a->aIdx >= cnt) {
            if (a->aLoop) a->aIdx = 0;
            else { a->aIdx = cnt - 1; a->animDone = 1; }
        }
    }
}

static u8 *StageOf(Arena *A, Actor *a, int which) { return a->cols ? A->bstage[which] : A->stage[which]; }

static void FreeBlocks(Arena *A, Actor *a) {
    for (int k = 1; k < 4; k++) {
        if (a->pb[k] >= 448) A->blkUsed &= ~(1 << ((a->pb[k] - 448) / 64));
        a->pb[k] = 0;
    }
}

// pieces of a big sprite: piece 0 lives in the actor's own tile slot, the others in free 64-tile blocks above tile 448
static void SetupPieces(Arena *A, Actor *a, int which, const u8 *rec) {
    static const u16 OBJBASE[4] = {0, 64, 320, 384};
    FreeBlocks(A, a);
    a->cols = rec[6]; a->rows = rec[7]; a->uh = rec[3];
    a->np = 1;
    a->pb[0] = OBJBASE[which];
    if (a->cols * a->rows > 1) {
        if (!A->bstage[which]) A->bstage[which] = (u8 *)AllocZeroed(8192);
        if (!A->bstage[which]) { a->cols = a->rows = 0; a->tiles = 64; return; }
        int want = a->cols * a->rows;
        for (int k = 1; k < want; k++) {
            int j = 0;
            while (j < 9 && (A->blkUsed & (1 << j))) j++;
            if (j == 9) break;
            A->blkUsed |= 1 << j; a->pb[k] = 448 + 64 * j; a->np = k + 1;
        }
    } else a->cols = a->rows = 0;
}

static void UploadFrame(Arena *A, Actor *a, int which) {
    const u8 *d = AnimData(a);
    if (!d[0]) return;
    u8 idx = a->aIdx >= d[0] ? d[0] - 1 : a->aIdx;
    u8 frame = d[1 + idx * 5];
    if (frame != a->curFrame && frame < a->nframes) {
        LZ77UnCompWram(a->rec + RecFrameOff(a->rec)[frame], StageOf(A, a, which));
        a->curFrame = frame;
        a->upPending = 1;
    }
}

static void SetPal(Arena *A, int bank, const u16 *pal) {
    for (int i = 0; i < 16; i++) A->objPal[bank * 16 + i] = pal[i];
}

static u8 StatusFromMon(u32 st) {
    if (st & 7) return S_SLEEP;
    if (st & 0x80) return S_TOXIC;
    if (st & 0x08) return S_POISON;
    if (st & 0x10) return S_BURN;
    if (st & 0x20) return S_FREEZE;
    if (st & 0x40) return S_PARA;
    return S_NONE;
}
static u32 StatusToMon(u8 s) {
    switch (s) {
    case S_SLEEP: return 2; case S_POISON: return 8; case S_TOXIC: return 0x80;
    case S_BURN: return 0x10; case S_FREEZE: return 0x20; case S_PARA: return 0x40;
    }
    return 0;
}

static int InitActor(Arena *A, Actor *a, struct Pokemon *mon, int isPlayer, int partyIdx, int which) {
    u16 species = GetMonData(mon, MON_DATA_SPECIES, 0);
    u16 nat = SpeciesToNationalPokedexNum(species);
    const u8 *rec = RecFor(nat);
    if (!rec) return 0;
    if (isPlayer) A->partMask |= 1 << partyIdx;     // took part in the battle (Exp)
    int hero = A->safari && isPlayer;              // Safari: you play as the trainer sprite
    if (hero) { const u8 *h = RecFor(509 + (gSaveBlock2Ptr[8] & 1)); if (h) rec = h; else hero = 0; }
    FreeBlocks(A, a);
    u8 *p = (u8 *)a;
    for (u32 i = 0; i < sizeof(Actor); i++) p[i] = 0;
    a->rec = rec; a->mon = mon; a->species = species; a->nat = nat;
    a->isPlayer = isPlayer; a->partyIdx = partyIdx; a->alive = 1;
    a->shape = rec[0]; a->size = rec[1]; a->nframes = rec[2]; a->tiles = rec[3];
    a->ox = rec[4]; a->oy = rec[5];
    a->w = SHAPE_W[a->shape][a->size]; a->h = SHAPE_H[a->shape][a->size];
    static const u16 OBJBASE[4] = {0, 64, 320, 384};
    static const u8 PALBANK[4] = {0, 1, 5, 7};
    a->objBase = OBJBASE[which];
    SetupPieces(A, a, which, rec);
    a->palBank = PALBANK[which];
    a->curFrame = 0xFF;
    a->level = GetMonData(mon, MON_DATA_LEVEL, 0);
    a->hp = GetMonData(mon, MON_DATA_HP, 0);
    a->maxHp = GetMonData(mon, MON_DATA_MAX_HP, 0);
    a->stat[0] = GetMonData(mon, MON_DATA_ATK, 0);
    a->stat[1] = GetMonData(mon, MON_DATA_DEF, 0);
    a->stat[2] = GetMonData(mon, MON_DATA_SPEED, 0);
    a->stat[3] = GetMonData(mon, MON_DATA_SPATK, 0);
    a->stat[4] = GetMonData(mon, MON_DATA_SPDEF, 0);
    const u8 *bs = gBaseStats + (u32)species * 28;
    a->type1 = bs[6]; a->type2 = bs[7];
    for (int i = 0; i < 4; i++) {
        a->moves[i] = GetMonData(mon, MON_DATA_MOVE1 + i, 0);
        a->pp[i] = GetMonData(mon, MON_DATA_PP1 + i, 0);
        a->cd[i] = 20 + i * 5;
    }
    a->status = StatusFromMon(GetMonData(mon, MON_DATA_STATUS, 0));
    if (a->status == S_SLEEP) a->statusTimer = 120;
    u8 nm[12];
    GetMonData(mon, 2, nm);        // nickname (game charset)
    GameStr(nm, a->name, 11);
    if (hero) GameStr(gSaveBlock2Ptr, a->name, 8);   // trainer name
    a->dir = isPlayer ? 2 : 6;
    SetPal(A, a->palBank, RecPal(rec));
    PlayAnim(a, ANIM_WALK, 1);
    UploadFrame(A, a, which);
    return 1;
}
