// arena_b.c - combat: damage, status, moves, projectiles
static void PopupAdd(Arena *A, int x, int y, const char *txt, int pal) {
    for (int i = 0; i < 8; i++) {
        Popup *p = &A->pop[i];
        if (!p->timer) {
            p->x = x; p->y = y; p->timer = 48; p->pal = pal;
            int n = slen(txt); if (n > 7) n = 7;
            for (int k = 0; k < n; k++) p->text[k] = txt[k];
            p->len = n;
            return;
        }
    }
}
static void PopupNum(Arena *A, int x, int y, int v, int pal) {
    char b[12]; int n = itoa_(v, b); b[n] = 0;
    PopupAdd(A, x, y, b, pal);
}
// animation style of a move's projectile (the game's own sprite, drawn several times)
enum { ST_ONE, ST_POWDER, ST_STREAM, ST_MULTI, ST_ORBIT, ST_FLAME, ST_WAVE, ST_TORNADO, ST_FIRESTAR, ST_GALE, ST_BEANS, ST_QUAKE, ST_MOUND, ST_RINGS, ST_FALL, ST_DIVE, ST_WHIPS, ST_DRAGON, ST_JET, ST_ECG };
static int FxStyle(int id) {
    switch (id) {
    case 126: return ST_FIRESTAR;                               // Fire Blast: a big fire star with a trail of flames
    case 59: return ST_GALE;                                    // Blizzard: an icy gale sweeping forward
    case 58: return ST_BEANS;                                   // Ice Beam: a heap of bean-shaped ice balls
    case 89: case 222: return ST_QUAKE;
    case 82: return ST_DRAGON;                                  // Dragon Rage: a yellow dragon flies at the target
    case 75: return ST_BEANS;                                   // Razor Leaf: a heap of leaves flying forward (long range)
    case 22: return ST_WHIPS;                                   // Vine Whip: two vine lashes flying forward (long range)
    case 145: return ST_BEANS;                                  // Bubble: a heap of small bubbles drifting forward (same scatter as the ice beans)
    case 352: return ST_RINGS;                                  // Water Pulse: water rings one behind the other
    case 127: return ST_FALL;                                   // Waterfall: a column of falling water at medium range
    case 291: return ST_DIVE;                                   // Dive: a leap in the water, long range
    case 91: return ST_MOUND;                                   // Dig: a mound of earth ploughs forward, the crater opens where it hits                                   // Earthquake: a train of ground cracks rolling forward (long range)
    case 16: return ST_TORNADO;                                 // Gust: a spinning tornado travels to the target
    case 72: case 202: return ST_BEANS;                         // Mega/Giga Drain: a heap of green balls flying at the target
    case 84: return ST_ECG;                                     // Thunder Shock: an electrocardiogram trace racing at the target
    case 56: return ST_JET;                                     // Hydro Pump: a long continuous jet of water
    case 57: return ST_WAVE;                                    // Surf: waves rolling forward (a long range projectile, not a burst around the user)
    case 53: return ST_FLAME;                                   // Flamethrower: a long wavering column of flames (Ember keeps the short stream)
    case 77: case 78: case 79: case 147: case 230: case 73: return ST_POWDER;
    case 41: case 42: case 131: case 140: case 155: case 198: case 331: case 350: return ST_MULTI;
    case 83: case 250: case 35: case 20: case 239: case 48: case 109: case 47: case 320: case 86: case 95:
    case 93: case 139: case 92: case 18: return ST_ORBIT;
    case 51: return ST_WAVE;                                    // Acid: a flat sheet of acid on the ground, flowing forward (long range)
    case 52: case 55: case 60: case 61: case 62: case 63:
    case 76: case 94: case 124: case 188: case 192: case 247: case 315: case 353:
        return ST_STREAM;
    }
    const u8 *m = MV(id);
    if (MV_POWER(m) == 0) return ST_ORBIT;                    // status moves: waves / rings
    switch (MV_TYPE(m)) {
    case 10: case 11: case 13: case 14: case 15: case 16: case 17: case 7: case 3: return ST_STREAM;
    }
    return ST_MULTI;                                           // grass, bug, rock, ground, fighting, flying, normal, steel
}
#define MOVEFX ((const u8 *)0x09C00000)
#define FXTILE(s) (256 + (s) * 16)
// move-effect sprites come from FireRed's own battle-animation graphics (see tools/extract_movefx.py)
static void LoadFx(Arena *A, int owner, int id) {
    if (A->fxMove[owner] == id || id <= 0 || id >= 355) return;
    A->fxMove[owner] = id;
    const u32 *t = (const u32 *)MOVEFX;
    for (int k = 0; k < 2; k++) {
        int s = owner * 2 + k;
        u32 off = t[id * 2 + k];
        if (!off || off == 0xFFFFFFFF) { A->fxN[s] = 0; continue; }
        const u8 *b = MOVEFX + off;
        A->fxShape[s] = b[0]; A->fxSize[s] = b[1]; A->fxN[s] = b[2];
        const u16 *pal = (const u16 *)(b + 4);
        for (int i = 0; i < 16; i++) A->objPal[(8 + s) * 16 + i] = pal[i];
        if (id == 211 && k == 0)                                // Steel Wing: silver wings
            for (int i = 1; i < 16; i++) {
                u16 c = pal[i]; int lum = ((c & 31) * 3 + ((c >> 5) & 31) * 6 + ((c >> 10) & 31)) / 10;
                int v = 9 + lum * 20 / 31, bl = v + 3 > 31 ? 31 : v + 3;
                A->objPal[(8 + s) * 16 + i] = v | v << 5 | bl << 10;
            }
        if (id == 240 && k == 0)                                // Rain Dance: blue raindrops
            for (int i = 1; i < 16; i++) {
                u16 c = pal[i]; int lum = ((c & 31) * 3 + ((c >> 5) & 31) * 6 + ((c >> 10) & 31)) / 10;
                A->objPal[(8 + s) * 16 + i] = (3 + lum * 8 / 31) | (8 + lum * 14 / 31) << 5 | (20 + lum * 11 / 31) << 10;
            }
        A->fxSrc[s] = b + 36;
        A->fxPend |= 1 << s;
    }
}
static void FxAdd(Arena *A, int x, int y, int kind) {
    for (int i = 0; i < 8; i++) {
        Fx *f = &A->fx[i];
        if (!f->active) { f->active = 1; f->x = x; f->y = y; f->timer = 0; f->kind = kind; f->pad = A->fxOwner; return; }
    }
}
static void RainAdd(Arena *A, Actor *a) {            // Rain Dance: drizzle falling over the user (follows it)
    for (int i = 0; i < 8; i++) {
        Fx *f = &A->fx[i];
        if (!f->active) { f->active = 1; f->x = 0; f->y = 0; f->timer = 0; f->kind = 7; f->pad = A->fxOwner | ((a - A->act) << 1); return; }
    }
}
static void Msg(Arena *A, const char *s, int frames) {
    scopy(A->msg, s, 32);
    A->msgTimer = frames;
}

static int BodyX(Actor *a) { return a->x >> 8; }
static int BodyY(Actor *a) { return (a->y >> 8) - 8; }
static int DistBody(Actor *a, Actor *t) {
    s32 dx = BodyX(t) - BodyX(a), dy = BodyY(t) - BodyY(a);
    return isqrt(dx * dx + dy * dy);
}
static int DirFromVec(s32 dx, s32 dy) {
    s32 ax = iabs(dx), ay = iabs(dy);
    int sx = dx > 0 ? 1 : (dx < 0 ? -1 : 0), sy = dy > 0 ? 1 : (dy < 0 ? -1 : 0);
    if (ay * 2 < ax) sy = 0;
    else if (ax * 2 < ay) sx = 0;
    for (int d = 0; d < 8; d++) if (DIRX[d] == sx && DIRY[d] == sy) return d;
    return 0;
}
static Actor *FoeOf(Arena *A, Actor *a) {
    int me = a - A->act, best = -1, bd = 0x7FFFFFFF;
    for (int i = 0; i < 4; i++) {
        if ((i & 1) == (me & 1) || !(A->pm & (1 << i))) continue;
        Actor *t = &A->act[i];
        if (!t->alive) continue;
        int d = DistBody(a, t);
        if (d < bd) { bd = d; best = i; }
    }
    if (best < 0) best = (me & 1) ^ 1;
    return &A->act[best];
}
static void FaceToward(Actor *a, Actor *t) {
    a->dir = DirFromVec(BodyX(t) - BodyX(a), BodyY(t) - BodyY(a));
}

static int Eff(Actor *a, int idx) {
    int v = StageMul(a->stat[idx], a->stage[idx]);
    if (idx == 2 && a->status == S_PARA) v /= 3;
    return v < 1 ? 1 : v;
}

static void Faint(Arena *A, Actor *a) {
    a->hp = 0; a->alive = 0; a->phase = PH_FAINT; a->fainted = 1;
    a->stun = 0; a->status = a->status == S_POISON || a->status == S_TOXIC ? a->status : S_NONE;
    PlayAnim(a, ANIM_HURT, 0);
}

static void StageChange(Arena *A, Actor *t, int stat, int delta) {
    static const char *names[7] = {"ATK", "DEF", "SPD", "SP.A", "SP.D", "ACC", "EVA"};
    int old = t->stage[stat];
    if (delta < 0 && (t->focus & 4)) { PopupAdd(A, BodyX(t) - 8, BodyY(t) - 22, "GUARD", 6); return; }
    int nw = clampi(old + delta, -6, 6);
    char buf[10];
    int x = BodyX(t) - 8, y = BodyY(t) - 22;
    if (nw == old) { PopupAdd(A, x, y, delta > 0 ? "MAX" : "MIN", 4); return; }
    t->stage[stat] = nw;
    scopy(buf, names[stat], 8);
    int n = slen(buf);
    buf[n] = delta > 0 ? '+' : '-'; buf[n + 1] = 0;
    PopupAdd(A, x - 4, y, buf, delta > 0 ? 6 : 7);
    FxAdd(A, BodyX(t), BodyY(t), 3);
}

static int CanInflict(Actor *t, int st) {
    if (t->status != S_NONE || !t->alive) return 0;
    if ((st == S_POISON || st == S_TOXIC) && (t->type1 == 3 || t->type2 == 3 || t->type1 == 8 || t->type2 == 8)) return 0;
    if (st == S_BURN && (t->type1 == 10 || t->type2 == 10)) return 0;
    if (st == S_FREEZE && (t->type1 == 15 || t->type2 == 15)) return 0;
    return 1;
}
static void Inflict(Arena *A, Actor *t, int st) {
    static const char *nm[7] = {"", "SLEEP", "POISON", "BURN", "FREEZE", "PARA", "POISON"};
    if (!CanInflict(t, st)) { PopupAdd(A, BodyX(t) - 12, BodyY(t) - 22, "NO EFFECT", 4); return; }
    t->status = st; t->statusTick = 0;
    if (st == S_SLEEP) t->statusTimer = 150 + rnd(150);
    else if (st == S_FREEZE) t->statusTimer = 180 + rnd(150);
    else t->statusTimer = 0;
    PopupAdd(A, BodyX(t) - 10, BodyY(t) - 22, nm[st], 5);
    FxAdd(A, BodyX(t), BodyY(t), 3);
}

static int CalcDamage(Actor *at, Actor *df, const u8 *m, int *effm, int *crit) {
    int power = MV_POWER(m), type = MV_TYPE(m);
    int special = type >= 10;
    int a = special ? Eff(at, 3) : Eff(at, 0);
    int d = special ? Eff(df, 4) : Eff(df, 1);
    if (!special && at->status == S_BURN) a /= 2;
    int base = ((2 * at->level / 5 + 2) * power * a / d) / 50 + 2;
    int chance = (MV_EFFECT(m) == 43 || at->focus) ? 8 : 16;
    *crit = 0;
    if (rnd(chance) == 0) { base *= 2; *crit = 1; }
    if (!special && df->reflect) base /= 2;
    if (special && df->lscreen) base /= 2;
    if (type == at->type1 || type == at->type2) base = base * 3 / 2;
    *effm = TypeMult(type, df->type1, df->type2);
    base = base * *effm / 10;
    base = base * (85 + rnd(16)) / 100;
    if (*effm > 0 && base < 1) base = 1;
    return base;
}

static void DamageActor(Arena *A, Actor *att, Actor *df, int dmg, int effm, int crit, int fireHit) {
    if (att && !att->isPlayer && df->isPlayer && !LINKMODE && CheatOn(2)) { dmg /= 12; if (dmg < 1) dmg = 1; }   // easy mode: enemies hardly hurt, type advantage included
    int x = BodyX(df), y = BodyY(df);
    if (dmg > df->hp) dmg = df->hp;
    df->hp -= dmg;
    PopupNum(A, x - 4, y - 20, dmg, crit ? 3 : 0);
    if (crit) PopupAdd(A, x - 16, y - 30, "CRIT!", 3);
    else if (effm > 10) PopupAdd(A, x - 18, y - 30, "SUPER!", 3);
    else if (effm < 10 && effm > 0) PopupAdd(A, x - 12, y - 30, "WEAK", 2);
    if (!(att && att->moves[att->curSlot] == 337)) FxAdd(A, x, y, 0);      // Dragon Claw shows only its claws
    if (att) {
        // knockback away from the attacker
        s32 dx = x - BodyX(att), dy = y - BodyY(att);
        s32 l = isqrt(dx * dx + dy * dy); if (!l) l = 1;
        s32 k = 384 + (dmg * 640 / (df->maxHp > 0 ? df->maxHp : 1));
        if (k > 1100) k = 1100;
        df->kx = dx * k / l; df->ky = dy * k / l;
    }
    df->flash = 14;
    if (df->status == S_SLEEP) { df->status = S_NONE; df->stun = 0; }
    if (df->status == S_FREEZE && fireHit) df->status = S_NONE;
    if (df->hp <= 0) { Faint(A, df); return; }
    if (df->phase == PH_FREE || df->phase == PH_HURT) {
        df->phase = PH_HURT; df->stun = 14;
        PlayAnim(df, ANIM_HURT, 0);
    }
}

static int MoveCd(Actor *a, const u8 *m) {
    int pow = MV_POWER(m);
    int base = 30 + (pow > 1 ? pow * 3 / 4 : 18);
    int pp = MV_PP(m);
    if (pp <= 5) base += 40; else if (pp <= 10) base += 25; else if (pp <= 15) base += 10;
    if (MV_EFFECT(m) == 80) base += 40;
    base = base * 100 / (100 + a->stat[2] / 3);
    return clampi(base, 30, 200);
}

static void Heal(Arena *A, Actor *a, int v) {
    if (v < 1) v = 1;
    a->hp += v; if (a->hp > a->maxHp) a->hp = a->maxHp;
    PopupNum(A, BodyX(a) - 4, BodyY(a) - 22, v, 1);
}

static void ResolveSelf(Arena *A, Actor *a, int id) {
    const u8 *m = MV(id); int e = MV_EFFECT(m);
    A->fxOwner = a->isPlayer ? 0 : 1;
    FxAdd(A, BodyX(a), BodyY(a) - 4, 4);
    if (e >= 10 && e <= 16) StageChange(A, a, e - 10, 1);
    else if (e >= 50 && e <= 56) StageChange(A, a, e - 50, 2);
    else if (e == 32) Heal(A, a, a->maxHp / 2);
    else if (e == 37) { if (a->hp < a->maxHp) { a->hp = a->maxHp; a->status = S_SLEEP; a->statusTimer = 140; PopupAdd(A, BodyX(a) - 8, BodyY(a) - 22, "REST", 1);} }
    else if (e == 47) { a->focus = 1; PopupAdd(A, BodyX(a) - 16, BodyY(a) - 22, "FOCUS", 6); }
    else if (e == 65) { a->reflect = 900; PopupAdd(A, BodyX(a) - 16, BodyY(a) - 22, "REFLECT", 6); }
    else if (e == 35) { a->lscreen = 900; PopupAdd(A, BodyX(a) - 16, BodyY(a) - 22, "SCREEN", 6); }
    else if (e == 111) { a->invuln = 40; FxAdd(A, BodyX(a), BodyY(a), 2); }
    else if (e == 25) { for (int i = 0; i < 4; i++) for (int s = 0; s < 7; s++) A->act[i].stage[s] = 0; PopupAdd(A, BodyX(a) - 8, BodyY(a) - 22, "HAZE", 5); }
    else if (e == 108) StageChange(A, a, 6, 1);
    else if (e == 156) StageChange(A, a, 1, 1);
    else if (e == 26 || e == 85) { /* bide / splash: nothing */ }
    FxAdd(A, BodyX(a), BodyY(a), 3);
}

// Transform (Ditto): copies the target's looks, stats, stat stages, types and moves (5 PP each)
static void TransformInto(Arena *A, Actor *a, Actor *t) {
    int which = a - A->act;
    a->rec = t->rec; a->shape = t->shape; a->size = t->size; a->nframes = t->nframes; a->tiles = t->tiles;
    SetupPieces(A, a, which, t->rec);
    a->ox = t->ox; a->oy = t->oy; a->w = t->w; a->h = t->h;
    a->curFrame = 0xFF; a->aIdx = 0; a->aTick = 0;
    SetPal(A, a->palBank, RecPal(a->rec));
    for (int i = 0; i < 5; i++) a->stat[i] = t->stat[i];
    for (int i = 0; i < 7; i++) a->stage[i] = t->stage[i];
    a->type1 = t->type1; a->type2 = t->type2;
    for (int i = 0; i < 4; i++) { a->moves[i] = t->moves[i]; a->pp[i] = t->moves[i] ? 5 : 0; a->cd[i] = 20 + i * 5; }
    a->curSlot = 0; a->xform = 1;
    UploadFrame(A, a, which);
    PopupAdd(A, BodyX(a) - 18, BodyY(a) - 22, "COPIED", 5);
    FxAdd(A, BodyX(a), BodyY(a), 3);
}

static void ResolveHit(Arena *A, Actor *att, Actor *df, int id) {
    const u8 *m = MV(id);
    int e = MV_EFFECT(m), power = MV_POWER(m), acc = MV_ACC(m), type = MV_TYPE(m);
    if (!df->alive || df->invuln || df->phase == PH_CAPTURED) return;
    A->fxOwner = att->isPlayer ? 0 : 1;
    if (id == 144) { TransformInto(A, att, df); return; }
    if (acc && e != 17) {
        int chance = acc * AccMul(att->stage[5] - df->stage[6]) / 100;
        if (e == 38) chance = att->level >= df->level ? 30 + att->level - df->level : 0;
        if ((int)rnd(100) >= chance) { PopupAdd(A, BodyX(df) - 8, BodyY(df) - 22, "MISS", 4); return; }
    }
    if (power > 0) {
        int effm = 10, crit = 0, dmg;
        if (e == 130) dmg = 20;
        else if (e == 41) dmg = 40;
        else if (e == 87) dmg = att->level;
        else if (e == 88) dmg = 1 + rnd(att->level * 3 / 2 + 1);
        else if (e == 40) { dmg = df->hp / 2; if (dmg < 1) dmg = 1; }
        else if (e == 38) dmg = df->hp;
        else dmg = CalcDamage(att, df, m, &effm, &crit);
        if (e == 130 || e == 41 || e == 87 || e == 88 || e == 40 || e == 38) {
            effm = TypeMult(type, df->type1, df->type2);
            if (effm == 0) dmg = 0;
        }
        if (e == 29) dmg = dmg * (2 + rnd(4));
        else if (e == 44) dmg *= 2;
        att->focus &= 2;
        if (effm == 0 || dmg == 0) { PopupAdd(A, BodyX(df) - 14, BodyY(df) - 22, "NO EFFECT", 4); return; }
        DamageActor(A, att, df, dmg, effm, crit, type == 10);
        int sec = MV_SEC(m);
        if (df->alive) {
            switch (e) {
            case 2: if ((int)rnd(100) < sec) Inflict(A, df, S_POISON); break;
            case 4: if ((int)rnd(100) < sec) Inflict(A, df, S_BURN); break;
            case 5: if ((int)rnd(100) < sec) Inflict(A, df, S_FREEZE); break;
            case 6: if ((int)rnd(100) < sec) Inflict(A, df, S_PARA); break;
            case 31: if ((int)rnd(100) < sec) { df->stun = 26; df->phase = PH_HURT; PlayAnim(df, ANIM_HURT, 0);} break;
            case 76: if ((int)rnd(100) < sec) { df->confTimer = 240; PopupAdd(A, BodyX(df) - 12, BodyY(df) - 22, "CONFUSE", 5);} break;
            case 42: df->trapTimer = 300; break;
            case 68: case 69: case 70: case 71: case 72: case 73: case 74:
                if ((int)rnd(100) < sec) StageChange(A, df, e - 68, -1); break;
            }
        }
        if (e == 3 || e == 8) Heal(A, att, dmg / 2);
        if ((e == 48 || e == 198) && att->alive) {
            int r = e == 48 ? dmg / 4 : dmg / 3; if (r < 1) r = 1;
            att->hp -= r; PopupNum(A, BodyX(att) - 4, BodyY(att) - 20, r, 2);
            if (att->hp <= 0) Faint(A, att);
        }
        if (e == 80) att->recharge = 70;
    } else {
        // pure status move aimed at the target
        if (e == 1 || e == 66 || e == 33 || e == 67) {
            if (e == 67 && TypeMult(type, df->type1, df->type2) == 0) { PopupAdd(A, BodyX(df) - 14, BodyY(df) - 22, "NO EFFECT", 4); return; }
            Inflict(A, df, e == 1 ? S_SLEEP : (e == 66 ? S_POISON : (e == 33 ? S_TOXIC : S_PARA)));
        } else if (e == 49) { df->confTimer = 240; PopupAdd(A, BodyX(df) - 12, BodyY(df) - 22, "CONFUSE", 5); FxAdd(A, BodyX(df), BodyY(df), 3); }
        else if (e >= 18 && e <= 24) StageChange(A, df, e - 18, -1);
        else if (e >= 58 && e <= 64) StageChange(A, df, e - 58, -2);
        else if (id != 337) FxAdd(A, BodyX(df), BodyY(df), 3);
    }
}

static int TypeBank(Arena *A, int type) {
    int free_ = -1, oldest = 0;
    for (int i = 0; i < NTB; i++) {
        if (A->typeBankType[i] == type + 1) { A->typeBankAge[i] = 0; return 6 + i; }
        if (A->typeBankType[i] == 0 && free_ < 0) free_ = i;
        if (A->typeBankAge[i] > A->typeBankAge[oldest]) oldest = i;
    }
    int s = free_ >= 0 ? free_ : oldest;
    A->typeBankType[s] = type + 1; A->typeBankAge[s] = 0;
    A->objPal[(6 + s) * 16 + 0] = 0;
    for (int k = 0; k < 3; k++) A->objPal[(6 + s) * 16 + 1 + k] = gTypeColors[type][k];
    return 6 + s;
}

static void SpawnProj(Arena *A, Actor *a, Actor *t, int kind, int id, int speed) {
    for (int i = 0; i < 10; i++) {
        Proj *p = &A->proj[i];
        if (p->active) continue;
        s32 dx = BodyX(t) - BodyX(a), dy = BodyY(t) - BodyY(a);
        s32 dist = isqrt(dx * dx + dy * dy); if (!dist) dist = 1;
        s32 dot = DIRX[a->dir] * dx + DIRY[a->dir] * dy;
        s32 ux, uy;
        if (dot * 512 >= (s32)DIRLEN[a->dir] * dist) { ux = dx * 256 / dist; uy = dy * 256 / dist; }
        else { ux = DIRX[a->dir] * 256 * 256 / DIRLEN[a->dir]; uy = DIRY[a->dir] * 256 * 256 / DIRLEN[a->dir]; }
        p->active = 1; p->kind = kind; p->owner = a - A->act; p->move = id;
        p->x = (BodyX(a) << 8) + ux * 10; p->y = (BodyY(a) << 8) + uy * 10;
        p->vx = ux * speed / 256; p->vy = uy * speed / 256;
        p->life = kind ? 90 : (id == 127 ? 50 : 70);
        p->ptype = kind ? 0 : MV_TYPE(MV(id));
        p->pal = kind == 1 ? 3 : (kind ? 6 : TypeBank(A, p->ptype));
        return;
    }
}

static u16 Metronome(void) {
    for (int tries = 0; tries < 40; tries++) {
        u16 id = 1 + rnd(250);
        const u8 *m = MV(id);
        if (MV_EFFECT(m) == 83 || id == 165 || id == 118 || MV_EFFECT(m) == 89 || MV_EFFECT(m) == 82) continue;
        if (MV_POWER(m) > 0 || MV_EFFECT(m) != 0) return id;
    }
    return 33;
}

static void FireMove(Arena *A, Actor *a) {
    Actor *t = FoeOf(A, a);
    u16 id = a->relPad ? 165 : a->moves[a->curSlot];
    if (MV_EFFECT(MV(id)) == 83) id = Metronome();
    const u8 *m = MV(id);
    int kind = MoveKind(m);
    A->fxOwner = a->isPlayer ? 0 : 1;
    LoadFx(A, A->fxOwner, id);
    if (id == 240) {
        RainAdd(A, a);
    } else if (kind == K_SELF) {
        ResolveSelf(A, a, id);
    } else if (kind == K_MELEE && id != 91 && id != 127 && id != 291 && id != 22) {
        if (DistBody(a, t) <= 36) { ResolveHit(A, a, t, id); FxAdd(A, BodyX(t), BodyY(t), (id == 17 || id == 211) ? 5 : id == 91 ? 6 : 4); }
    } else if (kind == K_SPREAD && id != 57 && id != 89 && id != 59 && id != 222 && id != 145 && id != 75 && id != 51) {
        FxAdd(A, BodyX(a), BodyY(a), 2);
        for (int i = 0; i < 4; i++) {
            Actor *x = &A->act[i];
            if ((i & 1) == (a - A->act & 1) || !(A->pm & (1 << i))) continue;
            if (DistBody(a, x) <= 64) ResolveHit(A, a, x, id);
        }
    } else {
        { int st = FxStyle(id); SpawnProj(A, a, t, 0, id, st == ST_JET ? 760 : st == ST_ECG ? 720 : st == ST_DIVE ? 840 : st == ST_WHIPS ? 700 : st == ST_DRAGON ? 720 : st == ST_RINGS ? 640 : st == ST_FALL ? 512 : st == ST_MOUND ? 520 : st == ST_QUAKE ? 560 : st == ST_GALE ? 520 : st == ST_BEANS ? 760 : st == ST_WAVE ? 600 : st == ST_TORNADO ? 480 : st == ST_FIRESTAR ? 640 : st == ST_POWDER ? 380 : (st == ST_ORBIT ? 520 : (st == ST_MULTI ? 700 : 800))); }
    }
    if (MV_EFFECT(m) == 7 && a->alive) Faint(A, a);   // explosion / selfdestruct
}

static int TryStartMove(Arena *A, Actor *a, int slot) {
    Actor *t = FoeOf(A, a);
    if (a->phase != PH_FREE || !a->alive || a->stun || a->recharge) return 0;
    if (a->status == S_SLEEP || a->status == S_FREEZE) return 0;
    if (slot < 0 || slot > 3 || !a->moves[slot] || a->cd[slot]) return 0;
    a->relPad = 0;
    if ((a->isPlayer || LINKMODE) && a->pp[slot] == 0) {
        if (LINKMODE) return 0;
        a->relPad = 1;                                   // out of PP: the move turns into Struggle (relPad = 1), so you can always keep fighting
    }
    const u8 *m = MV(a->relPad ? 165 : a->moves[slot]);
    if (a->status == S_PARA && rnd(4) == 0) {
        PopupAdd(A, BodyX(a) - 14, BodyY(a) - 24, "PARALYZED", 4);
        a->stun = 24; a->cd[slot] = 20; return 0;
    }
    if (a->confTimer && rnd(3) == 0) {
        int d = ((2 * a->level / 5 + 2) * 40 * Eff(a, 0) / Eff(a, 1)) / 50 + 2;
        PopupAdd(A, BodyX(a) - 14, BodyY(a) - 24, "CONFUSED", 5);
        a->cd[slot] = 30; a->stun = 20;
        DamageActor(A, 0, a, d, 10, 0, 0);
        return 0;
    }
    a->curSlot = slot;
    int kind = MoveKind(m);
    if (kind == K_MELEE && t->alive && ((a->isPlayer || LINKMODE) ? DistBody(a, t) <= 44 : 1)) FaceToward(a, t);
    a->phase = PH_ATTACK; a->moving = 0;
    PlayAnim(a, kind == K_MELEE ? ANIM_ATTACK : ANIM_SHOOT, 0);
    a->cd[slot] = MoveCd(a, m);
    if ((a->isPlayer || LINKMODE) && a->pp[slot]) a->pp[slot]--;
    A->partyUsedMask |= a->isPlayer ? (1 << a->partyIdx) : 0;
    return 1;
}
