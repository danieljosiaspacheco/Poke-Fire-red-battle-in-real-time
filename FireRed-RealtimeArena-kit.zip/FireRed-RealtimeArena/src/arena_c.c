// arena_c.c - capture, AI, input, update loop
extern u16 CountTotalItemQuantityInBag(u16 item);
static void UiOpen(Arena *A, int ui, int forced);
#define NBALL 12
static const u16 BALL_ITEMS[NBALL] = {4, 3, 2, 1, 5, 6, 7, 8, 9, 10, 11, 12};
static const char *BALL_NAMES[NBALL] = {"POKE", "GREAT", "ULTRA", "MASTER", "SAFARI", "NET", "DIVE", "NEST", "REPEAT", "TIMER", "LUXURY", "PREMIER"};
// the 12 Poke Ball sprites of the original game (item icons shrunk to 12x12, tools/pack_balls.py): record = 16 colours + 4 tiles
#define BALLPACK ((const u8 *)0x09DFF800)
#define BALLGFX 224                                  // OBJ tile index of ball 0 (4 tiles each, 224..271; 160..223 is the OBJ font)
static void SetBallPalBank(Arena *A, int bank, int idx) {
    const u16 *p = (const u16 *)(BALLPACK + idx * 160);
    for (int i = 0; i < 16; i++) A->objPal[bank * 16 + i] = p[i];
}
static void SetBallPal(Arena *A, int idx) { A->ballTile = idx; SetBallPalBank(A, 3, idx); }
// release of a Pokemon from its ball (start of the battle, switching, the trainer's next Pokemon): a ball flies in from the corner of its
// side, lands on the spot, opens in a burst and the Pokemon appears in a white flash.  Wild Pokemon just appear.
#define REL_FL 44                      // frames of the ball's flight
#define REL_APP 52                     // the Pokemon appears this many frames after the start
#define REL_TOT (REL_APP + 18)
static int BallIdxOf(u32 id) { if (id < 1 || id > 12) return 0; return id <= 4 ? 4 - id : id - 1; }   // item id -> BALL_ITEMS index
static void StartRelease(Arena *A, Actor *a, int slot) {
    if (A->safari && a->isPlayer) return;
    if (!a->isPlayer && !A->isTrainer && !A->link) return;
    a->relBall = (a->isPlayer || A->link) ? BallIdxOf(GetMonData(a->mon, MON_DATA_POKEBALL, 0)) : 0;
    a->relDelay = 0;
    if (a->isPlayer && slot == 2 && A->act[0].relT) a->relDelay = A->act[0].relDelay + A->act[0].relT;   // both players' balls use one palette bank: one after the other
    a->relT = REL_TOT;
    a->stun = a->invuln = a->relDelay + REL_TOT;
}
static const u8 BALL_BONUS[NBALL] = {10, 15, 20, 255, 15, 10, 10, 10, 10, 10, 10, 10};

static void WriteBack(Actor *a) {
    u16 hp = a->hp < 0 ? 0 : a->hp;
    SetMonData(a->mon, MON_DATA_HP, &hp);
    if (!a->xform) for (int i = 0; i < 4; i++) SetMonData(a->mon, MON_DATA_PP1 + i, &a->pp[i]);
    u32 st = StatusToMon(a->status);
    SetMonData(a->mon, MON_DATA_STATUS, &st);
}

// ---------- capture ----------
static void BeginCapture(Arena *A, int ballIdx) {
    Actor *e = &A->act[1];
    A->capState = CAP_ABSORB; A->capTimer = 0; A->capBall = ballIdx;
    A->capX = BodyX(e); A->capY = BodyY(e);
    e->phase = PH_CAPTURED; e->moving = 0;
    int rate = gBaseStats[(u32)e->species * 28 + 8];
    if (A->safari) {                          // safari catch factor: rocks double it, bait halves it
        int fct = rate * 100 / 1275;
        if (fct < 3) fct = 3;
        if (fct > 20) fct = 20;
        if (A->sfAngry) { fct *= 2; if (fct > 20) fct = 20; }
        if (A->sfBait) { fct /= 2; if (fct < 3) fct = 3; }
        rate = fct * 1275 / 100;
    }
    int bonus = BALL_BONUS[ballIdx];
    if (ballIdx == 5 && (e->type1 == 11 || e->type2 == 11 || e->type1 == 6 || e->type2 == 6)) bonus = 30;   // net: water/bug
    else if (ballIdx == 6 && (e->type1 == 11 || e->type2 == 11)) bonus = 35;                                  // dive (water)
    else if (ballIdx == 7 && e->level <= 29) bonus = 41 - e->level;                                          // nest
    else if (ballIdx == 8 && GetSetPokedexFlag(e->nat, 1)) bonus = 30;                                       // repeat
    else if (ballIdx == 9) { bonus = 10 + (int)(A->frame / 180); if (bonus > 40) bonus = 40; }               // timer
    int shakes = 0, success = 0;
    if (ballIdx == 3 || CheatOn(0)) { success = 1; shakes = 4; }
    else {
        s32 maxh = e->maxHp, hp = e->hp;
        s32 a = ((3 * maxh - 2 * hp) * rate * bonus / 10) / (3 * maxh);
        if (e->status == S_SLEEP || e->status == S_FREEZE) a *= 2;
        else if (e->status != S_NONE) a = a * 3 / 2;
        if (a < 1) a = 1;
        if (a >= 255) { success = 1; shakes = 4; }
        else {
            u32 b = 1048560 / isqrt(isqrt(16711680 / a));
            for (int i = 0; i < 4; i++) { if (rnd(65536) < b) shakes++; else break; }
            success = shakes >= 4;
        }
    }
    A->capShakes = shakes > 3 ? 3 : shakes; A->capSuccessAt = success;
}

static void StartThrow(Arena *A, Actor *p, int kind) {     // kind 4 ball, 5 bait, 6 rock (safari)
    Actor *e = &A->act[1];
    if (A->ballCd || A->capState != CAP_NONE || !e->alive || p->phase != PH_FREE || A->sfLeave) return;
    if (kind == 4) {
        if (A->safari) {
            if (!gNumSafariBalls) { Msg(A, "NO SAFARI BALLS LEFT!", 60); return; }
            gNumSafariBalls--;
        } else {
            int sel = A->ballSel;
            if (!CountTotalItemQuantityInBag(BALL_ITEMS[sel])) { Msg(A, "NO BALLS OF THAT KIND!", 60); return; }
            RemoveBagItem(BALL_ITEMS[sel], 1);
        }
    }
    if (kind == 4) SetBallPal(A, A->safari ? 4 : A->ballSel);
    A->ballCd = kind == 4 ? 50 : 30;
    p->curSlot = kind; p->phase = PH_ATTACK; p->moving = 0;
    if (DistBody(p, e) < 200) FaceToward(p, e);
    PlayAnim(p, ANIM_SHOOT, 0);
}

static void CaptureUpdate(Arena *A) {
    Actor *e = &A->act[1];
    if (A->capState == CAP_NONE || A->capState == CAP_FLY) return;
    A->capTimer++;
    if (A->capState == CAP_ABSORB) {
        e->flash = 2;
        if (A->capTimer >= 24) { A->capState = CAP_SHAKE; A->capTimer = 0; }
    } else if (A->capState == CAP_SHAKE) {
        int total = A->capShakes * 40 + 30;
        if (A->capTimer >= total) {
            if (A->capSuccessAt) {
                A->capState = CAP_SUCCESS; A->capTimer = 0;
                u8 ball = BALL_ITEMS[A->capBall];
                SetMonData(e->mon, MON_DATA_POKEBALL, &ball);
                WriteBack(e);
                GetSetPokedexFlag(e->nat, 3);
                char buf[32]; int n = 0;
                for (int i = 0; e->name[i] && n < 14; i++) buf[n++] = e->name[i];
                const char *tail = gPlayerPartyCount < 6 ? " WAS CAUGHT!" : " GOES TO THE PC!";
                for (int i = 0; tail[i]; i++) buf[n++] = tail[i];
                buf[n] = 0;
                Msg(A, buf, 90);
                A->outcome = 7; A->enemyWasCaught = 1;
                FxAdd(A, A->capX, A->capY, 3); FxAdd(A, A->capX + 10, A->capY - 6, 3); FxAdd(A, A->capX - 10, A->capY - 4, 3);
            } else {
                A->capState = CAP_BREAK; A->capTimer = 0;
                e->phase = PH_FREE; e->invuln = 30; e->flash = 20; e->stun = 20;
                PlayAnim(e, ANIM_WALK, 1);
                Msg(A, A->capShakes >= 3 ? "SO CLOSE! IT BROKE FREE!" : "OH NO! IT BROKE FREE!", 90);
                e->aiReact = 30;
            }
        }
    } else if (A->capState == CAP_SUCCESS) {
        if (A->capTimer == 1) A->state = ST_END, A->stateTimer = 0;
    } else if (A->capState == CAP_BREAK) {
        if (A->capTimer > 20) A->capState = CAP_NONE;
    }
}

// ---------- movement ----------
static int ActorSpeed(Actor *a) {
    int v = 190 + Eff(a, 2) * 2;
    if (v > 430) v = 430;
    if (!a->isPlayer && !LINKMODE) v = v * 80 / 100;
    return v;
}
static void MoveDir(Actor *a, int dx, int dy, int speed) {
    if (dx && dy) speed = speed * 181 / 256;
    a->x += dx * speed; a->y += dy * speed;
}

// ---------- AI ----------
static int AiPickMove(Arena *A, Actor *e, Actor *p) {
    int best = -1, bestScore = -1;
    for (int i = 0; i < 4; i++) {
        if (!e->moves[i] || e->cd[i]) continue;
        const u8 *m = MV(e->moves[i]);
        int pw = MV_POWER(m), eff = MV_EFFECT(m), score;
        if (pw > 1) {
            int em = TypeMult(MV_TYPE(m), p->type1, p->type2);
            score = pw * em / 10;
            if (MV_TYPE(m) == e->type1 || MV_TYPE(m) == e->type2) score = score * 3 / 2;
            if (em == 0) score = 0;
        } else if (pw == 1) score = 40;
        else {
            score = 20 + rnd(25);
            if ((eff == 32 || eff == 37) && e->hp < e->maxHp / 2) score = 150;
            else if (eff == 32 || eff == 37) score = 0;
            if ((eff == 1 || eff == 66 || eff == 33 || eff == 67) && p->status != S_NONE) score = 0;
            if (eff >= 10 && eff <= 16 && e->stage[eff - 10] >= 2) score = 0;
            if (eff >= 50 && eff <= 56 && e->stage[eff - 50] >= 2) score = 0;
            if (eff >= 18 && eff <= 24 && p->stage[eff - 18] <= -2) score = 0;
        }
        score += rnd(40);
        if (score > bestScore) { bestScore = score; best = i; }
    }
    return best;
}

static void AiStep(Arena *A, Actor *e, Actor *p) {
    e->moving = 0;
    if (e->phase != PH_FREE || !e->alive || e->stun || e->recharge) return;
    if (e->status == S_SLEEP || e->status == S_FREEZE || !p->alive) return;
    if (A->capState != CAP_NONE) return;
    if (e->aiReact) { e->aiReact--; return; }
    if (e->aiMove < 0 && e->aiTimer == 0) { e->aiMove = AiPickMove(A, e, p); e->aiTimer = 12 + rnd(30); }
    if (e->aiTimer) e->aiTimer--;
    int dist = DistBody(e, p), speed = ActorSpeed(e);
    s32 dx = BodyX(p) - BodyX(e), dy = BodyY(p) - BodyY(e);
    if (e->aiMove >= 0) {
        const u8 *m = MV(e->moves[e->aiMove]);
        int kind = MoveKind(m);
        int range = kind == K_MELEE ? 26 : (kind == K_SELF ? 9999 : (kind == K_SPREAD ? 50 : 96));
        if (kind == K_SELF || dist <= range) {
            if (kind != K_SELF) FaceToward(e, p);
            TryStartMove(A, e, e->aiMove);
            e->aiMove = -1; e->aiReact = 8 + rnd(20);
            return;
        }
        e->dir = DirFromVec(dx, dy); e->moving = 1;
        MoveDir(e, DIRX[e->dir], DIRY[e->dir], speed);
    } else {
        // nothing ready: keep distance and strafe
        if (dist < 44) {
            e->dir = DirFromVec(-dx, -dy); e->moving = 1;
            MoveDir(e, DIRX[e->dir], DIRY[e->dir], speed * 3 / 4);
        } else {
            if (!e->aiStrafeT) { e->aiStrafeT = 25 + rnd(40); e->aiStrafe = rnd(3) - 1; }
            e->aiStrafeT--;
            if (e->aiStrafe) {
                s32 sx = -dy * e->aiStrafe, sy = dx * e->aiStrafe;
                e->dir = DirFromVec(sx, sy); e->moving = 1;
                MoveDir(e, DIRX[e->dir], DIRY[e->dir], speed / 2);
            }
        }
        if (e->aiTimer == 0) e->aiMove = AiPickMove(A, e, p);
    }
}

// ---------- safari: the wild Pokemon wanders, eats bait, gets angry from rocks and may run away ----------
static void SafariAi(Arena *A, Actor *e, Actor *p) {
    e->moving = 0;
    if (!e->alive || e->phase != PH_FREE || A->state != ST_FIGHT) return;
    int speed = ActorSpeed(e);
    if (A->sfLeave) {
        e->dir = 2; e->moving = 1; MoveDir(e, 1, 0, speed * 2);
        if ((e->x >> 8) >= FIELD_W_MAX - 1) { A->outcome = 6; A->state = ST_END; A->stateTimer = 0; A->endPhase = 0; A->endSlot = 1; }
        return;
    }
    if (A->capState == CAP_FLY && 0) return;
    if (A->sfBait) A->sfBait--;
    if (A->sfAngry) A->sfAngry--;
    if (++A->sfTimer >= 120) {                      // flee roll every two seconds
        A->sfTimer = 0;
        int rate = gBaseStats[(u32)e->species * 28 + 24] / 4;
        if (A->sfAngry) rate *= 2;
        if (A->sfBait) rate /= 4;
        if (rate > 90) rate = 90;
        if (rnd(100) < rate) { A->sfLeave = 1; PopupAdd(A, BodyX(e) - 12, BodyY(e) - 22, "FLEES!", 7); return; }
    }
    if (A->sfBait) { FaceToward(e, p); return; }   // busy eating
    s32 dx = BodyX(e) - BodyX(p), dy = BodyY(e) - BodyY(p);
    int dist = DistBody(e, p);
    if (dist < 46 || A->sfAngry) {                  // keeps its distance (angry ones run around faster)
        e->dir = DirFromVec(dx, dy); e->moving = 1;
        MoveDir(e, DIRX[e->dir], DIRY[e->dir], A->sfAngry ? speed : speed * 3 / 4);
    } else {
        if (!A->sfDirT) { A->sfDirT = 25 + rnd(50); A->sfDir = rnd(10); }
        A->sfDirT--;
        if (A->sfDir < 8) { e->dir = A->sfDir; e->moving = 1; MoveDir(e, DIRX[e->dir], DIRY[e->dir], speed / 2); }
    }
}

// ---------- player input ----------
// mode 0: single (A/B/L/R = moves 1-4); 1: first of a pair (A, L); 2: second of a pair (B, R)
static void PlayerInput(Arena *A, Actor *a, int mode) {
    u16 held = gMain.heldKeys, nw = gMain.newKeys;
    a->moving = 0;
    if (mode != 2 && A->capState == CAP_NONE && (nw & KEY_START)) { UiOpen(A, UI_MENU, 0); return; }
    if (mode == 1 && (nw & KEY_SELECT)) { A->page ^= 1; Msg(A, A->page ? "MOVES 3 AND 4" : "MOVES 1 AND 2", 40); }
    if (a->phase != PH_FREE || !a->alive || a->stun || a->recharge) return;
    if (a->status == S_SLEEP || a->status == S_FREEZE) return;
    int dx = 0, dy = 0;
    if (held & KEY_LEFT) dx = -1; else if (held & KEY_RIGHT) dx = 1;
    if (held & KEY_UP) dy = -1; else if (held & KEY_DOWN) dy = 1;
    if (a->confTimer && (dx || dy)) {
        if (a->confDirTimer == 0) { a->confDirTimer = 20 + rnd(30); a->confDir = rnd(8); }
        else a->confDirTimer--;
        if (a->confDirTimer > 12) { dx = DIRX[(int)a->confDir]; dy = DIRY[(int)a->confDir]; }
    }
    if (dx || dy) {
        for (int d = 0; d < 8; d++) if (DIRX[d] == dx && DIRY[d] == dy) { a->dir = d; break; }
        a->moving = 1;
        MoveDir(a, dx, dy, ActorSpeed(a));
    }
    if (mode == 0 && A->safari) {
        if (nw & KEY_A) StartThrow(A, a, 4);
        else if (nw & KEY_B) StartThrow(A, a, 5);
        else if (nw & KEY_L) StartThrow(A, a, 6);
    } else if (mode == 0) {
        if (nw & KEY_A) TryStartMove(A, a, 0);
        else if (nw & KEY_B) TryStartMove(A, a, 1);
        else if (nw & KEY_L) TryStartMove(A, a, 2);
        else if (nw & KEY_R) TryStartMove(A, a, 3);
        else if (nw & KEY_SELECT) {
            if (A->isTrainer) Msg(A, "CAN'T CATCH A TRAINER'S POKEMON", 70);
            else if (!A->safari) StartThrow(A, a, 4);
        }
    } else {
        int base = A->page * 2;
        u16 k1 = mode == 1 ? KEY_A : KEY_B, k2 = mode == 1 ? KEY_L : KEY_R;
        if (nw & k1) TryStartMove(A, a, base);
        else if (nw & k2) TryStartMove(A, a, base + 1);
    }
}

// ---------- per-actor update ----------
static void SetAnimIf(Actor *a, int slot, int loop) {
    if (a->anim != slot) PlayAnim(a, slot, loop);
}

static void UpdateActor(Arena *A, Actor *a) {
    if (a->flash) a->flash--;
    if (a->invuln) a->invuln--;
    if (a->stun) a->stun--;
    if (a->recharge) a->recharge--;
    for (int i = 0; i < 4; i++) if (a->cd[i]) a->cd[i]--;
    if (a->reflect) a->reflect--;
    if (a->lscreen) a->lscreen--;
    if (a->confTimer) { a->confTimer--; if (!a->confTimer) PopupAdd(A, BodyX(a) - 12, BodyY(a) - 22, "SNAPPED", 3); }
    if (a->alive) {
        if (a->trapTimer) {
            a->trapTimer--;
            if (a->trapTimer % 60 == 0) {
                int d = a->maxHp / 16; if (d < 1) d = 1;
                a->hp -= d; PopupNum(A, BodyX(a) - 4, BodyY(a) - 20, d, 2);
                if (a->hp <= 0) Faint(A, a);
            }
        }
        switch (a->status) {
        case S_SLEEP: case S_FREEZE:
            if (a->statusTimer && --a->statusTimer == 0) {
                const char *w = a->status == S_SLEEP ? "WOKE" : "THAWED";
                a->status = S_NONE; PopupAdd(A, BodyX(a) - 12, BodyY(a) - 22, w, 6);
            }
            break;
        case S_POISON: case S_TOXIC: case S_BURN:
            if (++a->statusTick >= 90) {
                a->statusTick = 0;
                int d = a->maxHp / 16; if (d < 1) d = 1;
                a->hp -= d;
                PopupNum(A, BodyX(a) - 4, BodyY(a) - 20, d, 2);
                if (a->hp <= 0) Faint(A, a);
            }
            break;
        }
    }
    switch (a->phase) {
    case PH_ATTACK:
        AnimStep(a);
        if (!a->hitFired && a->aIdx >= a->hitIdx) {
            a->hitFired = 1;
            if (a->curSlot >= 4) {
                SpawnProj(A, a, FoeOf(A, a), a->curSlot - 3, 0, 700);     // 1 ball, 2 bait, 3 rock
                if (a->curSlot == 4) A->capState = CAP_FLY;
            } else FireMove(A, a);
        }
        if (a->animDone) { a->phase = PH_FREE; PlayAnim(a, ANIM_WALK, 1); }
        break;
    case PH_HURT:
        AnimStep(a);
        if (!a->stun) { a->phase = PH_FREE; PlayAnim(a, ANIM_WALK, 1); }
        break;
    case PH_FAINT:
        a->fainted++;
        break;
    case PH_CAPTURED:
        break;
    default:
        if (a->status == S_SLEEP || a->status == S_FREEZE) { SetAnimIf(a, ANIM_SLEEP, 1); AnimStep(a); }
        else {
            SetAnimIf(a, ANIM_WALK, 1);
            if (a->moving) AnimStep(a); else { a->aIdx = 0; a->aTick = 0; }
        }
        break;
    }
    // knockback
    a->x += a->kx; a->y += a->ky;
    a->kx = a->kx * 208 / 256; a->ky = a->ky * 208 / 256;
    int x0 = FIELD_W_MIN, x1 = FIELD_W_MAX, y0 = FIELD_H_MIN, y1 = FIELD_H_MAX;
    if (a->cols) {                      // big sprite: keep the whole picture below the top bar and on the screen
        int cw = a->cols * 64;
        if (y0 < 12 + a->oy) y0 = 12 + a->oy;
        if (y1 > 158 - (a->uh - a->oy)) y1 = 158 - (a->uh - a->oy);
        if (y1 < y0) y1 = y0;
        if (x0 < a->ox + 2) x0 = a->ox + 2;
        if (x1 > 238 - cw + a->ox) x1 = 238 - cw + a->ox;
        if (x1 < x0) x1 = x0;
    }
    a->x = clampi(a->x, x0 << 8, x1 << 8);
    a->y = clampi(a->y, y0 << 8, y1 << 8);
}

// big Pokemon (Rayquaza, Groudon, Kyogre, Lugia, Ho-Oh, Zapdos, Articuno...) keep a distance from every other fighter that
// depends on the size of their pictures; in doubles each side starts with its big ones far apart (one high, one low)
static int SepR(Actor *a) { return a->cols ? a->uh / 4 + a->cols * 6 : 6; }
static void SeparateActors(Arena *A) {
    if (A->dbl && A->frame == 2) {
        for (int i = 0; i < 2; i++) {
            Actor *u = &A->act[i], *v = &A->act[i + 2];
            if (!(A->pm & (1 << i)) || !(A->pm & (1 << (i + 2))) || !(u->cols || v->cols)) continue;
            u->y = 66 << 8; v->y = 126 << 8;
            if (i == 0) { u->x = 52 << 8; v->x = 92 << 8; } else { u->x = 188 << 8; v->x = 148 << 8; }
        }
    }
    for (int i = 0; i < 4; i++) for (int k = i + 1; k < 4; k++) {
        if (!(A->pm & (1 << i)) || !(A->pm & (1 << k))) continue;
        Actor *p = &A->act[i], *e = &A->act[k];
        if (!p->alive || !e->alive || e->phase == PH_CAPTURED || p->phase == PH_CAPTURED) continue;
        s32 dx = e->x - p->x, dy = e->y - p->y;
        s32 d = isqrt((dx >> 4) * (dx >> 4) + (dy >> 4) * (dy >> 4)) << 4;   // 8.8
        int sr = SepR(p) + SepR(e);
        s32 dmin = ((i & 1) != (k & 1) || sr < 12 ? 12 : sr) * 256;      // only fighters on the same side keep the size-based distance
        if (d < dmin) {
            if (!d) { dx = 256; dy = 0; d = 256; }
            s32 push = (dmin - d) / 4;
            e->x += dx * push / d; e->y += dy * push / d;
            p->x -= dx * push / d; p->y -= dy * push / d;
        }
    }
}

static void UpdateProjectiles(Arena *A) {
    for (int i = 0; i < 10; i++) {
        Proj *p = &A->proj[i];
        if (!p->active) continue;
        p->x += p->vx; p->y += p->vy;
        int px = p->x >> 8, py = p->y >> 8;
        if (p->life) p->life--;
        if (!p->life || px < 10 || px > 230 || py < 40 || py > 140) {
            p->active = 0;
            if (p->kind == 1 && A->capState == CAP_FLY) A->capState = CAP_NONE;
            continue;
        }
        int hit = 0;
        for (int k = 0; k < 4 && !hit; k++) {
            if ((k & 1) == (p->owner & 1) || !(A->pm & (1 << k))) continue;
            Actor *t = &A->act[k];
            if (!t->alive || t->invuln || t->phase == PH_CAPTURED) continue;
            int dx = BodyX(t) - px, dy = BodyY(t) - py;
            if (iabs(dx) < 12 && iabs(dy) < 14) {
                hit = 1;
                p->active = 0;
                if (p->kind == 1) {
                    BeginCapture(A, A->ballSel);
                } else if (p->kind >= 2) {
                    if (p->kind == 2) { A->sfBait = 360 + rnd(300); A->sfAngry = 0; PopupAdd(A, BodyX(t) - 14, BodyY(t) - 22, "EATING", 6); }
                    else { A->sfAngry = 360 + rnd(300); A->sfBait = 0; t->flash = 20; PopupAdd(A, BodyX(t) - 14, BodyY(t) - 22, "ANGRY!", 7); }
                    A->sfTimer = 0;
                    FxAdd(A, px, py, 0);
                } else {
                    ResolveHit(A, &A->act[p->owner], t, p->move);
                    FxAdd(A, px, py, 0);
                    if (p->move == 91) FxAdd(A, BodyX(t), BodyY(t), 6);         // Dig: the crater opens under the target
                }
            }
        }
    }
}

static void UpdateAging(Arena *A) {
    if ((A->frame & 63) == 0) for (int i = 0; i < NTB; i++) if (A->typeBankAge[i] < 255) A->typeBankAge[i]++;
    for (int i = 0; i < 8; i++) {
        Popup *p = &A->pop[i];
        if (p->timer) { p->timer--; if (p->timer & 1) p->y--; }
        Fx *f = &A->fx[i];
        if (f->active) { f->timer++; if (f->timer > (f->kind == 7 ? 120 : f->kind == 6 ? 44 : 16)) f->active = 0; }
    }
    if (A->msgTimer) { A->msgTimer--; if (!A->msgTimer) A->msg[0] = 0; }
    if (A->ballCd) A->ballCd--;
}
