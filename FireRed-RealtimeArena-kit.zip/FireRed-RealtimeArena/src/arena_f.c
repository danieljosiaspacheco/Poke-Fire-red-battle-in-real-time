// ---------- overworld extras drawn by injecting OAM entries after BuildOamBuffer() ----------
//  * follower: the first party Pokemon walks behind the player
//  * wild Pokemon: visible, wandering wild Pokemon replace the random grass/cave/surf encounters; touching one
//    starts the real-time wild battle with that very Pokemon
// A ROM veneer calls FollowerEntry() once per frame right after BuildOamBuffer() in the field main loop.
// Graphics: 32x32 walking frames from the follower pack (ROM 0x09E00000).  OBJ tiles near the end of OBJ VRAM and
// free OBJ palettes (not used by any game sprite) are used; persistent state lives in OBJ tiles (VRAM is only
// accessed 16 bit at a time and is cleared by the game on every map load, which resets everything).

#define FOLLOW_PACK   ((const u8 *)0x09E00000)
#define FW_SPRITES    ((volatile u8 *)0x0202063C)
#define FW_OBJEVENTS  ((volatile u8 *)0x02036E38)
#define FW_AVATAR     ((volatile u8 *)0x02037078)
#define FW_OAM        ((volatile u16 *)0x03003128)
#define FW_PAL_UNF(s) ((volatile u16 *)(0x020371F8 + 0x200 + (s) * 32))
#define FW_PAL_FAD(s) ((volatile u16 *)(0x020375F8 + 0x200 + (s) * 32))
#define FW_TILE0      960                                             // tiles 960..1023: 64x64 follower sprite (or the first 16 for 32x32)
#define FW_STATE      ((volatile u16 *)(0x06010000 + 959 * 32))
#define FW_VRAM       ((volatile u32 *)(0x06010000 + FW_TILE0 * 32))
#define FW_MAGIC      0xF011

#define WILD_STATE    ((volatile u16 *)(0x06010000 + 955 * 32))      // tiles 955..958
#define WILD_TILE(i)  (699 + 64 * (i))                                // tiles 699..954, 64 per wild Pokemon
#define WILD_VRAM(i)  ((volatile u32 *)(0x06010000 + WILD_TILE(i) * 32))
#define WILD_MAGIC    0xA1D5
#define NWILD         4

enum { FS_MAGIC, FS_X, FS_Y, FS_V1, FS_V2, FS_SPECIES, FS_MAP, FS_ANIM, FS_FACE, FS_LOADED, FS_PALOK, FS_V3, FS_PAR, FS_BX, FS_BY, FS_STILL };
enum { W_SP, W_LV, W_X, W_Y, W_FACE, W_STEP, W_PROG, W_TIMER, W_AGE, W_LOADED };

typedef struct {
    u16 a0, a1, a2;
    int px, py, x2, y2, cx, cy, sx, sy;
    volatile u8 *oe;
    u8 fl;
} FwCtx;

static s8 FwLo(u16 v) { return (s8)(v & 0xFF); }
static s8 FwHi(u16 v) { return (s8)(v >> 8); }
static u16 FwPack(int x, int y) { return (u16)((x & 0xFF) | ((y & 0xFF) << 8)); }
static int FwAbs(int v) { return v < 0 ? -v : v; }

static u32 FwUsedPals(void) {
    u32 m = 0;
    for (int i = 0; i < 64; i++) {
        volatile u8 *s = FW_SPRITES + 0x44 * i;
        if (s[0x3E] & 1) m |= 1u << (*(volatile u16 *)(s + 4) >> 12);
    }
    return m;
}

static void FwSetPal(int slot, const u16 *pal) {
    volatile u16 *u = FW_PAL_UNF(slot), *f = FW_PAL_FAD(slot);
    int same = 1;
    for (int i = 1; i < 16; i++) if (u[i] != pal[i]) { same = 0; break; }
    if (!same) for (int i = 0; i < 16; i++) { u[i] = pal[i]; f[i] = pal[i]; }
}

static const u8 *FwRec(u16 species) {
    u16 nat = SpeciesToNationalPokedexNum(species);
    if (nat == 0 || nat >= 512) return 0;
    u32 roff = ((const u32 *)FOLLOW_PACK)[nat];
    return roff ? FOLLOW_PACK + roff : 0;
}

// walk animation of the species (the same frame sequence and timing the arena plays): record + 64 + dir * 17 =
// u8 count, 8 x {u8 frame, u8 ticks}; returns the frame id to show after t ticks of walking (t = 0: first frame)
static int FwAnimFrame(const u8 *rec, int dir, int t) {
    const u8 *an = rec + 64 + dir * 17;
    int cnt = an[0], total = 0;
    if (!cnt) return 0;
    for (int i = 0; i < cnt; i++) total += an[2 + i * 2] ? an[2 + i * 2] : 1;
    t %= total;
    for (int i = 0; i < cnt; i++) {
        int tk = an[2 + i * 2] ? an[2 + i * 2] : 1;
        if (t < tk) return an[1 + i * 2];
        t -= tk;
    }
    return an[1];
}

extern void LZ77UnCompVram(const void *src, void *dst);
static int FwCls(const u8 *rec) { return rec[115] ? 1 : 0; }        // 0: 32x32 frames, 1: 64x64 frames (large species, original size)
static void FwUpload(const u8 *rec, int frame, volatile u32 *dst) {
    LZ77UnCompVram(rec + ((const u16 *)(rec + 32))[frame], (void *)dst);
}

// insert one 32x32 (cls 0) or 64x64 (cls 1) sprite into the OAM buffer, in front of or behind the player's own entry;
// fx, fy are the top-left corner of a 32x32 sprite standing on the same tile (the 64x64 one is centred and feet-aligned)
static void FwInsert(FwCtx *c, int fx, int fy, int tile, int pal, int hflip, int cls, int fol) {
    int hh = 32;
    if (cls) { fx -= 16; fy -= 32; hh = 64; }
    if (fx < -64 || fx > 240 || fy < -64 || fy > 160) return;
    int n = 0;
    while (n < 127 && !((FW_OAM[n * 4] & 0xFF) == 160 && (FW_OAM[n * 4 + 1] & 0x1FF) == 304)) n++;   // unused entries are parked at y=160, x=304
    if (n >= 127) return;
    int p = -1;
    for (int i = 0; i < n; i++)
        if (FW_OAM[i * 4] == c->a0 && FW_OAM[i * 4 + 1] == c->a1 && FW_OAM[i * 4 + 2] == c->a2) { p = i; break; }
    if (p < 0) return;
    int idx = (fy + hh > c->py + 32 && !(fol && cls)) ? p : p + 1;       // a large follower stays behind the player so it never hides him
    for (int i = n; i > idx; i--) for (int k = 0; k < 3; k++) FW_OAM[i * 4 + k] = FW_OAM[(i - 1) * 4 + k];   // word 3 holds the affine matrices (reflections, surf blob...): they belong to the slot, never move them
    FW_OAM[idx * 4 + 0] = (fy & 0xFF);
    FW_OAM[idx * 4 + 1] = (fx & 0x1FF) | ((cls ? 3 : 2) << 14) | (hflip ? 0x1000 : 0);
    FW_OAM[idx * 4 + 2] = tile | (c->a2 & 0x0C00) | (pal << 12);
}

// ---------------------------------------------------------------- follower
static void FollowerStep(FwCtx *c, int slot) {
    volatile u16 *st = FW_STATE;
    int ok = !((c->fl & 0x1E) || !(c->fl & 1));              // surfing, biking, underwater: no follower (tracking goes on)
    struct Pokemon *mon = &gPlayerParty[0];
    u16 species = GetMonData(mon, MON_DATA_SPECIES, 0);
    if (!species || GetMonData(mon, MON_DATA_SANITY_IS_EGG, 0)) ok = 0;
    const u8 *rec = ok ? FwRec(species) : 0;
    if (!rec) ok = 0;

    int cx = c->cx, cy = c->cy;
    u16 mapid = (u16)((c->oe[10] << 8) | c->oe[9]);
    if (st[FS_MAGIC] != FW_MAGIC || st[FS_MAP] != mapid) {
        st[FS_MAGIC] = FW_MAGIC; st[FS_MAP] = mapid; st[FS_X] = cx; st[FS_Y] = cy;
        st[FS_V1] = 0; st[FS_V2] = 0; st[FS_V3] = 0; st[FS_PAR] = 0; st[FS_ANIM] = 0; st[FS_FACE] = 0; st[FS_LOADED] = 0xFFFF;
        st[FS_SPECIES] = 0; st[FS_PALOK] = 0; st[FS_STILL] = 0;
        st[FS_BX] = (u16)(c->sx - 16 * cx); st[FS_BY] = (u16)(c->sy - 16 * cy);       // the player arrives standing still
    } else if (cx != (s16)st[FS_X] || cy != (s16)st[FS_Y]) {
        int dx = cx - (s16)st[FS_X], dy = cy - (s16)st[FS_Y];
        if (FwAbs(dx) + FwAbs(dy) == 1) { st[FS_V3] = st[FS_V2]; st[FS_V2] = st[FS_V1]; st[FS_V1] = FwPack(dx, dy); st[FS_PAR] ^= 1; }
        else { st[FS_V1] = 0; st[FS_V2] = 0; st[FS_V3] = 0; }
        st[FS_X] = cx; st[FS_Y] = cy; st[FS_STILL] = 0;
    } else if (st[FS_STILL] < 30) {
        if (++st[FS_STILL] == 30) { st[FS_BX] = (u16)(c->sx - 16 * cx); st[FS_BY] = (u16)(c->sy - 16 * cy); }   // at rest: learn the map's sprite origin
    }
    c->x2 = c->sx - 16 * cx - (s16)st[FS_BX]; c->y2 = c->sy - 16 * cy - (s16)st[FS_BY];
    if (FwAbs(c->x2) > 16 || FwAbs(c->y2) > 16) { c->x2 = 0; c->y2 = 0; }
    if (!ok || !st[FS_V1]) return;                                   // no path yet (just arrived): stay hidden until the first step
    int v1x = FwLo(st[FS_V1]), v1y = FwHi(st[FS_V1]);
    int v2x = FwLo(st[FS_V2]), v2y = FwHi(st[FS_V2]);
    if (st[FS_SPECIES] != species) { st[FS_SPECIES] = species; st[FS_LOADED] = 0xFFFF; }
    FwSetPal(slot, (const u16 *)rec);

    int R = FwAbs(c->x2) + FwAbs(c->y2);
    int fx = c->px - 8 - c->x2 - 22 * v1x - R * v2x;                 // about 1.4 tiles behind the player
    int fy = c->py - c->y2 - 22 * v1y - R * v2y;

    int dx = v2x | v2y ? v2x : v1x, dy = v2x | v2y ? v2y : v1y;
    int face = st[FS_FACE];
    if (dy > 0) face = 0; else if (dy < 0) face = 1; else if (dx < 0) face = 2; else if (dx > 0) face = 3;
    st[FS_FACE] = face;
    // the walk animation of the species (same frames/timing as in the arena) plays while the player is moving
    if (R) st[FS_PAR] = 0; else if (st[FS_PAR] < 4) st[FS_PAR]++;       // R is 0 for a frame between two steps of a walk
    if (st[FS_PAR] < 4) st[FS_ANIM]++; else st[FS_ANIM] = 0;
    int want = FwAnimFrame(rec, face == 3 ? 2 : face, st[FS_ANIM]);
    if (st[FS_LOADED] != want) { FwUpload(rec, want, FW_VRAM); st[FS_LOADED] = want; }
    if (FwCls(rec)) { fx -= 14 * v1x; fy -= 14 * v1y; }                 // a large follower keeps a little more distance so it does not smother the player
    FwInsert(c, fx, fy, FW_TILE0, slot, face == 3, FwCls(rec), 1);
}

// ---------------------------------------------------------------- visible wild Pokemon
static const s8 WDIR[4][2] = {{0, 1}, {0, -1}, {-1, 0}, {1, 0}};    // S, N, W, E

static int WildTileKind(int x, int y) {                              // 1 = land encounter tile, 2 = water encounter tile
#ifdef WILD_TEST
    return 1;                                                         // test build only: every tile counts as grass
#endif
    return ((u8 (*)(s16, s16, u8))0x08058F49)((s16)x, (s16)y, 4);
}

static int WildTaken(volatile u16 *ws, int self, int x, int y) {
    for (int j = 0; j < NWILD; j++) {
        if (j == self) continue;
        volatile u16 *m = ws + 8 + j * 10;
        if (!m[W_SP]) continue;
        if ((s16)m[W_X] == x && (s16)m[W_Y] == y) return 1;
        if (m[W_PROG] && (s16)m[W_X] + FwLo(m[W_STEP]) == x && (s16)m[W_Y] + FwHi(m[W_STEP]) == y) return 1;
    }
    return 0;
}

// Repel / Super Repel / Max Repel: while the step counter (VAR_REPEL_STEP_COUNT, 0x4020) is running, wild Pokemon whose level is not
// higher than the first healthy party member neither appear on the map nor start a battle
static int RepelOn(int lv) {
    if (!((u16 (*)(u16))0x0806E569)(0x4020)) return 0;
    for (int i = 0; i < 6 && i < gPlayerPartyCount; i++) {
        if (GetMonData(&gPlayerParty[i], MON_DATA_SANITY_IS_EGG, 0)) continue;
        if (GetMonData(&gPlayerParty[i], MON_DATA_HP, 0)) return lv <= (int)GetMonData(&gPlayerParty[i], MON_DATA_LEVEL, 0);
    }
    return 0;
}

static void WildBattle(int species, int level) {
    *(volatile u8 *)0x0203F7FC = 1;                                    // this wild Pokemon was already chosen (randomised or not) on the map
    CreateMon(&gEnemyParty[0], species, level, 32, 0, 0, 0, 0);
    for (int i = 1; i < 6; i++) { u8 *q = (u8 *)&gEnemyParty[i]; for (int k = 0; k < 100; k++) q[k] = 0; }
    BattleSetup_StartWildBattle();
}

static void WildStep(FwCtx *c, const u8 *slots, int nslots) {
    volatile u16 *ws = WILD_STATE;
    int mode = (c->fl & 8) ? 2 : 1;                                   // surfing -> water Pokemon
    if (c->fl & 0x10) return;                                         // underwater
    u16 mapid = (u16)((c->oe[10] << 8) | c->oe[9]);
    if (ws[0] != WILD_MAGIC || ws[1] != mapid || ws[3] != mode) {
        for (int i = 0; i < 64; i++) ws[i] = 0;
        ws[0] = WILD_MAGIC; ws[1] = mapid; ws[3] = mode; ws[2] = 60;
    }
    u16 hid = ((u16 (*)(void))0x08082935)();
#ifdef WILD_TEST
    hid = 87;                                                         // test build only: Route 1 table
#endif
    if (hid == 0xFFFF) return;
    const u32 *hdr = (const u32 *)(0x083C9CB8 + hid * 20);
    const u8 *info = (const u8 *)hdr[mode == 2 ? 2 : 1];
    if (!info) return;
    const u8 *mons = *(const u8 *const *)(info + 4);
    int cx = c->cx, cy = c->cy;
    int fx0 = cx - FwLo(FW_STATE[FS_V1]), fy0 = cy - FwHi(FW_STATE[FS_V1]);     // the follower's tile

    int count = 0;
    for (int i = 0; i < NWILD; i++) if (ws[8 + i * 10 + W_SP]) count++;
    // ----- spawn -----
    if (ws[2]) ws[2]--;
    else if (count < NWILD && count < nslots && gPlayerPartyCount && !ws[4]) {
        ws[2] = 40 + Random() % 100;
        for (int t = 0; t < 10; t++) {
            int dx = (int)(Random() % 15) - 7, dy = (int)(Random() % 9) - 4;
            if (FwAbs(dx) < 3 && FwAbs(dy) < 3) continue;
            int tx = cx + dx, ty = cy + dy;
            if (WildTileKind(tx, ty) != mode) continue;
            if ((tx == fx0 && ty == fy0) || WildTaken(ws, -1, tx, ty)) continue;
            static const u8 landThr[12] = {20, 40, 50, 60, 70, 80, 85, 90, 94, 98, 99, 100};
            static const u8 waterThr[5] = {60, 90, 95, 99, 100};
            int r = Random() % 100, k = 0, nk = mode == 2 ? 5 : 12;
            const u8 *thr = mode == 2 ? waterThr : landThr;
            while (k < nk - 1 && r >= thr[k]) k++;
            const u8 *w = mons + k * 4;
            int lo = w[0], hi = w[1];
            for (int j = 0; j < NWILD; j++) {
                volatile u16 *m = ws + 8 + j * 10;
                if (m[W_SP]) continue;
                m[W_SP] = *(const u16 *)(w + 2);
                if (CheatOn(1)) {                                           // any of the 386 species, legendaries and other regions included
                    u16 nat = 1 + Random() % 386;
                    for (u16 sp = 1; sp < 412; sp++) if (SpeciesToNationalPokedexNum(sp) == nat) { m[W_SP] = sp; break; }
                }
#ifdef WILD_TEST
                if (*(volatile u16 *)0x0203F004) m[W_SP] = *(volatile u16 *)0x0203F004;
#endif
                {   // large species (64x64 on the map): only one at a time, so they do not pile up on each other and the player
                    const u8 *nr = FwRec(m[W_SP]);
                    if (nr && FwCls(nr)) {
                        int other = 0;
                        for (int q = 0; q < NWILD; q++) {
                            volatile u16 *o = ws + 8 + q * 10;
                            if (o != m && o[W_SP]) { const u8 *orr = FwRec(o[W_SP]); if (orr && FwCls(orr)) other = 1; }
                        }
                        if (other) { m[W_SP] = 0; continue; }
                    }
                }
                m[W_LV] = lo + (hi > lo ? Random() % (hi - lo + 1) : 0);
                if (RepelOn(m[W_LV])) { m[W_SP] = 0; break; }
                m[W_X] = tx; m[W_Y] = ty; m[W_FACE] = Random() & 3; m[W_STEP] = 0; m[W_PROG] = 0;
                m[W_TIMER] = 20 + Random() % 60; m[W_AGE] = 0; m[W_LOADED] = 0xFFFF;
                break;
            }
            break;
        }
    }
    // ----- update + draw -----
    int controllable = FieldFree();
    for (int i = 0; i < NWILD; i++) {
        volatile u16 *m = ws + 8 + i * 10;
        if (!m[W_SP]) continue;
        int x = (s16)m[W_X], y = (s16)m[W_Y];
        if (m[W_AGE] < 60000) m[W_AGE]++;
        if (FwAbs(x - cx) > 11 || FwAbs(y - cy) > 8 || m[W_AGE] > 3600) { m[W_SP] = 0; continue; }
        if (m[W_PROG]) {
            m[W_PROG]++;
            if (m[W_PROG] > 32) {
                m[W_X] = x += FwLo(m[W_STEP]); m[W_Y] = y += FwHi(m[W_STEP]);
                m[W_PROG] = 0; m[W_TIMER] = 20 + Random() % 80;
            }
        } else if (m[W_TIMER]) m[W_TIMER]--;
        else {
            int d = Random() & 3;
            int tx = x + WDIR[d][0], ty = y + WDIR[d][1];
            m[W_FACE] = d; m[W_TIMER] = 12;
            if (WildTileKind(tx, ty) == mode && !(tx == cx && ty == cy) && !(tx == fx0 && ty == fy0) && !WildTaken(ws, i, tx, ty)) {
                m[W_STEP] = FwPack(WDIR[d][0], WDIR[d][1]); m[W_PROG] = 1;
            }
        }
        // touching the player starts the battle
        int mx = x, my = y;
        if (m[W_PROG]) { mx += FwLo(m[W_STEP]); my += FwHi(m[W_STEP]); }
        int reach = 1;
        { const u8 *tr = FwRec(m[W_SP]); if (tr && FwCls(tr)) reach = 2; }   // a large body touches from a tile further away
        if (!ws[4] && controllable && m[W_AGE] > 50 && !RepelOn(m[W_LV]) &&
            (FwAbs(x - cx) + FwAbs(y - cy) <= reach || FwAbs(mx - cx) + FwAbs(my - cy) <= reach)) {
            ws[4] = 1;
            WildBattle(m[W_SP], m[W_LV]);
            return;
        }
        // draw
        if (i + 1 >= nslots) continue;
        const u8 *rec = FwRec(m[W_SP]);
        if (!rec) continue;
        int slot = slots[i + 1];
        FwSetPal(slot, (const u16 *)rec);
        int face = m[W_FACE] & 3;
        int want = FwAnimFrame(rec, face == 3 ? 2 : face, m[W_PROG]);
        if (m[W_LOADED] != want) { FwUpload(rec, want, WILD_VRAM(i)); m[W_LOADED] = want; }
        if (m[W_AGE] < 30 && (m[W_AGE] & 2)) continue;                // blink in
        int off = m[W_PROG] >> 1;
        int fx = c->px - 8 - c->x2 + (x - cx) * 16 + FwLo(m[W_STEP]) * off;
        int fy = c->py - c->y2 + (y - cy) * 16 + FwHi(m[W_STEP]) * off;
        if (!m[W_PROG]) { fx = c->px - 8 - c->x2 + (x - cx) * 16; fy = c->py - c->y2 + (y - cy) * 16; }
        FwInsert(c, fx, fy, WILD_TILE(i), slot, face == 3, FwCls(rec), 0);
    }
}


// ---- Fly and Flash without a Pokemon that knows them -----------------------------------------------------------
// Fly: press R outdoors with the Thunder Badge -> the Fly map opens (a failed start returns through the party menu).
// Flash: entering a dark cave with the Boulder Badge asks once whether to use Flash (the cave then lights up).
static const u8 FlashTxt1[] = { 0xCE, 0xDC, 0xDD, 0xE7, 0x00, 0xD7, 0xD5, 0xEA, 0xD9, 0x00, 0xDD, 0xE7, 0x00, 0xD8, 0xD5, 0xE6, 0xDF, 0xAD, 0xFE, 0xCF, 0xE7, 0xD9, 0x00, 0xC0, 0xC6, 0xBB, 0xCD, 0xC2, 0xAC, 0xFF };
static const u8 FlashTxt2[] = { 0xC0, 0xC6, 0xBB, 0xCD, 0xC2, 0x00, 0xE0, 0xDD, 0xE8, 0x00, 0xE9, 0xE4, 0x00, 0xE8, 0xDC, 0xD9, 0x00, 0xD7, 0xD5, 0xEA, 0xD9, 0xAB, 0xFF };
#define FLASH_SCRIPT 0x081BFB5Fu          // the game's own "animate flash, set flash level, end" script
struct __attribute__((packed)) FlashAskScript {
    u8 lockall;
    u8 ld0; u8 ld0i; u32 ld0p;           // loadword 0, text1
    u8 cs; u8 csn;                        // callstd 5 (yes / no)
    u8 cmp; u16 cv; u16 cval;             // compare VAR_RESULT, 0
    u8 gi; u8 gic; u32 gip;               // goto_if eq, no
    u8 sf; u16 sfn;                       // setflag 0x806
    u8 ld1; u8 ld1i; u32 ld1p;            // loadword 0, text2
    u8 cs2; u8 cs2n;                      // callstd 4
    u8 rel; u8 go; u32 gop;               // releaseall; goto flash script
    u8 no_rel; u8 no_end;                 // no: releaseall; end
};
extern const struct FlashAskScript FlashAsk;
const struct FlashAskScript FlashAsk = {
    0x69, 0x0F, 0, (u32)FlashTxt1, 0x09, 5, 0x21, 0x800D, 0, 0x06, 1, (u32)&FlashAsk + __builtin_offsetof(struct FlashAskScript, no_rel),
    0x29, 0x806, 0x0F, 0, (u32)FlashTxt2, 0x09, 4, 0x6B, 0x05, FLASH_SCRIPT, 0x6B, 0x02
};

void FieldMoves(void) {
    volatile u16 *st = (volatile u16 *)0x0203F800;                      // st[0] map, st[1] ask/delay, st[2] magic
    if (st[2] != 0xA55A) { st[0] = 0xFFFF; st[1] = 0; st[2] = 0xA55A; st[3] = 0xFFFF; }
    *(volatile u8 *)0x03005ECC = 0;                                      // HELP system off: R opens Fly instead
    u16 held = *(volatile u16 *)(0x030030F0 + 0x2C);                    // own edge detection: R pressed now, not before
    u16 newKeys = (held & ~st[3]) & 0x100;
    st[3] = held;
    if (*(volatile u32 *)0x030030F4 != 0x080565B5u) return;            // CB2_Overworld only
    if (*(volatile u8 *)0x03000F9C) return;                             // player controls locked (menu, script)
    if (((u8 (*)(void))0x08069A65)()) return;                           // a script is running
    volatile u8 *sb1 = *(volatile u8 *volatile *)0x03005008;
    if (!sb1) return;
    {   // event islands: Birth Island (Aurora Ticket) and Navel Rock (Mystic Ticket): tickets + the same flags the Mystery Event scripts set
        u8 (*FlagGetE)(u16) = (u8 (*)(u16))0x0806E6D1;
        void (*FlagSetE)(u16) = (void (*)(u16))0x0806E681;
        u8 (*HasItem)(u16, u16) = (u8 (*)(u16, u16))0x08099F41;
        u8 (*AddItem)(u16, u16) = (u8 (*)(u16, u16))0x0809A085;
        if (!FlagGetE(0x2A8)) {                                           // Mystic Ticket (Navel Rock): flags 0x2A8 received, 0x84A ship enabled
            if (!HasItem(370, 1)) AddItem(370, 1);
            FlagSetE(0x2A8); FlagSetE(0x84A);
        }
        if (!FlagGetE(0x2A7)) {                                           // Aurora Ticket (Birth Island): flags 0x2A7 received, 0x84B ship enabled
            if (!HasItem(371, 1)) AddItem(371, 1);
            FlagSetE(0x2A7); FlagSetE(0x84B);
        }
    }
    u16 map = (u16)(sb1[4] << 8 | sb1[5]);
    if (map != st[0]) { st[0] = map; st[1] = 40; }                     // low byte: delay, high byte: asked
    if (st[1] & 0xFF) { st[1]--; return; }
    u8 (*FlagGetF)(u16) = (u8 (*)(u16))0x0806E6D1;
    volatile u8 *hdr = (volatile u8 *)0x02036DFC;
    if ((newKeys & 0x100) && FlagGetF(0x822) && ((u8 (*)(u8))0x080561FD)(hdr[0x17])) {
        *(volatile u32 *)0x020386E0 = 0;                                // party slot 0 shows the Fly animation
        *(volatile u32 *)0x030030F4 = 0x080C4EF9u;                      // CB2_OpenFlyMap
        return;
    }
    if (!(st[1] & 0x100) && hdr[0x15] == 1 && sb1[0x30] && FlagGetF(0x820) && !FlagGetF(0x806)) {
        st[1] |= 0x100;
        ((void (*)(const void *))0x08069AE5)(&FlashAsk);                // ScriptContext1_SetupScript
    }
}

void FollowerEntry(void) {
    FwCtx c;
    FieldMoves();
    {   // the National Pokedex is available from the start (EnableNationalPokedex: var 0x403C, magic byte, flag 0x838)
        volatile u8 *sb1 = *(volatile u8 *volatile *)0x03005008;
        if (sb1 && !(sb1[0xEE0 + (0x838 >> 3)] & 1)) ((void (*)(void))0x0806E191)();
    }
    c.fl = FW_AVATAR[0];
    if (c.fl & 0x10) return;                                  // underwater
    volatile u8 *oe = FW_OBJEVENTS + 0x24 * FW_AVATAR[5];
    if (!(oe[0] & 1)) return;
    volatile u8 *sp = FW_SPRITES + 0x44 * oe[4];
    if (!(sp[0x3E] & 1) || (sp[0x3E] & 4)) return;           // player sprite not in use / invisible
    c.oe = oe;
    volatile u16 *so = (volatile u16 *)sp;
    c.a0 = so[0]; c.a1 = so[1]; c.a2 = so[2];
    c.px = c.a1 & 0x1FF; if (c.px >= 256) c.px -= 512;
    c.py = c.a0 & 0xFF;
    c.cx = *(volatile s16 *)(oe + 0x10); c.cy = *(volatile s16 *)(oe + 0x12);
    // the game moves the player by sprite->x/y (the camera follows): offset of the drawn player from its tile
    c.sx = *(volatile s16 *)(sp + 0x20) + *(volatile s16 *)(sp + 0x24);       // world position of the player sprite
    c.sy = *(volatile s16 *)(sp + 0x22) + *(volatile s16 *)(sp + 0x26);
    c.x2 = 0; c.y2 = 0;
    // OBJ palettes not used by any game sprite, from the top: follower first, then the wild Pokemon
    u32 used = FwUsedPals();
    u8 slots[16]; int ns = 0;
    for (int s = 15; s >= 0 && ns < 6; s--) if (!(used & (1u << s))) slots[ns++] = s;
    if (ns) FollowerStep(&c, slots[0]);
    WildStep(&c, slots, ns);
}
