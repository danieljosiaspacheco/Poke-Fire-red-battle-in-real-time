#!/bin/bash
# build.sh [debug] -> build/arena.bin (+ build/arena.sym)
set -e
cd "$(dirname "$0")"
OUT=build; mkdir -p $OUT
DBG="$EXTRA"; [ "$1" = "debug" ] && DBG="-DARENA_DEBUG" && OUT=build_debug && mkdir -p $OUT
CF="--target=thumbv4t-none-eabi -mthumb -mcpu=arm7tdmi -Os -ffreestanding -fno-builtin -mlong-calls -fno-unwind-tables -fno-asynchronous-unwind-tables -fno-stack-protector -fno-pic -Wall -Wno-unused-function -Wno-unused-variable -Isrc $DBG"
clang $CF -c src/arena.c -o $OUT/arena.o
clang $CF -c src/rt.c -o $OUT/rt.o
clang $CF -c src/div.S -o $OUT/div.o
ld.lld -T src/arena.ld -Lsrc --no-rosegment -o $OUT/arena.elf $OUT/arena.o $OUT/rt.o $OUT/div.o
llvm-objcopy -O binary $OUT/arena.elf $OUT/arena.bin
llvm-nm $OUT/arena.elf | grep -E " T (ArenaEntry|ArenaDebugEntry|DebugStartWild|DebugCandy|LinkTest|LinkScreenInit|EvoAskMain|LinkKeyGuard)$" > $OUT/arena.sym
ls -la $OUT/arena.bin; cat $OUT/arena.sym
