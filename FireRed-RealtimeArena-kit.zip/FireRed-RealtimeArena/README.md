# Pokémon FireRed — Arena em tempo real (protótipo)

Transforma as **batalhas selvagens** do FireRed (USA 1.0) em combates em tempo real numa arena,
com sprites e animações (andar, atacar, tomar dano) tirados do **Pokémon Mystery Dungeon: Red Rescue Team**,
e captura "enfraquece e joga a bola".

Este pacote NÃO contém dados da Nintendo. Você gera a ROM com as suas próprias cópias.

## Como gerar a ROM

Requisitos: Python 3.8+ (só biblioteca padrão).

    python3 tools/make_rom.py FireRed.gba PMD_RedRescueTeam.gba FireRed_Arena.gba

* FireRed: **USA, revisão 0 (v1.0)**, md5 `e26ee0d44e809351c8ce2d73c7400cdd` (o script confere).
* PMD: Red Rescue Team (USA/Australia). Leva ~1 min (extrai e comprime ~21 mil quadros de sprites).
* `--species 1-151` gera um pacote de sprites menor/mais rápido (espécies fora da lista usam a batalha original).
* Para reaproveitar pacotes já gerados: `make_rom.py FireRed.gba --sprites build/sprites.bin --follow build/follow.bin saida.gba` (o `follow.bin` vem de `tools/pack_follow.py PMD.gba x build/follow.bin FireRed.gba`; o `sprites.bin` de `tools/pack_sprites.py PMD.gba build/sprites.bin 1,2,...,386 FireRed.gba`; o último argumento, a ROM do FireRed, é usado para o Zangoose de duas pernas).
* A ROM final tem 32 MB; saves do jogo original continuam compatíveis.

`build/arena.bin` já vem compilado. Para recompilar o código (clang + lld, alvo thumbv4t): `./build.sh`.

## Controles na arena

| Botão | Ação |
|---|---|
| D-pad | mover (8 direções) |
| A / B / L / R | **batalha simples:** golpe do slot 1 / 2 / 3 / 4 (consome PP, tem recarga) |
| SELECT | simples: jogar a Poké Ball (só contra selvagens) · dupla: alterna golpes 1-2 / 3-4 |
| START | menu de pausa: continuar, **trocar de Pokémon** (na dupla: "SWITCH 1ST/2ND"), escolher a bola, **BAG**, fugir |

**Batalhas em dupla** (treinadores): você controla os dois Pokémon ao mesmo tempo.
**A e L** = golpes do 1º Pokémon, **B e R** = golpes do 2º. O D-pad move os dois juntos.
Quando um da dupla desmaia abre a tela de troca para entrar outro; o adversário também manda reforços.

* Os efeitos visuais dos golpes (projéteis, impactos, anéis) são os gráficos de animação do próprio FireRed,
  extraídos da sua ROM na hora de gerar o patch (`tools/extract_movefx.py`, que lê os scripts de animação do jogo).
  Golpes que no FireRed não têm gráfico próprio (socos, chutes, tackle, Bind, Earthquake, Surf, golpes psíquicos etc.)
  usam sprites originais desenhados em `tools/customfx.py`, na cor do tipo do golpe.
* Golpes de contato acertam à queima-roupa; os demais saem como projéteis (golpes de área atingem ao redor).
* Dano, tipos, STAB, críticos, estágios, status etc. usam as regras e dados da Geração 3 do próprio jogo.
* **Captura**: fórmula da Gen 3. Depois de capturar pergunta se quer dar **apelido** (tela de nomes original).
* **Batalhas de treinador** (rival, líderes de ginásio, Elite dos 4, campeão e treinadores comuns, simples ou em dupla): luta em tempo real contra cada Pokémon do time, um após o outro. Dá EXP (x1,5),
  dinheiro do prêmio, e derrota/blackout seguem o fluxo original do jogo (com perda de dinheiro).
* **Subir de nível**: **EXP total para todo o time desde o início do jogo** (como um Exp. Share): se a batalha dá 150 de EXP, cada Pokémon do time (inclusive os que não lutaram) recebe os 150 completos, sem dividir; ao subir aprende golpes novos
  (se já tem 4, aparece a escolha de qual esquecer) e **evolui** ao fim da batalha com a cena original.
* Se o Pokémon em campo desmaiar abre a tela de troca (escolha o próximo); sem ninguém vivo, derrota normal.

## Mochila (START > BAG)

A mochila usa os **mesmos 5 bolsos da mochila do overworld**, que você troca com **←/→ (ou L/R)**: **ITEMS**,
**KEY ITEMS**, **POKE BALLS**, **TMS AND HMS** e **BERRIES**. Cada bolso lista tudo o que você tem nele, na ordem do
jogo. Em POKE BALLS, **A** escolhe a bola que o SELECT joga (marcada com \*). Nos outros, **A** usa o item quando ele
Cada uma das 12 bolas tem sua própria cor, com metade de cima, metade de baixo, botão e contorno corretos (mesmo formato, paleta própria: Great azul, Ultra preta/amarela, Master roxa, Safari verde-oliva, Net turquesa, Dive azul, Nest verde, Repeat laranja, Timer cinza, Luxury preta/dourada, Premier branca).

**Sprites:** todos os Pokémon usam os sprites do Mystery Dungeon, em tamanho original, sem encolher. Na arena, os sprites maiores que 64x64 (Lugia, Ho-Oh, Articuno, Zapdos, Moltres, Groudon, Gyarados, Onix, Wailord, Milotic, Steelix, Rayquaza etc.) são desenhados inteiros com vários OBJs de 64x64 e o movimento é limitado para que o sprite nunca passe por baixo da barra superior nem saia da tela (não precisou diminuir a HUD). Zangoose voltou ao sprite original do Mystery Dungeon (arena e mapa). Diglett e Dugtrio usam a pose parada do PMD, com a cabeça à mostra. **Limite no mapa:** seguidores e selvagens no mapa ainda são limitados a 64x64 por causa da VRAM; os 18 Pokémon maiores que isso aparecem reduzidos no mapa (com redução que preserva contornos). Os demais ficam no tamanho original. Seguidores grandes são desenhados atrás do personagem. Também corrigi pontinhos soltos nos seguidores grandes (a descompressão para a VRAM não aceita um tipo de cópia da compressão).

**Transform (Ditto):** copia a aparência, os atributos, as alterações de status, os tipos e os golpes (5 PP cada) do alvo; volta ao normal ao trocar de Pokémon ou ao fim da batalha.

**Evoluir ou não:** na arena, quando um Pokémon vai evoluir aparece "DO YOU WANT TO EVOLVE?" com YES / NO. Escolhendo NO (ou B) ele **nunca mais evolui** (fica marcado no próprio Pokémon, vale no save). A marca usa o atributo de concurso "Cute", que o hack não usa; a mesma pergunta aparece no mapa quando um Pokémon evolui por Rare Candy no menu de Pokémon/Bolsa (tela preta com YES / NO). Um Pokémon marcado nunca evolui, nem na arena nem com Rare Candy. Evoluções por outros caminhos fora da arena (pedras, troca) não foram ligadas à pergunta.

**Pokédex Nacional:** já fica ativada desde o início do jogo (Pokémon de outras regiões e suas evoluções aparecem normalmente).

**Animação dos golpes:** os golpes à distância usam o sprite do próprio jogo com um estilo de animação: pós/esporos (Poison Powder, Stun Spore, Sleep Powder, Spore, Sweet Scent, Leech Seed) viram uma nuvem de partículas lenta; raios e jatos (Flamethrower, Water Gun, Ice Beam, Hyper Beam, Solar Beam etc.) deixam rastro; golpes de várias agulhas/folhas (Pin Missile, Twineedle, Razor Leaf, Barrage etc.) saem em leque de 3; golpes de giro/ondas (Fire Spin, Whirlpool, Wrap, Twister, Supersonic, Confuse Ray, Thunder Wave etc.) giram em órbita. Todos os outros golpes à distância seguem uma regra por tipo: sem dano (status) = ondas em órbita; fogo, água, elétrico, gelo, psíquico, dragão, sombrio, fantasma e veneno = jato com rastro; grama, inseto, pedra, terra, lutador, voador, normal e aço = leque de três. Golpes de contato mostram três impactos em sequência.
tem efeito em batalha (poções, curas, Éter/Elixir, PP Up, vitaminas, Rare Candy, X Items, Dire Hit, Guard Spec e as
berries de cura); chaves e TMs só aparecem na lista ("CAN'T USE THAT HERE!"). Os itens usáveis são aplicados nos Pokémon (o jogo
pausa enquanto o menu está aberto):
Poções, Full Restore, remédios de status, Revive/Max Revive/Revival Herb, Sacred Ash, Éter/Elixir (e Max),
PP Up/PP Max, vitaminas, **Rare Candy** (sobe de nível, aprende golpes e evolui no fim da batalha),
X Attack/Defend/Speed/Special/Accuracy, Dire Hit e Guard Spec. Os efeitos vêm da tabela original do jogo.
**Poké Balls:** as 12 bolas do jogo funcionam (Master, Ultra, Great, Poké, Safari, Net, Dive, Nest, Repeat, Timer,
Luxury, Premier, com seus bônus); troque a bola no menu de pausa (←/→) e jogue com SELECT.

## Zona Safári em tempo real

Nas batalhas do Safári você não luta: **A** joga a Safari Ball (usa o contador de bolas do Safári, 30), **B** joga
**isca** (o Pokémon fica comendo: foge bem menos e fica mais difícil de capturar) e **L** joga **pedra**
(fica bravo: captura mais fácil, mas foge mais). O D-pad move o seu personagem, que aparece com o **sprite do overworld** (Red ou Leaf, conforme o seu save), com o nome do treinador, em vez de um Pokémon. O Pokémon selvagem anda pela
arena, mantém distância e pode fugir (a chance usa a taxa de fuga do jogo, sorteada a cada 2 s). Acabou o contador
de bolas, a batalha termina e o jogo continua como no Safári original. START: continuar ou fugir.

## Pokémon seguidor no mapa

O primeiro Pokémon do time anda atrás do personagem no overworld (rotas, cidades, cavernas e prédios), com o sprite
da espécie (386 espécies, vindos da ROM do Mystery Dungeon que você fornece). Ele acompanha o caminho do personagem
passo a passo, **cerca de 1,4 tile atrás** do personagem, com a mesma animação de pernas dele (uma pose de passo na primeira metade de cada tile, alternando os pés, e parado no resto), com a **mesma animação de andar** que o Pokémon usa na arena (mesmos quadros e tempos, tirados do Mystery Dungeon; ela toca enquanto o personagem anda e volta ao primeiro quadro quando ele para), com o tamanho original do sprite (só os muito grandes são encolhidos para caber em 30 px). Ele vira para a direção em que anda e anima ao caminhar. Some enquanto você surfa, anda de bicicleta ou
logo depois de entrar em outro mapa (aparece no primeiro passo). É só visual: não tem colisão e não conversa com NPCs.
Muda sozinho quando você troca o primeiro Pokémon do time. Implementado em `src/arena_f.c`; o jogo chama a rotina
logo depois de montar os sprites do mapa (um pequeno gancho no cabeçalho da ROM).

## Pokémon selvagens visíveis no mapa

Os Pokémon selvagens agora aparecem no overworld: em grama alta e cavernas aparecem andando por perto (até 4 ao mesmo
tempo, sorteados da tabela de encontros do mapa, com os mesmos níveis e chances), e surfando aparecem os da água.
Eles vagam e somem se você se afasta. **Encostar em um** (ou ele encostar em você) abre a batalha em tempo real
na arena, com aquela espécie e nível. Os sprites são os do Mystery Dungeon, como o seguidor.

Importante: os encontros aleatórios por passo (grama e surf) foram **desligados** (`StandardWildEncounter` retorna
sempre 0), então só se luta com quem aparece no mapa. Consequências: Pokémon que só aparecem por encontro fixo ou
roaming (os lendários errantes) não aparecem mais por esse sistema; pescar e Rock Smash continuam como no jogo
original; o Safári usa o mesmo sistema. Código em `src/arena_f.c` (`WildStep`).

## Primeira batalha do jogo

A batalha contra o rival no laboratório do Prof. Oak, logo depois de escolher o inicial, também roda em tempo real na
arena (ela usa uma flag própria do jogo, 0x18, que antes era ignorada). Ao terminar, o jogo segue o roteiro normal do
laboratório, ganhando ou perdendo.

## Menu de cheats (botão L)

No overworld, com o personagem livre, **L** abre uma tela de **CHEATS** no lugar da ajuda do jogo (o botão R, e o L
durante diálogos e menus, continuam abrindo a ajuda normal). Cima/baixo escolhe, **A** liga/desliga, **B** volta
(o jogo recarrega o mapa no mesmo lugar). As opções ficam gravadas no save (duas flags de sistema no fim da tabela
de flags, 0x8FE e 0x8FF).

- **EASY CAPTURE:** qualquer bola captura sempre, em qualquer Pokémon, inclusive lendários (no Safári também).
- **ALL POKEMON:** os Pokémon selvagens que aparecem no mapa passam a ser sorteados entre as 386 espécies, com
  lendários e Pokémon de outras regiões (Johto e Hoenn), em vez da tabela da rota. O nível e os locais onde aparecem
  continuam sendo os do mapa.

Implementado em `src/arena_e.c` (`CheatMenu*`, `LinkKeyCheck`) e `src/arena_f.c`.

## Evoluções por troca, item e felicidade

A tabela de evolução do jogo é alterada ao gerar a ROM:

- Evoluções **por troca** (Kadabra, Machoke, Graveler, Haunter), **por troca com item** (Onix, Scyther, Seadra,
  Porygon) e **por pedra** (Pikachu, Nidorina/Nidorino, Clefairy, Vulpix, Growlithe, Weepinbell, Shellder, Staryu,
  Exeggcute, Lombre, Nuzleaf, Skitty, Sunkern e outros) passam a acontecer no **nível 36**.
- Evoluções por **felicidade ou beleza** (Pichu, Cleffa, Igglybuff, Togepi, Azurill, Golbat, Chansey, Feebas)
  passam a acontecer no **nível 22**.
- **Evoluções por nível tardias:** toda evolução por nível acima do 36 (Dragonair, Pupitar, Ponyta, Rhyhorn,
  Slowpoke, Grimer, Slugma, Omanyte, Kabuto... 22 no total) passa a acontecer no **nível 36**. Os golpes que a
  forma evoluída aprendia a partir do nível da evolução original passam a ser aprendidos mais cedo, deslocados pela
  mesma diferença (Dragonite, que evoluía no 55: o golpe do nível 55 vem no 36, o do 66 no 47, e assim por diante;
  os golpes de antes disso não mudam).
- **Eevee:** as pedras continuam (Vaporeon, Jolteon, Flareon), e Espeon e Umbreon agora evoluem por item segurado,
  no nível 22 ou mais: **Potion = Espeon**, **Antidote = Umbreon** (o item é consumido; a evolução por felicidade
  foi removida). O Eevee selvagem vem com um dos 5 itens sorteado.
- **Exceções (continuam por pedra):** Poliwhirl, Slowpoke e Clamperl mantêm as evoluções originais por
  pedra (usando a pedra da mochila) porque têm mais de um ramo.
- **Item segurado como gatilho (sem troca):** as evoluções que exigiam troca com item acontecem no nível 36 ou mais
  se o Pokémon estiver **segurando** o item, que é consumido: Poliwhirl + King's Rock = Politoed, Slowpoke + King's
  Rock = Slowking (sem o item evolui para Slowbro no 37), Clamperl + Deep Sea Tooth = Huntail, Clamperl + Deep Sea
  Scale = Gorebyss. Vale para as evoluções que acontecem na arena e logo depois dela; usar Rare Candy fora da
  batalha não dispara esse caso.
- Os Pokémon **selvagens já vêm segurando o item de evolução** da espécie (Onix com Metal Coat, Pikachu com Thunder
  Stone etc.). Nas espécies com mais de um item, o item é sorteado: Eevee (Fire, Water ou Thunder Stone), Gloom (Leaf ou Sun
  Stone), Poliwhirl (Water Stone ou King's Rock) e Clamperl (Deep Sea Tooth ou Scale). Vale para qualquer captura, já que o item é colocado no Pokémon selvagem ao começar a batalha.

Tabela de itens em `tools/make_rom.py` (`patch_evolutions`); o jogo lê o item em `ArenaStart`.

## Chão da arena conforme o local

O chão da arena muda de acordo com o terreno onde a batalha começou (o próprio jogo decide): grama, grama alta,
areia, mar, lagoa, debaixo d'água, montanha, caverna, prédio/ginásio/Elite 4 (piso de ladrilho) e terra (rotas sem
grama). Pescando, o chão vira água. O gerador dos temas é `tools/floorthemes.py` (arte original).

## Evolução em tempo real

Quando um Pokémon sobe de nível e pode evoluir, a evolução acontece **dentro da arena**, logo depois da
batalha (ou do adversário derrotado, em lutas de treinador, ginásio, Elite 4 e batalhas em dupla):
"X IS EVOLVING!", o sprite pisca em branco e troca pelo da nova forma, o HUD é atualizado, o grito toca e os
golpes do novo nível são oferecidos. Aperte **B** durante o brilho para cancelar. A Pokédex é atualizada e o
apelido só muda se ainda for o nome da espécie. Pokémon do time que não estavam em campo evoluem com mensagens.

## Pokémon grandes

Pokémon maiores que o limite de 64x64 do GBA (Onix, Gyarados, Dragonite, Groudon, etc.) são reduzidos
automaticamente na geração do pacote de sprites para aparecerem inteiros.

## Limitações conhecidas (protótipo)

* **Lendários e Mewtwo** (Articuno, Zapdos, Moltres, Mewtwo, Lugia, Ho-Oh, Deoxys e demais encontros
  scriptados) também rodam em tempo real; dá para enfraquecer e capturar normalmente.
* Tutoriais, fantasmas, roaming e link continuam com o sistema original.
* Itens do treinador não existem (só os seus).
* Fonte do HUD só em maiúsculas; arena de uma tela só.
* Testado em emulador (mGBA); não testado em hardware real.

## Como funciona (resumo técnico)

* O código (C compilado para Thumb, ~42 KB) fica em 0x09000000 numa ROM expandida; o pacote de
  sprites em 0x09020000.
* Hook: o literal de `Task_BattleStart` (ROM 0x7F68C) que aponta para `CB2_InitBattle` passa a apontar
  para `ArenaEntry`; se a arena não se aplica, ela chama `CB2_InitBattle` normalmente.
* O tratador de teclas L/R do adaptador wireless (tabela em 0x0813B890) é desviado para
  `LinkKeyGuard` enquanto a arena roda, pois ele desligava o VBlank ao apertar R.
* Formato do pacote de sprites: ver `tools/pack_sprites.py`.


**HMs sem Pokémon que saiba o golpe:** Cut (árvores), Surf (água), Strength (pedras), Rock Smash (rochas), Waterfall e Dive funcionam só interagindo, sem nenhum Pokémon do time conhecer o golpe. Continua valendo a regra original da insígnia: é preciso ter derrotado o líder correspondente (Cut = Cascade, Strength = Rainbow, Surf = Soul etc.; Rock Smash não pede insígnia no FireRed). A mensagem usa o primeiro Pokémon do time ("PIKACHU used SURF!"), ou o que sabe o golpe, se houver (nesse caso o jogo usa o primeiro que ele achar; sem ninguém, usa o primeiro do time). Teleport e Dig são golpes de menu e não foram alterados. Implementação: o comando de script `checkpartymove` e a função de checagem do Surf foram trocados (tools/make_rom.py, src/arena_e.c: HmCheck).


**Fly e Flash sem o golpe:**
- **Fly:** com a insígnia Thunder, apertar **R** em área externa abre o mapa do Fly (escolha a cidade com A; o Pokémon que aparece voando é o primeiro do time). O sistema HELP do jogo (L/R) fica desligado no mapa por causa disso. Se você cancelar o mapa com B, o jogo volta pelo menu de Pokémon e depois pelo menu Start (basta fechar com B).
- **Flash:** com a insígnia Boulder, ao entrar numa caverna escura aparece uma vez "This cave is dark. Use FLASH?" com YES / NO. YES acende a caverna ("FLASH lit up the cave!"); NO deixa escura e não pergunta de novo naquele mapa até você sair e entrar outra vez. Se já estiver ativo, não pergunta.
- Implementação: FieldMoves em src/arena_f.c (chamada todo quadro no mapa).


**Eventos (Birth Island e Navel Rock):** o jogo já começa com o Aurora Ticket e o Mystic Ticket na bolsa. Mostre-os ao marinheiro do porto de Vermilion City, como no jogo original, para liberar a Birth Island (Deoxys) e a Navel Rock (Lugia/Ho-Oh). A Faraway Island (Mew) e a Southern Island (Latios/Latias) não existem na FireRed. O jogo também liga as flags de "ticket recebido" e "barco liberado" que o evento original ligaria. Seguidores grandes ficam um pouco mais afastados do jogador no mapa.

**Modo ALL POKEMON (aleatório):** além dos selvagens visíveis no mapa, agora também são aleatórios os encontros que não vêm deles (pesca, Rock Smash, Sweet Scent), com o mesmo nível. Selvagens grandes (64x64) no mapa aparecem um por vez e encostam de uma casa mais longe.

**Marinheiro do porto de Vermilion (Navel Rock / Birth Island):** o marinheiro entre os dois pilares agora oferece a viagem a qualquer momento (as condições de história do original foram desligadas). Com os tickets na bolsa, escolha OTHER no menu do Seagallop para ir à Navel Rock ou à Birth Island.

**Sprites no mapa:** a redução dos Pokémon grandes foi refeita (cobertura exata de área, contorno contínuo) e os olhos pequenos (Rayquaza, Lugia, Steelix, Ho-Oh etc.) são preservados em vez de virarem preto.

**Duplas:** treinadores de dupla também lutam em tempo real quando você tem só um Pokémon em condições (o jogo os trata como batalha simples).

**Batalhas especiais em tempo real:** o fantasma da Pokémon Tower (Marowak L30 depois do Silph Scope), o Snorlax das rotas 12 e 16 e outras batalhas selvagens de roteiro agora também usam a arena. Só batalhas por cabo, multi, Battle Tower, tutoriais e e-Reader seguem como no jogo original.

**Flamethrower:** agora é uma coluna longa de chamas ondulando (10 sprites), bem mais comprida que o Ember.

**Trainer Tower (experimental, sem teste):** as batalhas da torre usam a arena apenas se o time do treinador já estiver montado quando a batalha começa (o ROM compara com o time da batalha anterior). Se não estiver, a batalha segue como no jogo original, sem erro. Nome do treinador pode aparecer errado na arena.


## Link por cabo: batalhas 1x1 / 2x2 em tempo real e trocas

No overworld, **L → LINK BATTLE (CABLE)** nos dois consoles (sem Cable Club, sem condições do jogo). Os dois se encontram,
trocam as equipes e mostram o time do adversário. Nessa tela:

* **A** = batalha, **START** = troca. Os dois precisam escolher a mesma coisa. **SELECT** alterna 1x1 / 2x2 (vale a escolha do console 1). **B** cancela.
* **Nível igual** nos dois lados (padrão L20 x L20; direcional: ±1 / ±10; 0 = níveis originais; vale a escolha do console 1). Os Pokémon são recalculados nesse nível, com HP e PP cheios e sem status. Nada é alterado nos seus Pokémon de verdade; sem prêmio e sem EXP (o nível igual vale para o time inteiro).
* **Time inteiro:** a batalha só termina quando **todos** os Pokémon saudáveis de um lado caem. Quando o seu Pokémon cai, o próximo do time (na ordem da equipe) entra no lugar, com HP e PP cheios e uma breve invulnerabilidade; o HUD mostra "X<n>" com quantos faltam ao adversário. **1x1:** um Pokémon de cada vez. **2x2:** dois de cada lado; cada jogador controla os seus dois (A/L = primeiro, B/R = segundo; SELECT alterna os golpes 1-2 / 3-4); quem cai é substituído pelo próximo. Vence quem derrubar todos do outro; aparece "YOU WIN!/YOU LOSE...".
* **Troca:** escolha o Pokémon (cima/baixo, A), os dois veem "YOU GIVE / YOU GET", confirmam com A e a troca é feita nos dois lados (Pokédex marca visto/capturado). Os Pokémon trocados NÃO evoluem por troca (evolução por troca não foi implementada). Salve o jogo depois. Se o cabo cair no instante exato da confirmação, um lado pode ficar com a troca feita e o outro não: não tem como garantir atomicidade em um cabo.
* **Cable Club (2º andar do Centro Pokémon):** os três atendentes do balcão (esquerda, centro, direita) agora abrem essa mesma tela de link em tempo real (batalha 1x1/2x2 ou troca), em vez do Colosseum/Trade Center originais. Ao sair (B ou fim da batalha) você volta ao 2º andar. Implementação: os scripts dos atendentes viram `callnative ClubEntry; end` (`install_club` em `tools/make_rom.py`). **Testado:** no emulador, os três atendentes abrem a tela e B volta ao andar. **Não testado:** com um Cable Club/cabo real de dois consoles (a tela é a mesma já testada em lockstep).
* Como funciona a batalha: os dois consoles rodam a **mesma simulação** (lockstep); só os botões viajam pelo cabo, a cada quadro, com a mesma semente de números aleatórios. Um checksum do estado detecta dessincronia ("OUT OF SYNC") e perda de cabo ("LINK LOST"). Camada de link própria sobre o SIO (modo multiplayer, 115200 baud, envio-e-confirmação), em `src/arena_l.c`. O console 1 fica à esquerda; o HUD de cada um mostra os seus golpes embaixo.
* Os Pokémon trafegam no formato bruto da 3ª geração; vale entre FRLG e RSE desde que o outro jogo também rode esta ROM modificada (um RSE original não participa).
* **Testado:** dois consoles emulados (mGBA em lockstep): troca de equipes, 1x1 e 2x2 com golpes e movimento sincronizados (mesmas posições e HP), fim de batalha com vencedor e perdedor, e uma troca completa (Pikachu L12 <-> Charizard L23, conferido na memória). **Não testado:** cabo real, outros emuladores, RSE.
* **Limitações:** sem troca de Pokémon, itens ou 3+ jogadores durante a batalha; Pokémon sem sprite no pacote (fora de 1-386) não entram.


## Efeitos de golpes (ajustes)

* **Surf** agora é um golpe de longo alcance como Ember: um trem de três ondas vistas **de lado** (perfil com crista e espuma, sprite original desenhado para o projeto) rola para a frente (antes era uma explosão ao redor de quem usa). Atinge o primeiro inimigo no caminho.
* **Wing Attack** e **Steel Wing** mostram exatamente duas asas retas, esticadas para os lados como as de um avião (uma de cada lado do alvo, com 8 penas cada, batendo de leve). Sprite original desenhado para o projeto (`wing` em `tools/customfx.py`). No Steel Wing as asas são prateadas.
* **Gust** é um tornado (funil girando e balançando) que viaja até o alvo.
* **Dig** agora é de **longa distância**: um monte de terra avança pelo chão até o inimigo e, onde acerta, abre uma **cratera** sob o alvo, que fica visível por uns instantes.
* **Golpes de água do Squirtle e evoluções:** **Bubble** é um amontoado de bolhas pequenas que vai só para a frente, de longa distância, como o Ember (antes explodia ao redor). **Water Pulse** são anéis de água, um atrás do outro. **Waterfall** é uma cachoeira (coluna de água caindo) de **meia distância**: avança uns 100 pixels e some. **Dive** é um mergulho: um arco de água com marolas no chão que cruza o campo, de longa distância. Sprites originais desenhados para o projeto (`bubbles`, `ring`, `fall`, `dive` em `tools/customfx.py`).
* **Magnitude** também é de longa distância, com um sprite próprio (três rochas pontiagudas saindo do chão, em meio a poeira), diferente do Earthquake (rachaduras em zigue-zague).
* **Blizzard** é **uma única rajada** de ventania de gelo (vento em ondas com cristais) que voa para a frente até o alvo, como o Ember (longa distância). **Ice Beam** vem como um amontoado de bolas de gelo em forma de feijão, em fila e espalhadas, também de longa distância. **Earthquake** agora é de longa distância: uma fileira de rachaduras no chão avança até o inimigo (antes era uma explosão ao redor de quem usa).
* **Fire Blast** é o "大" de fogo do anime (barra, haste e duas pernas em chamas), com um rastro de chamas atrás; as chamas também aparecem no impacto.


## Correções (batalhas em dupla e Revive)

* **Treinadores em dupla (ex.: Mik & Kia na Kindle Road):** o jogo só liga a bandeira de "dupla" depois que o código da arena decide, então essas lutas entravam como 1x1. Agora a arena lê no cadastro do treinador se ele luta em dupla (e você tem pelo menos dois Pokémon saudáveis): a luta é 2x2. Com um só Pokémon utilizável, continua 1x1.
* **Revive / Max Revive em Pokémon desmaiado:** funcionam na mochila (START → BAG) em qualquer Pokémon do time desmaiado, inclusive o que acabou de cair no campo (ele se levanta e continua a luta com invulnerabilidade curta). Quando o seu Pokémon cai e há outros, a tela "CHOOSE YOUR NEXT POKEMON" ganhou **START: BAG** (mochila). Quando **todos** caíram e você tem Revive/Max Revive, aparece "ALL FAINTED! USE A REVIVE?" (START = mochila, B = desistir); sem Revive a luta termina como antes.


## Nota de compatibilidade (My Boy!)
Um build com os golpes de água novos travava no My Boy! (Android) embora funcionasse no mGBA; o problema dependia da organização do código gerado. As funções de desenho de efeitos (`DrawFx`, `DrawProjFx`) agora são `noinline`, o que corrigiu o travamento no aparelho do usuário. Se algum build futuro travar só no My Boy!, suspeite de layout do código antes de suspeitar do golpe.

## Razor Leaf e Vine Whip
- **Razor Leaf**: um amontoado de folhas voando para frente, longa distância (mesmo espalhamento do Ice Beam).
- **Vine Whip**: dois chicotes de cipó voando para frente, longa distância.

## Dragon Rage e Grovyle
- **Dragon Rage**: um dragão amarelo voa até o alvo.
- **Grovyle**: verde do corpo mais claro na arena (`tools/tweak_sprites.py` aplica o ajuste de paleta no pacote de sprites).

## Correção: reflexos na água
O seguidor/Pokémon selvagem é inserido no buffer de OAM; o deslocamento das entradas arrastava também as matrizes afins (palavra 3 de cada entrada), que o jogo usa para virar o reflexo na água. Agora só os atributos 0-2 são deslocados, e as matrizes ficam no lugar.

## Dragon Rage furioso
O dragão amarelo ganhou cara de fúria: sobrancelha pesada, olho vermelho, mandíbula aberta com presas, chifres e asa.

## Dragon Rage estilo Game of Thrones
O dragão amarelo agora tem asa de morcego aberta, pescoço longo, cabeça com chifres e olho vermelho, patas e cauda.

## Dragon Rage salamandra
O Dragon Rage agora é uma salamandra-dragão amarela com o corpo inteiro à mostra: corpo comprido ondulado, quatro patas, cauda, manchas pretas, espinhos nas costas e cara furiosa.

## Dragon Rage com o contorno do Salamence
O Dragon Rage usa o contorno do corpo inteiro do Salamence (o dragão da 3ª geração), redesenhado em amarelo, com asa laranja e olho vermelho furioso.

## Portão de ferro de Ruin Valley (Dotted Hole)
Falar com o homem na frente do portão (ou apertar A no portão) agora usa Cut sozinho: "There are dots on the door. Your party used CUT! The door opened!". O jogo marca o portão como aberto, esconde o homem e recarrega o mapa, assim o caminho fica livre. Se já estiver aberto, mostra o texto original.

## Acid
Acid agora é um golpe de longa distância: uma poça de ácido no chão (cor roxa original) que escorre só para frente.

## PP
Todo golpe que tinha PP 5 ou 10 agora tem 15 (`patch_pp` em `tools/make_rom.py`).

## Modo fácil
Menu do botão L no mundo aberto: nova opção **EASY MODE** (flag 0x8FD). Ligada, todo dano que os Pokémon adversários causam no jogador é dividido por 12 (mínimo 1), mesmo com vantagem de tipo. Não afeta o modo cabo.

## Grovyle no mundo aberto
O seguidor Grovyle também usa o verde claro (arena e mundo aberto).

## Trainer Tower em tempo real
A Trainer Tower inicia suas batalhas por tarefas próprias (`trainer_tower.c`), e não por `Task_BattleStart`, por isso o gancho não era chamado. `make_rom.py` agora também aponta os dois literais `CB2_InitBattle` da torre (0x15BD54 e 0x15E15C, constante `TOWER_HOOKS`) para a arena. Vale para Single, Double, Knockout e Mixed (todos usam as flags 0x80008/0x80009); a batalha começa ao interagir com o treinador do andar.

## Pokébolas (sprites originais + animação)
- `tools/pack_balls.py` extrai os 12 ícones de Poké Ball do jogo original (24x24, tabela de ícones de itens), reduz para 12x12 (sprite 16x16) e grava 12 x 160 bytes em 0x09DFF800. Substituem os sprites antigos de bola (lançamento e captura), cada bola com a sua paleta original.
- **Animação de entrada**: no início da batalha, ao trocar de Pokémon e quando o treinador manda o próximo, uma bola voa em arco girando desde o canto do lado do Pokémon, abre numa explosão e o Pokémon aparece num clarão branco (`StartRelease` em `arena_c.c`, `DrawRelease` em `arena_d.c`). Pokémon seu usa a bola com que foi capturado (MON_DATA_POKEBALL); Pokémon de treinador usa Poké Ball; no modo cabo cada um usa a sua. Pokémon selvagem só aparece. Em duplas, a segunda bola sai depois da primeira (mesma paleta).
- O Actor ganhou 4 bytes (relT, relDelay, relBall, relPad): `tools/bot.py` agora usa o passo 156.

## Pokémon grandes em duplas
Rayquaza, Groudon, Kyogre, Lugia, Ho-Oh, Zapdos, Articuno e outros sprites grandes começam um em cima e outro embaixo e mantêm distância proporcional ao tamanho do desenho dos outros do mesmo lado (`SepR`/`SeparateActors`, normal e cabo).

## Repel
Repel, Super e Max Repel (contador VAR 0x4020): enquanto ativo, selvagens de nível menor ou igual ao do primeiro Pokémon saudável não aparecem no mapa nem iniciam batalha (`RepelOn` em `arena_f.c`).

## Chão de neve
Seafoam Islands e Icefall Cave (mapsec 0x8B e 0xB1) usam o tema 10 (neve) no piso da arena (`gFloorPals[11]`).

## Trainer Tower: Knockout, Easy Mode; HUD symbols
- Trainer Tower fights now save your party exactly like the original battle start does (should fix Knockout wins sending you to the 1st floor - tested only that Single mode still works in mGBA; Knockout itself could not be reached in the emulator).
- Easy Mode: Trainer Tower enemies also have 1/4 of their HP and react slower (on top of the 1/12 damage).
- Wild Pokemon show a blue male / pink female sign next to the HP bar, and a Poke Ball sign when the species is already caught.

## Dragon Claw
Dragon Claw now shows three yellow claw slashes across the target (hand-drawn sprite, tools/customfx.py 'dclaw').

## Dragon Claw / EXP FOR ALL
- Dragon Claw shows only the three yellow claws (no generic hit star).
- New option in the L menu: EXP FOR ALL. ON = every Pokemon of the team gets the full Exp of each defeated enemy. OFF (default) = only the Pokemon that took part in the battle, sharing it.

## Slower Poke Ball release, Rain Dance
- The ball thrown at the start / on a switch now flies much slower (about 0.7 s) and tumbles more slowly, so it can be followed.
- Rain Dance is now a blue drizzle falling over the Pokemon that used it (about 2 seconds).

## Out of PP
When a move runs out of PP, pressing it uses Struggle (typeless, 50 power, 1/4 recoil) instead of doing nothing, so you can always keep damaging the enemy. Not used in link battles.

## Trainer Tower Knockout (real-time)
Knockout fights are real-time again. The cause of the old "win = loss" bug: the Tower scripts read the fight's result from VAR_RESULT, which the game's own battle end writes; the arena now writes it too (1 won, 2 lost, 3 drew). Tested in mGBA by winning a real Knockout fight on floor 1 and seeing the next trainer's fight start.

## Hydro Pump
Hydro Pump is now a continuous jet of water (a row of water blobs from the user to the head of the shot).

## Mega Drain, Giga Drain e Thunder Shock
- **Mega Drain / Giga Drain**: um amontoado de bolinhas verdes voa até o alvo (a cura continua igual).
- **Thunder Shock**: uma onda horizontal de raios amarelos em zigue-zague corre até o alvo, em vários trechos ligados.
