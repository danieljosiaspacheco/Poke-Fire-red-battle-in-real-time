"""statusfx.py - original 32x32 sprites for the status moves that have no graphics in FireRed.
DEF maps a kind name to (shape drawing function name, palette).  Palette = (outline, main, light, white, shade).
Colour indices on the canvas: 1 outline, 2 main, 3 light, 4 white, 5 shade.  Pure python."""
import math

def _P(o, m, l, s): return (o, m, l, (255, 255, 255), s)
STEEL = _P((40, 44, 56), (170, 176, 190), (230, 234, 244), (104, 110, 128))
STEELBLUE = _P((24, 40, 88), (120, 150, 210), (206, 224, 255), (64, 92, 160))
GREY = _P((60, 60, 70), (170, 170, 176), (232, 232, 238), (110, 110, 120))
GREEN = _P((16, 72, 24), (72, 200, 56), (184, 248, 140), (40, 136, 40))
PINK = _P((140, 40, 100), (250, 120, 180), (255, 200, 226), (200, 70, 140))
PSY = _P((110, 30, 120), (230, 110, 220), (255, 190, 250), (170, 60, 180))
PURPLE = _P((50, 14, 80), (150, 64, 200), (216, 160, 248), (96, 30, 140))
DARKP = _P((20, 6, 40), (84, 40, 130), (156, 100, 210), (46, 18, 80))
BLUE = _P((16, 56, 150), (60, 150, 240), (170, 218, 255), (30, 100, 200))
YEL = _P((120, 96, 0), (248, 216, 24), (255, 248, 150), (200, 150, 8))
FLASH = _P((150, 130, 40), (255, 238, 110), (255, 255, 200), (240, 205, 70))
ACID = _P((56, 24, 80), (150, 220, 60), (216, 255, 140), (80, 150, 30))
BLACK = _P((90, 90, 110), (36, 34, 48), (110, 108, 130), (60, 58, 76))
RED = _P((90, 10, 10), (230, 50, 40), (255, 150, 130), (160, 20, 20))
CAMO = _P((70, 56, 20), (150, 190, 70), (216, 236, 140), (190, 140, 60))
SANDY = _P((100, 86, 60), (200, 186, 150), (246, 238, 214), (150, 134, 100))
CYAN = _P((30, 96, 120), (110, 220, 240), (210, 248, 255), (60, 160, 190))


def sword(c):
    c.line(7, 25, 24, 8, 6, 1)
    c.line(7, 25, 24, 8, 4, 2)
    c.line(8, 24, 23, 9, 1.4, 3)
    c.poly([(23, 6), (28, 3), (26, 10)], 2)
    c.line(5, 21, 12, 28, 4, 1); c.line(5, 21, 12, 28, 2.4, 5)       # cross guard
    c.line(3, 29, 8, 24, 4, 1); c.line(3, 29, 8, 24, 2.4, 5)
    c.px(25, 7, 4); c.px(24, 8, 4)

def sparkle4(c):
    pts = [(16, 1), (19, 13), (31, 16), (19, 19), (16, 31), (13, 19), (1, 16), (13, 13)]
    c.poly(pts, 2)
    c.poly([(16, 6), (18, 14), (26, 16), (18, 18), (16, 26), (14, 18), (6, 16), (14, 14)], 3)
    c.ell(16, 16, 3, 3, 4)
    c.outline()

def orb(c):
    c.ell(16, 16, 10, 10, 2)
    for y in range(32):
        for x in range(32):
            if c.p[y][x] == 2 and (x - 16) + (y - 16) > 7: c.p[y][x] = 5
    c.ell(13, 12, 5, 3.6, 3); c.ell(12, 11, 2, 1.4, 4)
    c.outline()

def plus(c):
    c.rect(12, 3, 19, 28, 2); c.rect(3, 12, 28, 19, 2)
    c.rect(12, 3, 14, 28, 3); c.rect(3, 12, 28, 14, 3)
    c.rect(18, 3, 19, 28, 5); c.rect(3, 18, 28, 19, 5)
    c.rect(13, 13, 18, 18, 4)
    c.outline()

def wisp(c):
    c.ell(16, 19, 8, 9, 2)
    c.poly([(8, 17), (12, 10), (14, 2), (17, 9), (21, 4), (24, 17)], 2)
    c.poly([(11, 17), (14, 10), (16, 7), (18, 12), (21, 17)], 3)
    c.ell(13, 20, 2.2, 3, 4); c.ell(19, 20, 2.2, 3, 4)
    c.ell(13, 21, 1.1, 1.8, 1); c.ell(19, 21, 1.1, 1.8, 1)
    c.outline()

def drip(c):
    c.ell(16, 20, 8, 8, 2)
    c.poly([(16, 2), (23, 17), (9, 17)], 2)
    for y in range(32):
        for x in range(32):
            if c.p[y][x] == 2 and (x + y > 38): c.p[y][x] = 5
    c.ell(13, 18, 2.6, 3.4, 3); c.px(12, 16, 4); c.px(13, 16, 4)
    c.outline()

def recycle(c):
    for base in (0, 180):
        c.ring(16, 16, 13, 9, 2, clip=lambda x, y, b=base: ((math.degrees(math.atan2(-(y - 16), x - 16)) - b + 360) % 360) < 130)
    # arrow heads at the ends of each arc
    for base in (0, 180):
        a = math.radians(base + 132); px, py = 16 + 11 * math.cos(a), 16 - 11 * math.sin(a)
        d = a + math.pi / 2
        c.poly([(px + 6 * math.cos(d), py - 6 * math.sin(d)), (px - 6 * math.cos(d), py + 6 * math.sin(d)),
                (px + 7 * math.cos(a + math.pi / 2 + 1.2) * 0 + 8 * math.cos(d + 1.57), py - 8 * math.sin(d + 1.57))], 2)
    c.ring(16, 16, 11, 10, 3, clip=lambda x, y: y < 16)
    c.outline()

def swirl(c):
    pts = []
    for k in range(0, 121):
        t = k / 120.0; ang = t * 4.6 * math.pi; r = 1.5 + 13 * t
        pts.append((16 + r * math.cos(ang), 16 + r * math.sin(ang), 1.2 + 3.2 * t))
    for x, y, w in pts: c.ell(x, y, w + 1.2, w + 1.2, 1)
    for x, y, w in pts: c.ell(x, y, w, w, 2)
    for x, y, w in pts[::3]: c.ell(x - 0.6, y - 0.6, max(0.8, w * 0.45), max(0.8, w * 0.45), 3)
    c.ell(16, 16, 2, 2, 4)

def _quad_border(c, pts, thick=3.2, rivets=False, shine=True):
    for (a, b), (d, e) in zip(pts, pts[1:]): c.line(a, b, d, e, thick + 2, 1)
    for (a, b), (d, e) in zip(pts, pts[1:]): c.line(a, b, d, e, thick, 2)
    if shine:
        for (a, b), (d, e) in zip(pts, pts[1:]): c.line(a, b, d, e, 1.0, 3)
    if rivets:
        for (a, b) in pts[1:-1]: c.ell(a, b, 1.6, 1.6, 4)

def plate(c):               # quarter of a thick octagonal armour frame; the game draws it four times, mirrored
    _quad_border(c, [(4, 31), (4, 14), (14, 4), (31, 4)], 3.6, True)
    c.line(8, 27, 8, 17, 1, 4); c.line(16, 8, 27, 8, 1, 4)
    for i in range(3): c.px(6 + i, 12 - i, 5)

def hexq(c):                # quarter of a hexagonal force field
    _quad_border(c, [(4, 31), (4, 18), (12, 4), (31, 4)], 2.8, False)
    for k in range(5): c.px(8 + k, 20 - k * 2, 4)
    c.px(14, 7, 4); c.px(18, 6, 4)

def bubbleq(c):             # quarter of a round shell of water / glass
    c.ring(31, 31, 28, 24.5, 1, clip=lambda x, y: x <= 31 and y <= 31)
    c.ring(31, 31, 27, 25.5, 2, clip=lambda x, y: x <= 31 and y <= 31)
    c.ring(31, 31, 26.4, 25.6, 3, clip=lambda x, y: x <= 31 and y <= 31)
    for k in range(6): c.px(7 + k, 14 - int(k * 1.2), 4)
    c.px(5, 20, 4); c.px(5, 22, 4)

def streak(c):              # three speed lines, the head on the right, tapering to the left
    for y, x0, w in ((7, 3, 3), (15, 0, 4), (23, 6, 3)):
        c.poly([(x0, y), (30, y - w / 2.0), (30, y + w / 2.0)], 2)
        c.line(x0 + 6, y, 29, y, 1, 3)
    c.outline()

def arrow(c):               # a diagonal arrow pointing to the bottom right
    c.line(4, 4, 20, 20, 5, 1); c.line(4, 4, 20, 20, 3, 2); c.line(5, 4, 19, 18, 1, 3)
    c.poly([(30, 30), (13, 24), (24, 13)], 1)
    c.poly([(27, 27), (16, 23), (23, 16)], 2)
    c.line(19, 24, 24, 19, 1, 3)

def dupghost(c):            # a hazy pale silhouette (head + body), dithered so the real Pokemon shows through
    mask = []
    c.ell(16, 9, 6, 6, 9); c.ell(16, 20, 9, 10, 9)
    for y in range(32):
        for x in range(32):
            if c.p[y][x] == 9:
                c.p[y][x] = 2 if (x + y) % 2 == 0 else 0
    for y in range(32):
        for x in range(32):
            if c.p[y][x] == 2 and (y < 3 or any(y + dy < 0 or y + dy > 31 or c.p[y + dy][x] == 0 for dy in (-2, 2))): c.p[y][x] = 3 if (x % 2 == 0) else 2
    c.ell(14, 8, 1.2, 1.2, 4); c.ell(19, 8, 1.2, 1.2, 4)

def drops(c):
    for (x, y, r) in ((8, 20, 3.4), (16, 10, 4.2), (24, 19, 3.4), (12, 27, 2.4), (21, 27, 2.4), (16, 22, 2.0)):
        c.ell(x, y + 1, r, r, 2); c.poly([(x, y - r * 1.9), (x + r * 0.9, y), (x - r * 0.9, y)], 2)
        c.px(int(x - r / 2), int(y), 4)
    c.outline()

def fog(c):
    for (x, y, rx, ry) in ((9, 20, 8, 6), (17, 15, 9, 8), (24, 21, 7, 6), (14, 24, 9, 5)):
        c.ell(x, y, rx, ry, 2)
    for (x, y, rx, ry) in ((17, 12, 5, 3.4), (10, 18, 4, 2.6), (24, 19, 3.6, 2.4)):
        c.ell(x, y, rx, ry, 3)
    c.outline()

def swish(c):               # a curved white swipe, thick in the middle, pointed ends
    for k in range(0, 61):
        t = k / 60.0; ang = math.radians(-70 + 140 * t)
        w = 1.0 + 4.6 * math.sin(math.pi * t)
        x = 5 + 20 * math.cos(ang); y = 16 + 18 * math.sin(ang)
        c.ell(x, y, w / 2 + 1.1, w / 2 + 1.1, 1)
    for k in range(0, 61):
        t = k / 60.0; ang = math.radians(-70 + 140 * t)
        w = 1.0 + 4.6 * math.sin(math.pi * t)
        x = 5 + 20 * math.cos(ang); y = 16 + 18 * math.sin(ang)
        c.ell(x, y, w / 2, w / 2, 2)
        if w > 3: c.ell(x - 0.4, y, w / 5, w / 5, 4)

def darkcloud(c):
    for (x, y, rx, ry) in ((9, 18, 7, 6), (17, 12, 9, 8), (24, 19, 7, 6), (15, 22, 9, 6)):
        c.ell(x, y, rx, ry, 2)
    for (x, y, rx, ry) in ((15, 10, 5, 3.4), (8, 16, 3.6, 2.4)):
        c.ell(x, y, rx, ry, 3)
    c.ell(12, 19, 2.2, 1.6, 4); c.ell(20, 19, 2.2, 1.6, 4)
    c.px(12, 19, 1); c.px(20, 19, 1)
    c.outline()

def eyes(c):
    for cx in (9, 23):
        c.ell(cx, 17, 6.2, 4.4, 1); c.ell(cx, 17, 5.2, 3.5, 4)
        c.ell(cx, 17, 2.8, 3.2, 2); c.ell(cx, 17, 1.2, 2.4, 1)
    c.line(2, 9, 14, 13, 2.4, 1); c.line(30, 9, 18, 13, 2.4, 1)       # angry brows

def psyring(c):
    c.ring(16, 16, 14, 11, 1); c.ring(16, 16, 13, 12, 2)
    c.ring(16, 16, 9, 6.5, 1); c.ring(16, 16, 8.4, 7.1, 3)
    c.ell(16, 16, 2.6, 2.6, 4)
    for a in (30, 150, 270): c.px(int(16 + 13 * math.cos(math.radians(a))), int(16 - 13 * math.sin(math.radians(a))), 4)

def skull(c):
    c.ell(16, 13, 10, 9, 4); c.rect(10, 18, 22, 27, 4)
    c.ell(12, 14, 3.2, 3.6, 1); c.ell(20, 14, 3.2, 3.6, 1)
    c.poly([(16, 17), (14, 21), (18, 21)], 1)
    for x in (12, 15, 18, 21): c.line(x, 23, x, 27, 1, 1)
    for y in range(32):
        for x in range(32):
            if c.p[y][x] == 4 and (x + y) > 36: c.p[y][x] = 3
    c.outline()

def hand(c):
    c.ell(15, 22, 9, 7, 2)
    for i, (x, ang) in enumerate(((7, 100), (12, 90), (17, 82), (22, 72))):
        c.line(x, 20, x + (90 - ang) * 0.12, 6 + abs(i - 1.5) * 1.4, 4, 2)
        c.poly([(x - 1.6 + (90 - ang) * 0.12, 8 + abs(i - 1.5)), (x + 1.6 + (90 - ang) * 0.12, 8 + abs(i - 1.5)), (x + (90 - ang) * 0.14, 2 + abs(i - 1.5) * 1.2)], 3)
    c.line(5, 24, 2, 16, 4, 2)
    c.ell(13, 24, 4, 2.6, 5)
    c.outline()

def scent(c):
    for x0 in (7, 16, 25):
        pts = []
        for k in range(0, 31):
            t = k / 30.0
            pts.append((x0 + 3.2 * math.sin(t * 6.5 + x0), 29 - 26 * t))
        for (a, b), (d, e) in zip(pts, pts[1:]): c.line(a, b, d, e, 3.4, 1)
        for (a, b), (d, e) in zip(pts, pts[1:]): c.line(a, b, d, e, 2.0, 2)
        for (a, b), (d, e) in list(zip(pts, pts[1:]))[::4]: c.line(a, b, d, e, 0.8, 4)

def bricks(c):
    c.rect(3, 5, 28, 26, 2)
    for y in (5, 12, 19, 26): c.rect(3, y, 28, y + 1, 5)
    for y, off in ((6, 0), (13, 7), (20, 0)):
        for x in range(3 + off, 29, 14): c.rect(x, y, x + 1, y + 6, 5)
    c.rect(3, 6, 28, 6, 3); c.rect(3, 13, 28, 13, 3); c.rect(3, 20, 28, 20, 3)
    c.outline()

SHAPES = {k: v for k, v in globals().items() if callable(v) and k in (
    'sword', 'sparkle4', 'orb', 'plus', 'wisp', 'drip', 'recycle', 'swirl', 'plate', 'hexq', 'bubbleq', 'streak', 'arrow',
    'dupghost', 'drops', 'fog', 'swish', 'darkcloud', 'eyes', 'psyring', 'skull', 'hand', 'scent', 'bricks')}

# kind -> (shape, palette) ; moves -> kind
DEF = {
    'st_sword': ('sword', STEEL), 'st_safe': ('sparkle4', PINK), 'st_tailglow': ('sparkle4', YEL), 'st_flash': ('sparkle4', FLASH),
    'st_wispd': ('wisp', DARKP), 'st_orbpsy': ('orb', PSY), 'st_orbcalm': ('orb', CYAN), 'st_plus': ('plus', GREEN),
    'st_drip': ('drip', ACID), 'st_recycle': ('recycle', GREEN), 'st_swirlpsy': ('swirl', PSY), 'st_swirlcamo': ('swirl', CAMO),
    'st_plate': ('plate', GREY), 'st_plateiron': ('plate', STEELBLUE), 'st_acidplate': ('plate', ACID), 'st_hex': ('hexq', GREEN),
    'st_hexpink': ('hexq', PINK), 'st_bubble': ('bubbleq', BLUE), 'st_streak': ('streak', PSY), 'st_arrow': ('arrow', SANDY),
    'st_dup': ('dupghost', CYAN), 'st_drops': ('drops', BLUE), 'st_fog': ('fog', GREY), 'st_swish': ('swish', GREY),
    'st_dcloud': ('darkcloud', DARKP), 'st_eyes': ('eyes', RED), 'st_psyring': ('psyring', PSY), 'st_skull': ('skull', BLACK),
    'st_hand': ('hand', DARKP), 'st_scent': ('scent', SANDY), 'st_bricks': ('bricks', SANDY), 'st_wispp': ('wisp', PURPLE),
}
MOVES = {14: 'st_sword', 219: 'st_safe', 294: 'st_tailglow', 148: 'st_flash', 194: 'st_wispd', 96: 'st_orbpsy', 347: 'st_orbcalm',
         74: 'st_plus', 151: 'st_acidplate', 278: 'st_recycle', 100: 'st_swirlpsy', 293: 'st_swirlcamo', 106: 'st_plate',
         334: 'st_plateiron', 182: 'st_hex', 110: 'st_bubble', 97: 'st_streak', 107: 'st_arrow', 104: 'st_dup', 150: 'st_drops',
         114: 'st_fog', 39: 'st_swish', 144: 'st_swirlpsy', 171: 'st_dcloud', 180: 'st_wispp', 212: 'st_eyes', 244: 'st_psyring',
         262: 'st_skull', 272: 'st_orbpsy', 277: 'st_hexpink', 289: 'st_hand', 316: 'st_scent', 335: 'st_bricks'}
MOVES.pop(144); MOVES[144] = 'st_swirlpsy2'
DEF['st_swirlpsy2'] = ('swirl', PURPLE)
MOVES.pop(272); MOVES[272] = 'st_orbpsy2'
DEF['st_orbpsy2'] = ('orb', PINK)
MOVES.pop(151); MOVES[151] = 'st_acidplate'
# Metal Sound (319) reuses the 'sound' kind of Screech (its palette comes from the move type, steel)


def draw(kind, Canvas):
    c = Canvas()
    SHAPES[DEF[kind][0]](c)
    return c

def palette(kind):
    return DEF[kind][1]
