import sys; sys.path.insert(0,'/home/claude/work/kit/FireRed-RealtimeArena/tools')
from emu import Emu
ROM='/home/claude/work/kit/FireRed-RealtimeArena/out/t.gba'
def boot(rom=ROM):
    e=Emu(rom); e.run(400)
    for i in range(60): e.press(0x1,3,30)
    for i in range(150): e.press(0x8 if i==2 else 0x1,3,30)
    return e
def walk(e,key,n,fr=16):
    for _ in range(n): e.press(key,fr,2)
def to1f(e):
    e.run(60)
    for i in range(5): e.press(0x1,3,40)
    walk(e,0x80,2); walk(e,0x10,6); walk(e,0x80,2); walk(e,0x10,6); walk(e,0x40,6); walk(e,0x20,2); e.run(100)
def sbp(e): return e.r32(0x3005008)
def st(e):
    sb=sbp(e); return (e.r16(sb),e.r16(sb+2),e.r8(sb+4),e.r8(sb+5))
def setparty(e,sp):
    P=0x2024284
    for i in range(100): e.w8(P+i,0)
    e.w16(P+0x20,sp); e.w16(P+0x1C,sp); e.w8(0x2024029,1)
