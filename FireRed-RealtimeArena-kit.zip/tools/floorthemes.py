#!/usr/bin/env python3
"""floorthemes.py - generate src/gfx_floors.h: floor palettes and alternative floor tile sets
for the arena, one theme per FireRed battle terrain (grass, sand, water, cave, building, ...).
All art is original and drawn here."""
import os, random

def bgr(c):
    r, g, b = (c >> 16) & 255, (c >> 8) & 255, c & 255
    return (r >> 3) | ((g >> 3) << 5) | ((b >> 3) << 10)

# index: 0 transp, 1/2 base shades (checker), 3,4,5 details, 6 spare, 7,8,9 wall, A dark border
def pal(base1, base2, d3, d4, d5, w7, w8, w9, dark):
    # wall arguments are given light, mid, dark -> palette 9 (highlight), 7 (body), 8 (mortar)
    p = [0, base1, base2, d3, d4, d5, base1, w8, w9, w7, dark, 0, 0, 0, 0, 0]
    return [bgr(c) if c else 0 for c in p]

THEMES = [
    # 0 grass  (same colours as the original floor)
    None,
    # 1 long grass
    pal(0x2E7A32, 0x286C2C, 0x58B04A, 0x1E5A22, 0x174A1B, 0x8A8A8A, 0x6A6A6A, 0x4A4A4A, 0x101810),
    # 2 sand
    pal(0xDCC688, 0xD2BA7A, 0xEAD9A2, 0xBFA56A, 0xA98F55, 0xA89878, 0x887858, 0x686040, 0x201C10),
    # 3 underwater
    pal(0x2858A8, 0x224C98, 0x4C80D0, 0x183C80, 0x102C68, 0x587098, 0x405878, 0x2C4058, 0x081020),
    # 4 water (sea)
    pal(0x3C78D0, 0x3470C4, 0x78B0F0, 0x2A5CAC, 0x204C94, 0x8A9AA8, 0x687888, 0x485868, 0x101820),
    # 5 pond
    pal(0x48A0C8, 0x3F94BC, 0x88D0E8, 0x3482A8, 0x2A7090, 0x8A9A98, 0x687878, 0x485858, 0x102018),
    # 6 mountain / rock
    pal(0x9C9488, 0x90887C, 0xB4ACA0, 0x78706A, 0x625C56, 0x8C8478, 0x6C645A, 0x4C463E, 0x181410),
    # 7 cave
    pal(0x5C5048, 0x544840, 0x786A5C, 0x403830, 0x302A24, 0x6C6258, 0x4C443C, 0x342E28, 0x080808),
    # 8 building
    pal(0xC8C0B0, 0xB8B0A0, 0xE0D8C8, 0x8C8478, 0x706A60, 0x9C8C70, 0x7C6C54, 0x5C4C38, 0x181410),
    # 9 plain / dirt
    pal(0xA07C50, 0x967246, 0xB89468, 0x7C5C38, 0x68482C, 0x8A7A68, 0x6A5A48, 0x4A3C2C, 0x181008),
    # 10 snow (ice caves: Icefall Cave, Seafoam Islands)
    pal(0xEAF2FA, 0xDCE8F4, 0xFFFFFF, 0xBFD2E6, 0xA2BCD8, 0xA8C4DC, 0x88A8C8, 0x6888AC, 0x20303C),
]
THEME_TILESET = [0, 0, 0, 1, 1, 1, 0, 0, 2, 0, 0]      # 0 grass tiles, 1 water waves, 2 building plates

def pack_tile(rows):
    out = []
    for r in rows:
        v = 0
        for x, c in enumerate(r):
            v |= (c & 15) << (4 * x)
        out.append(v)
    return out

def water_tiles():
    rnd = random.Random(7)
    tiles = []
    for k in range(8):
        base = 1 if k % 2 == 0 else 2
        t = [[base] * 8 for _ in range(8)]
        r1 = (k * 3 + 1) % 6
        c1 = (k * 5) % 4
        for i in range(4):                       # light crest
            t[r1][c1 + i] = 3
        t[r1 + 1][(c1 + 4) % 8] = 4              # shadow under the wave
        t[r1 + 1][(c1 + 5) % 8] = 4
        r2 = (r1 + 4) % 8
        c2 = (c1 + 3) % 5
        for i in range(3):
            t[r2][c2 + i] = 5 if k % 3 == 0 else 3
        tiles.append(pack_tile(t))
    return tiles

def building_tiles():
    rnd = random.Random(11)
    tiles = []
    for k in range(8):
        base = 1 if k % 2 == 0 else 2
        t = [[base] * 8 for _ in range(8)]
        for i in range(8):
            t[7][i] = 4                          # grout
            t[i][7] = 4
        for i in range(7):
            t[0][i] = 3                          # highlight
        for i in range(1, 7):
            t[i][0] = 3
        if k % 3 == 0:
            t[3][3] = 5; t[4][4] = 5
        tiles.append(pack_tile(t))
    return tiles


# ---- court floor (sand arena with white lines, centre circle): a 28 x 13 tile picture built from unique tiles (+ flips) ----
COURT_PAL = [0, 0xE2BE56, 0xDEBA52, 0xEED27C, 0xC4A040, 0xFFF8EA, 0x8E7A4A, 0x7C6C54, 0x5C4C38, 0x9C8C70, 0x181410, 0x75653D, 0xCFC3A0, 0, 0, 0]
COURT_BASE = 16        # first tile index of the court tiles inside the floor charblock

def court_image():
    W, H = 240, 120
    img = [[1] * W for _ in range(H)]
    def circ(cx, cy, r0, r1):
        for y in range(H):
            for x in range(W):
                d = ((x + 0.5 - cx) ** 2 + (y + 0.5 - cy) ** 2) ** 0.5
                if r0 <= d <= r1: img[y][x] = 5
    # outer band (dark tan) and the line rectangle
    for y in range(3, H - 3):
        for x in range(3, W - 3):
            if x < 5 or x >= W - 5 or y < 5 or y >= H - 5: img[y][x] = 5      # the line rectangle, 3 px from the very edge of the screen field
    for y in range(3, H - 3):
        for x in (119, 120): img[y][x] = 5                   # centre line
    circ(120, 60, 16.0, 18.0)                                # centre circle
    circ(120, 60, 6.5, 8.5)                                  # inner ring
    return img

def court_tiles():
    img = court_image()
    rnd = random.Random(5)
    base = []                                                # plain sand variants
    for k in range(4):
        t = [[1 if (k % 2 == 0) else 2] * 8 for _ in range(8)]
        for _ in range(3 if k >= 2 else 1):
            t[rnd.randrange(8)][rnd.randrange(8)] = rnd.choice((3, 4))
        base.append(t)
    uniq = []                                                # list of 8x8 tiles
    def key(t): return tuple(tuple(r) for r in t)
    def flips(t):
        h = [r[::-1] for r in t]; v = t[::-1]; hv = [r[::-1] for r in v]
        return ((t, 0), (h, 1), (v, 2), (hv, 3))
    index = {}
    def add(t):
        for f, bits in flips(t):
            if key(f) in index: return index[key(f)][0], bits ^ index[key(f)][1] if False else bits
        return None
    out_map = []
    for ty in range(15):
        row = []
        for tx in range(30):
            t = [[img[ty * 8 + y][tx * 8 + x] for x in range(8)] for y in range(8)]
            plain = all(c == 1 for r in t for c in r)
            if plain:
                row.append(COURT_BASE + ((tx * 3 + ty * 5 + (tx * ty)) % 4) if (tx + ty) % 2 == 0 else COURT_BASE + 1 + 2 * (((tx + ty) // 2) % 2) * 0 + ((tx + ty) % 2)); continue
            found = None
            for f, bits in flips(t):
                if key(f) in index: found = (index[key(f)], bits); break
            if found is None:
                # store this orientation; a later tile that is a flip of it reuses it
                index[key(t)] = 4 + len(uniq); uniq.append(t); found = (index[key(t)], 0)
            row.append(COURT_BASE + found[0] - 4 + 0 if False else None)
            row[-1] = (found[0] - 4, found[1])
        out_map.append(row)
    return base, uniq, out_map

def court_emit(out):
    base, uniq, m = court_tiles()
    tiles = base + uniq
    out.append("#define COURT_BASE %d\n#define COURT_N %d\n" % (COURT_BASE, len(tiles)))
    out.append("static const u16 gCourtPal[16] = {" + ",".join("0x%04X" % bgr(c) if c else "0x0000" for c in COURT_PAL) + "};\n")
    out.append("static const u32 gCourtTiles[%d][8] = {\n" % len(tiles))
    for t in tiles: out.append("  {" + ",".join("0x%08X" % v for v in pack_tile(t)) + "},\n")
    out.append("};\n")
    out.append("static const u16 gCourtMap[15][30] = {\n")
    rows = []
    for ty, row in enumerate(m):
        vals = []
        for tx, e in enumerate(row):
            if isinstance(e, tuple):
                idx, bits = e; vals.append(0x1000 | ((bits & 1) << 10) | ((bits >> 1) << 11) | (COURT_BASE + len(base) + idx))
            else:
                vals.append(0x1000 | e)
        rows.append("  {" + ",".join(str(v) for v in vals) + "}")
    out.append(",\n".join(rows) + "\n};\n")
    print("court: %d tiles" % len(tiles))

def main():
    out = ["// generated by tools/floorthemes.py - arena floor themes (original art)\n"]
    out.append("static const u16 gFloorPals[11][16] = {\n")
    for i, p in enumerate(THEMES):
        if p is None:
            out.append("  {0x0000,0x32CE,0x2A8C,0x262A,0x3B11,0x1DC8,0x212B,0x2DAF,0x14C7,0x3A33,0x0C64,0x4296,0x0000,0x0000,0x0000,0x0000},\n")
        else:
            out.append("  {" + ",".join("0x%04X" % v for v in p) + "},\n")
    out.append("};\n")
    out.append("static const u8 gFloorSet[11] = {" + ",".join(str(v) for v in THEME_TILESET) + "};\n")
    for name, tl in (("gFloorWater", water_tiles()), ("gFloorBldg", building_tiles())):
        out.append("static const u32 %s[8][8] = {\n" % name)
        for t in tl:
            out.append("  {" + ",".join("0x%08X" % v for v in t) + "},\n")
        out.append("};\n")
    court_emit(out)
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "gfx_floors.h")
    open(path, "w").write("".join(out))
    print("wrote", os.path.normpath(path))

main()
